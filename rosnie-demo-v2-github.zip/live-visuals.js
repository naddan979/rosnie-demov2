(() => {
  const api = () => window.DemoV2PhysicalAI;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const states = new WeakMap();
  const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
  const lerp = (a, b, f) => a + (b - a) * f;
  const rng = seed => () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
  const pad = (value, size = 2) => String(value).padStart(size, '0');
  const stamp = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`; };
  const text = (english, german) => document.documentElement.lang === 'de' ? german : english;

  function fit(canvas) {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.round(canvas.clientWidth * ratio);
    const h = Math.round(canvas.clientHeight * ratio);
    if (!w || !h) return false;
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
    return true;
  }
  function layer(w, h, paint) {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    paint(canvas.getContext('2d'), w, h, w / 480);
    return canvas;
  }
  function overlayLayer(w, h) {
    return layer(w, h, (ctx, width, height, s) => {
      const vignette = ctx.createRadialGradient(width / 2, height / 2, height * 0.25, width / 2, height / 2, height * 0.95);
      vignette.addColorStop(0, 'rgba(0,0,0,0)');
      vignette.addColorStop(1, 'rgba(0,0,0,0.62)');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = 'rgba(0,0,0,0.16)';
      for (let y = 0; y < height; y += Math.max(2, Math.round(3 * s))) ctx.fillRect(0, y, width, 1);
    });
  }
  function weldBackground(w, h) {
    return layer(w, h, (ctx, width, height, s) => {
      const random = rng(7);
      const wall = ctx.createLinearGradient(0, 0, 0, height);
      wall.addColorStop(0, '#101513');
      wall.addColorStop(0.45, '#1b211e');
      wall.addColorStop(1, '#252c28');
      ctx.fillStyle = wall;
      ctx.fillRect(0, 0, width, height);
      for (let i = 0; i < 4; i++) {
        const light = ctx.createRadialGradient(width * (0.15 + i * 0.25), height * 0.08, 0, width * (0.15 + i * 0.25), height * 0.08, 60 * s);
        light.addColorStop(0, 'rgba(190,205,200,0.20)');
        light.addColorStop(1, 'rgba(190,205,200,0)');
        ctx.fillStyle = light;
        ctx.fillRect(0, 0, width, height * 0.5);
      }
      const plate = ctx.createLinearGradient(0, height * 0.42, 0, height * 0.84);
      plate.addColorStop(0, '#59615c');
      plate.addColorStop(1, '#3a413d');
      ctx.fillStyle = plate;
      ctx.fillRect(0, height * 0.42, width, height * 0.42);
      for (let i = 0; i < 260; i++) {
        ctx.strokeStyle = random() > 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.12)';
        ctx.lineWidth = Math.max(1, s * 0.6);
        const y = height * (0.42 + random() * 0.42);
        const x = random() * width;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + (0.05 + random() * 0.35) * width, y + (random() - 0.5) * 2 * s);
        ctx.stroke();
      }
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(width * 0.06, height * 0.62 - 3 * s, width * 0.88, 6 * s);
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.beginPath();
      ctx.moveTo(width * 0.06, height * 0.62 - 4 * s);
      ctx.lineTo(width * 0.94, height * 0.62 - 4 * s);
      ctx.stroke();
      ctx.fillStyle = '#14181a';
      ctx.fillRect(0, height * 0.84, width, height * 0.16);
    });
  }
  function gateBackground(w, h) {
    return layer(w, h, (ctx, width, height, s) => {
      const wall = ctx.createLinearGradient(0, 0, 0, height);
      wall.addColorStop(0, '#0f1412');
      wall.addColorStop(0.7, '#1c2320');
      wall.addColorStop(1, '#232b27');
      ctx.fillStyle = wall;
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = '#10151a';
      ctx.fillRect(0, 0, width * 0.05, height);
      ctx.fillRect(width * 0.95, 0, width * 0.05, height);
      ctx.fillRect(0, 0, width, height * 0.08);
      const floor = ctx.createLinearGradient(0, height * 0.72, 0, height);
      floor.addColorStop(0, '#2f3733');
      floor.addColorStop(1, '#171c19');
      ctx.fillStyle = floor;
      ctx.fillRect(0, height * 0.72, width, height * 0.28);
      const lamp = ctx.createRadialGradient(width * 0.5, height * 0.02, 0, width * 0.5, height * 0.5, height * 0.9);
      lamp.addColorStop(0, 'rgba(230,240,235,0.30)');
      lamp.addColorStop(1, 'rgba(230,240,235,0)');
      ctx.fillStyle = lamp;
      ctx.fillRect(0, 0, width, height);
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, height * 0.93, width, height * 0.07);
      ctx.clip();
      ctx.fillStyle = '#c9a227';
      ctx.fillRect(0, height * 0.93, width, height * 0.07);
      ctx.fillStyle = '#15191a';
      for (let x = -height; x < width + height; x += 22 * s) {
        ctx.beginPath();
        ctx.moveTo(x, height);
        ctx.lineTo(x + 11 * s, height);
        ctx.lineTo(x + 11 * s + height * 0.07, height * 0.93);
        ctx.lineTo(x + height * 0.07, height * 0.93);
        ctx.fill();
      }
      ctx.restore();
    });
  }
  function cameraState(canvas, kind) {
    let state = states.get(canvas);
    if (!state || state.w !== canvas.width || state.h !== canvas.height) {
      state = { w: canvas.width, h: canvas.height, particles: [], flagUntil: 0, seenTick: 0, last: 0, bg: kind === 'tag' ? gateBackground(canvas.width, canvas.height) : weldBackground(canvas.width, canvas.height), overlay: overlayLayer(canvas.width, canvas.height) };
      states.set(canvas, state);
    }
    return state;
  }
  function label(ctx, s, content, x, y, color) {
    ctx.font = `700 ${Math.round(10 * s)}px ui-monospace, Consolas, monospace`;
    const width = ctx.measureText(content).width + 8 * s;
    const left = clamp(x, 2 * s, ctx.canvas.width - width - 2 * s);
    ctx.fillStyle = color;
    ctx.fillRect(left, y - 14 * s, width, 14 * s);
    ctx.fillStyle = '#0c1210';
    ctx.textBaseline = 'middle';
    ctx.fillText(content, left + 4 * s, y - 7 * s);
  }
  function box(ctx, s, x, y, w, h, color, alpha = 1) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.6 * s;
    const c = Math.min(10 * s, w / 3, h / 3);
    ctx.beginPath();
    for (const [px, py, dx, dy] of [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]]) {
      ctx.moveTo(px + dx * c, py);
      ctx.lineTo(px, py);
      ctx.lineTo(px, py + dy * c);
    }
    ctx.stroke();
    ctx.restore();
  }
  function hud(ctx, s, device, t, live) {
    const { width, height } = ctx.canvas;
    ctx.font = `700 ${Math.round(10 * s)}px ui-monospace, Consolas, monospace`;
    ctx.textBaseline = 'top';
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(0, 0, width, 18 * s);
    ctx.fillRect(0, height - 18 * s, width, 18 * s);
    ctx.fillStyle = '#e8efe9';
    ctx.textAlign = 'left';
    ctx.fillText(device.id, 8 * s + 12 * s, 4 * s);
    if (live && Math.floor(t * 1.4) % 2 === 0) { ctx.fillStyle = '#ff4a3d'; ctx.beginPath(); ctx.arc(10 * s, 9 * s, 3.2 * s, 0, Math.PI * 2); ctx.fill(); }
    ctx.fillStyle = '#e8efe9';
    ctx.textAlign = 'right';
    ctx.fillText(stamp(), width - 8 * s, 4 * s);
    ctx.textAlign = 'left';
    ctx.fillStyle = '#b9c6bd';
    ctx.fillText(live ? '15 FPS \u00b7 AI VISION' : 'NO SIGNAL', 8 * s, height - 14 * s);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#e8c15a';
    ctx.fillText(text('SIMULATED', 'SIMULIERT'), width - 8 * s, height - 14 * s);
    ctx.textAlign = 'left';
  }
  function grain(ctx, s, state, strength) {
    const { width, height } = ctx.canvas;
    for (let i = 0; i < 380; i++) {
      const v = Math.random() * 255;
      ctx.fillStyle = `rgba(${v},${v},${v},${strength})`;
      ctx.fillRect(Math.random() * width, Math.random() * height, Math.max(1, s), Math.max(1, s));
    }
    ctx.drawImage(state.overlay, 0, 0);
  }
  function noSignal(ctx, s, state, device, t) {
    const { width, height } = ctx.canvas;
    ctx.fillStyle = '#0b0e0d';
    ctx.fillRect(0, 0, width, height);
    grain(ctx, s, state, 0.18);
    ctx.fillStyle = '#c9d3cc';
    ctx.font = `700 ${Math.round(14 * s)}px ui-monospace, Consolas, monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text('NO SIGNAL', 'KEIN SIGNAL'), width / 2, height / 2);
    ctx.textAlign = 'left';
    hud(ctx, s, device, t, false);
  }

  function drawWeld(canvas, device, ts, runtime, live) {
    const ctx = canvas.getContext('2d');
    const state = cameraState(canvas, 'weld');
    const { width, height } = canvas;
    const s = width / 480;
    const t = ts / 1000;
    if (!live) { noSignal(ctx, s, state, device, t); return; }
    const dt = clamp((ts - (state.last || ts)) / 1000, 0, 0.1);
    state.last = ts;
    const tickTime = api().getLastTick();
    if (state.seenTick !== tickTime) { state.seenTick = tickTime; if (runtime?.last?.exceeded) { state.flagUntil = ts + 7000; state.flagValue = runtime.last.value; } }
    const flagged = ts < state.flagUntil;
    ctx.globalCompositeOperation = 'source-over';
    ctx.drawImage(state.bg, 0, 0);
    const x0 = width * 0.08;
    const x1 = width * 0.92;
    const y = height * 0.62;
    const progress = (t * 0.07) % 1;
    const ax = lerp(x0, x1, progress);
    const trail = width * 0.3;
    const step = 3 * s;
    for (let x = x0; x <= ax; x += step) {
      const f = clamp((ax - x) / trail, 0, 1);
      const r = f < 0.35 ? lerp(255, 160, f / 0.35) : lerp(160, 98, (f - 0.35) / 0.65);
      const g = f < 0.35 ? lerp(170, 70, f / 0.35) : lerp(70, 104, (f - 0.35) / 0.65);
      const b = f < 0.35 ? lerp(60, 50, f / 0.35) : lerp(50, 112, (f - 0.35) / 0.65);
      ctx.fillStyle = `rgb(${r | 0},${g | 0},${b | 0})`;
      ctx.beginPath();
      ctx.ellipse(x, y + Math.sin(x / (4 * s)) * 0.5 * s, step * 1.05, (5 + Math.sin(x / (3.1 * s)) * 0.9) * s / 2 + 1.2 * s, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    if (flagged) {
      ctx.fillStyle = 'rgba(8,8,8,0.9)';
      for (const [dx, size] of [[0.11, 2.4], [0.14, 1.8], [0.17, 2.1]]) { ctx.beginPath(); ctx.arc(ax - dx * width, y + (dx * 40 % 3 - 1) * s, size * s, 0, Math.PI * 2); ctx.fill(); }
    }
    ctx.globalCompositeOperation = 'lighter';
    const flicker = 0.78 + Math.random() * 0.22;
    for (const [radius, a0, a1] of [[70 * s, 0.16, 0.05], [26 * s, 0.5, 0.14]]) {
      const bloom = ctx.createRadialGradient(ax, y, 0, ax, y, radius);
      bloom.addColorStop(0, `rgba(255,214,150,${a0 * flicker})`);
      bloom.addColorStop(0.5, `rgba(255,140,50,${a1 * flicker})`);
      bloom.addColorStop(1, 'rgba(255,120,30,0)');
      ctx.fillStyle = bloom;
      ctx.fillRect(ax - radius, y - radius, radius * 2, radius * 2);
    }
    const core = ctx.createRadialGradient(ax, y, 0, ax, y, 9 * s);
    core.addColorStop(0, `rgba(255,255,255,${flicker})`);
    core.addColorStop(0.5, `rgba(190,220,255,${0.7 * flicker})`);
    core.addColorStop(1, 'rgba(120,170,255,0)');
    ctx.fillStyle = core;
    ctx.fillRect(ax - 10 * s, y - 10 * s, 20 * s, 20 * s);
    ctx.globalCompositeOperation = 'source-over';
    for (let i = 0; i < 3 && state.particles.length < 90; i++) {
      state.particles.push({ x: ax, y, vx: (Math.random() - 0.75) * 170 * s, vy: -(30 + Math.random() * 150) * s, life: 0, max: 0.35 + Math.random() * 0.5 });
    }
    state.particles = state.particles.filter(p => {
      p.life += dt;
      p.vy += 430 * s * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.life >= p.max || p.y > height * 0.84) return false;
      const alpha = 1 - p.life / p.max;
      ctx.strokeStyle = `rgba(255,${190 - 80 * (1 - alpha) | 0},70,${alpha})`;
      ctx.lineWidth = 1.5 * s;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03);
      ctx.stroke();
      return true;
    });
    grain(ctx, s, state, 0.07);
    const bx = clamp(ax - 0.26 * width, width * 0.03, width * 0.7);
    const color = flagged ? '#ff5d4a' : '#5de08f';
    const pulse = flagged ? 0.6 + 0.4 * Math.abs(Math.sin(t * 5)) : 1;
    box(ctx, s, bx, height * 0.5, 0.27 * width, height * 0.2, color, pulse);
    const value = flagged ? (state.flagValue ?? 45) : (runtime?.last?.value ?? 97);
    label(ctx, s, flagged ? `${text('INDICATION', 'AUFF\u00c4LLIGKEIT')} ${(value / 100).toFixed(2)}` : `${text('SEAM OK', 'NAHT OK')} ${Math.round(value)}%`, bx, height * 0.5, color);
    hud(ctx, s, device, t, true);
  }

  function drawGate(canvas, device, ts, runtime, live) {
    const ctx = canvas.getContext('2d');
    const state = cameraState(canvas, 'tag');
    const { width, height } = canvas;
    const s = width / 480;
    const t = ts / 1000;
    if (!live) { noSignal(ctx, s, state, device, t); return; }
    const tickTime = api().getLastTick();
    if (state.seenTick !== tickTime) { state.seenTick = tickTime; if (runtime?.last?.exceeded) { state.flagUntil = ts + 7000; state.flagValue = runtime.last.value; } }
    const flagged = ts < state.flagUntil;
    const componentId = api().link(device)?.componentId || 'ASTRA';
    ctx.globalCompositeOperation = 'source-over';
    ctx.save();
    ctx.translate((Math.random() - 0.5) * 0.6 * s, (Math.random() - 0.5) * 0.6 * s);
    ctx.drawImage(state.bg, 0, 0);
    const progress = (t / 26) % 1;
    const bodyW = width * 0.5;
    const bodyH = height * 0.34;
    const bx = lerp(-bodyW, width * 1.02, progress);
    const by = height * 0.38;
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    ctx.ellipse(bx + bodyW / 2, height * 0.76, bodyW * 0.55, 8 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    const body = ctx.createLinearGradient(0, by, 0, by + bodyH);
    body.addColorStop(0, '#76807a');
    body.addColorStop(0.5, '#58625c');
    body.addColorStop(1, '#3d4640');
    ctx.fillStyle = body;
    ctx.fillRect(bx, by, bodyW, bodyH);
    ctx.fillStyle = 'rgba(255,255,255,0.10)';
    ctx.fillRect(bx, by, bodyW, 3 * s);
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.lineWidth = s;
    for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(bx + bodyW * i / 4, by); ctx.lineTo(bx + bodyW * i / 4, by + bodyH); ctx.stroke(); }
    ctx.fillStyle = '#2c332f';
    for (let i = 0; i < 8; i++) { ctx.beginPath(); ctx.arc(bx + bodyW * (0.06 + 0.125 * i), by + 7 * s, 2.2 * s, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.arc(bx + bodyW * (0.06 + 0.125 * i), by + bodyH - 7 * s, 2.2 * s, 0, Math.PI * 2); ctx.fill(); }
    const tagW = width * 0.22;
    const tagH = height * 0.1;
    const tx = bx + bodyW * 0.55;
    const ty = by + bodyH * 0.34;
    ctx.fillStyle = '#dde1d8';
    ctx.fillRect(tx, ty, tagW, tagH);
    ctx.fillStyle = '#1b211e';
    ctx.font = `700 ${Math.round(11 * s)}px ui-monospace, Consolas, monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(flagged ? 'ASTRA-XX-000' : componentId, tx + tagW / 2, ty + tagH / 2, tagW - 6 * s);
    ctx.textAlign = 'left';
    const zoneL = width * 0.28;
    const zoneR = width * 0.72;
    const centre = tx + tagW / 2;
    const inZone = centre > zoneL && centre < zoneR;
    const onScreen = tx + tagW > 0 && tx < width;
    ctx.restore();
    if (onScreen) {
      if (inZone) {
        const color = flagged ? '#ff5d4a' : '#5de08f';
        box(ctx, s, tx - 4 * s, ty - 4 * s, tagW + 8 * s, tagH + 8 * s, color, flagged ? 0.6 + 0.4 * Math.abs(Math.sin(t * 5)) : 1);
        label(ctx, s, flagged ? `${text('NO MATCH', 'KEIN TREFFER')} ${((state.flagValue ?? 40) / 100).toFixed(2)}` : `${text('TAG MATCH', 'KENNZ. PASST')} ${Math.round(runtime?.last?.value ?? 99)}%`, tx - 4 * s, ty - 4 * s, color);
      } else {
        box(ctx, s, tx - 4 * s, ty - 4 * s, tagW + 8 * s, tagH + 8 * s, '#59c7e8', 0.8);
        label(ctx, s, text('TRACKING', 'VERFOLGUNG'), tx - 4 * s, ty - 4 * s, '#59c7e8');
      }
    }
    ctx.strokeStyle = 'rgba(89,199,232,0.35)';
    ctx.lineWidth = s;
    ctx.setLineDash([4 * s, 4 * s]);
    ctx.strokeRect(zoneL, height * 0.18, zoneR - zoneL, height * 0.62);
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(89,199,232,0.30)';
    ctx.fillRect(lerp(zoneL, zoneR, (t * 0.7) % 1), height * 0.18, 1.5 * s, height * 0.62);
    grain(ctx, s, state, 0.08);
    hud(ctx, s, device, t, true);
  }

  function drawChart(canvas, device, ts, runtime, live) {
    const ctx = canvas.getContext('2d');
    const { width, height } = canvas;
    const ratio = width / Math.max(canvas.clientWidth, 1);
    const values = runtime?.history || [];
    const times = runtime?.times || [];
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#f4f6f2';
    ctx.fillRect(0, 0, width, height);
    const span = api().SAMPLES * api().TICK_MS;
    const now = live ? ts : (times[times.length - 1] ?? ts);
    const camera = device.rule === 'camera';
    let low = Math.min(...values, camera ? 90 : (device.max || 1) * 0.55);
    let high = Math.max(...values, camera ? 100 : (device.max || 1)) + (camera ? 1 : (device.max || 1) * 0.08);
    if (!(high > low)) high = low + 1;
    low -= (high - low) * 0.06;
    const top = 6 * ratio;
    const bottom = height - 12 * ratio;
    const yOf = value => bottom - (value - low) / (high - low) * (bottom - top);
    const xOf = time => width - (now - time) / span * width;
    ctx.strokeStyle = 'rgba(40,60,50,0.08)';
    ctx.lineWidth = ratio;
    for (let i = 1; i < 4; i++) { const gy = top + (bottom - top) * i / 4; ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(width, gy); ctx.stroke(); }
    if (!camera && device.max) {
      ctx.strokeStyle = '#a3483c';
      ctx.setLineDash([4 * ratio, 4 * ratio]);
      ctx.beginPath();
      ctx.moveTo(0, yOf(device.max));
      ctx.lineTo(width, yOf(device.max));
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#a3483c';
      ctx.font = `${Math.round(8 * ratio)}px sans-serif`;
      ctx.textBaseline = 'top';
      ctx.textAlign = 'right';
      ctx.fillText(`${text('limit', 'Grenze')} ${device.max}`, width - 3 * ratio, yOf(device.max) + 2 * ratio);
      ctx.textAlign = 'left';
    }
    if (values.length) {
      const points = values.map((value, index) => [xOf(times[index] ?? now), yOf(value), value]);
      points.push([width, points[points.length - 1][1], values[values.length - 1]]);
      const area = ctx.createLinearGradient(0, top, 0, bottom);
      area.addColorStop(0, 'rgba(40,95,74,0.22)');
      area.addColorStop(1, 'rgba(40,95,74,0)');
      ctx.beginPath();
      ctx.moveTo(points[0][0], bottom);
      for (const [x, y] of points) ctx.lineTo(x, y);
      ctx.lineTo(width, bottom);
      ctx.closePath();
      ctx.fillStyle = area;
      ctx.fill();
      ctx.beginPath();
      points.forEach(([x, y], index) => index ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
      ctx.strokeStyle = '#285f4a';
      ctx.lineWidth = 1.6 * ratio;
      ctx.lineJoin = 'round';
      ctx.stroke();
      for (const [x, y, value] of points) if (device.max && value > device.max) { ctx.fillStyle = '#a3483c'; ctx.beginPath(); ctx.arc(x, y, 2.4 * ratio, 0, Math.PI * 2); ctx.fill(); }
      const [lx, ly] = points[points.length - 1];
      const pulse = live ? 0.5 + 0.5 * Math.sin(ts / 260) : 0;
      ctx.fillStyle = `rgba(40,95,74,${0.18 + 0.2 * pulse})`;
      ctx.beginPath();
      ctx.arc(lx - ratio, ly, (4 + 3 * pulse) * ratio, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#285f4a';
      ctx.beginPath();
      ctx.arc(lx - ratio, ly, 2.2 * ratio, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = '#7b857e';
    ctx.font = `${Math.round(8 * ratio)}px sans-serif`;
    ctx.textBaseline = 'bottom';
    ctx.fillText(`-${Math.round(span / 1000)} s`, 3 * ratio, height - 1);
    ctx.textAlign = 'right';
    ctx.fillText(live ? text('now', 'jetzt') : text('paused', 'pausiert'), width - 3 * ratio, height - 1);
    ctx.textAlign = 'left';
  }

  let lastDraw = 0;
  function frame(ts) {
    requestAnimationFrame(frame);
    if (document.hidden || ts - lastDraw < (reduceMotion.matches ? 1000 : 66)) return;
    lastDraw = ts;
    const physical = api();
    if (!physical) return;
    for (const canvas of document.querySelectorAll('canvas[data-live-canvas]')) {
      const device = physical.devices.find(item => item.id === canvas.dataset.device);
      if (!device || !fit(canvas)) continue;
      const runtime = physical.rt[device.id];
      const live = physical.isLive(device);
      if (canvas.dataset.liveCanvas === 'chart') drawChart(canvas, device, ts, runtime, live);
      else if (device.scene === 'tag') drawGate(canvas, device, ts, runtime, live);
      else drawWeld(canvas, device, ts, runtime, live);
    }
  }
  requestAnimationFrame(frame);
})();
