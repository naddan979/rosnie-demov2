(() => {
  const storageKey = 'rosnie-demo-v2-operations-v1';
  const app = () => window.DemoV2;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  const dialog = document.createElement('dialog');
  dialog.id = 'evidence-editor-dialog';
  dialog.className = 'audit-modal evidence-editor';
  dialog.setAttribute('aria-labelledby', 'evidence-editor-title');
  dialog.innerHTML = '<header class="audit-modal-header"><div><small>ASTRA</small><h2 id="evidence-editor-title"></h2></div><button class="button secondary evidence-editor-close" type="button"></button></header><div class="audit-modal-body" id="evidence-editor-body"></div>';
  document.body.append(dialog);
  const body = dialog.querySelector('#evidence-editor-body');
  let order;
  let task;
  let draft;
  let step = 0;
  let opener;
  let completed = false;
  const profiles = {
    'material-certificate': {
      title: ['Steel material verification record', 'Stahlmaterial-Prüfprotokoll'],
      instruction: ['Compare the supplier certificate with the delivered material and component markings. Record actual certificate references and results; do not invent missing test data.', 'Lieferantenzeugnis mit geliefertem Material und Bauteilkennzeichnung vergleichen. Tatsächliche Zeugnisreferenzen und Ergebnisse erfassen; fehlende Prüfdaten nicht erfinden.'],
      fields: [
        ['issuer', 'Certificate issuer / supplier', 'Zeugnisaussteller / Lieferant'],
        ['reference', 'Supplier certificate reference', 'Referenz des Lieferantenzeugnisses'],
        ['grade', 'Material grade', 'Werkstoffgüte'],
        ['heat', 'Heat / batch number', 'Schmelzen- / Chargennummer'],
        ['specification', 'Required specification / certificate type', 'Geforderte Spezifikation / Zeugnisart'],
        ['results', 'Observed test results and units', 'Festgestellte Prüfergebnisse und Einheiten', 'textarea']
      ],
      checks: [
        ['Certificate identity and issuer checked against the source.', 'Zeugnisidentität und Aussteller mit der Quelle abgeglichen.'],
        ['Heat / batch marking checked against the component.', 'Schmelzen- / Chargenkennzeichnung mit dem Bauteil abgeglichen.'],
        ['Material grade and reported results compared with the order specification.', 'Werkstoffgüte und berichtete Ergebnisse mit der Auftragsspezifikation verglichen.']
      ]
    },
    wps: {
      title: ['Welding procedure worksheet', 'Schweißanweisungs-Arbeitsblatt'],
      instruction: ['Record the applicable qualified procedure and actual welding parameters. This worksheet does not qualify a procedure or replace authorized welding engineering approval.', 'Anwendbares qualifiziertes Verfahren und tatsächliche Schweißparameter erfassen. Dieses Arbeitsblatt qualifiziert kein Verfahren und ersetzt keine autorisierte schweißtechnische Freigabe.'],
      fields: [['reference', 'WPS reference / revision', 'WPS-Referenz / Revision'], ['qualification', 'Supporting WPQR reference', 'Zugehörige WPQR-Referenz'], ['process', 'Welding process and joint', 'Schweißprozess und Naht'], ['material', 'Base / filler material and thickness', 'Grund- / Zusatzwerkstoff und Dicke'], ['results', 'Parameters and acceptance criteria', 'Parameter und Annahmekriterien', 'textarea']],
      checks: [['Procedure revision checked.', 'Verfahrensrevision geprüft.'], ['Qualification range checked for this joint.', 'Qualifikationsbereich für diese Naht geprüft.'], ['Welding coordinator review requested.', 'Prüfung durch Schweißaufsicht angefordert.']]
    },
    wpqr: {
      title: ['Procedure qualification evidence record', 'Verfahrensprüfungs-Nachweisprotokoll'],
      instruction: ['Reference the actual qualification test and responsible examiner. Enter observed results only; this record cannot issue or fabricate a qualification.', 'Tatsächliche Verfahrensprüfung und zuständige Prüfstelle referenzieren. Nur festgestellte Ergebnisse erfassen; dieses Protokoll kann keine Qualifikation ausstellen oder erfinden.'],
      fields: [['reference', 'Qualification report reference', 'Referenz des Verfahrensprüfberichts'], ['issuer', 'Examiner / testing body', 'Prüfer / Prüfstelle'], ['process', 'Process and qualification range', 'Verfahren und Qualifikationsbereich'], ['results', 'Test results and source references', 'Prüfergebnisse und Quellreferenzen', 'textarea']],
      checks: [['Source qualification report available.', 'Original-Verfahrensprüfbericht verfügbar.'], ['Test scope matched to the intended procedure.', 'Prüfumfang mit vorgesehenem Verfahren abgeglichen.'], ['Authorized examiner identified.', 'Autorisierte Prüfstelle benannt.']]
    },
    'ndt-report': {
      title: ['NDT inspection record', 'ZfP-Prüfprotokoll'],
      instruction: ['Record the performed inspection, its method and actual findings. Only qualified personnel may perform and authorize the inspection.', 'Durchgeführte Prüfung, Verfahren und tatsächliche Befunde erfassen. Durchführung und Autorisierung nur durch qualifiziertes Personal.'],
      fields: [['reference', 'Inspection / procedure reference', 'Prüfungs- / Verfahrensreferenz'], ['inspector', 'Inspector and qualification reference', 'Prüfer und Qualifikationsreferenz'], ['method', 'Method, scope and equipment', 'Verfahren, Umfang und Prüfmittel'], ['criteria', 'Acceptance criteria', 'Annahmekriterien'], ['results', 'Findings and measurements', 'Befunde und Messwerte', 'textarea']],
      checks: [['Inspector qualification checked.', 'Prüferqualifikation geprüft.'], ['Inspection scope and equipment identified.', 'Prüfumfang und Prüfmittel erfasst.'], ['Findings compared with acceptance criteria.', 'Befunde mit Annahmekriterien verglichen.']]
    }
  };
  const compact = (titleEn, titleDe, instrEn, instrDe, fields, checks) => ({ title: [titleEn, titleDe], instruction: [instrEn, instrDe], fields, checks });
  const extra = {
    'inspection-report': compact('Inspection record', 'Prüfprotokoll', 'Record what was inspected, how, against which criteria, and the actual findings.', 'Erfassen, was wie und gegen welche Kriterien geprüft wurde, sowie die tatsächlichen Befunde.', [['reference', 'Inspection procedure / drawing reference', 'Prüfanweisung / Zeichnungsreferenz'], ['inspector', 'Inspector and qualification reference', 'Prüfer und Qualifikationsreferenz'], ['method', 'Method, scope and measuring equipment ID', 'Verfahren, Umfang und Messmittel-ID'], ['criteria', 'Acceptance criteria', 'Annahmekriterien'], ['results', 'Findings and measurements', 'Befunde und Messwerte', 'textarea']], [['Inspector qualification checked.', 'Prüferqualifikation geprüft.'], ['Measuring equipment identified and in calibration.', 'Messmittel identifiziert und kalibriert.'], ['Findings compared with acceptance criteria.', 'Befunde mit Annahmekriterien verglichen.']]),
    'calibration-certificate': compact('Calibration evidence record', 'Kalibriernachweis', 'Reference the actual calibration certificate and record the equipment it covers. This record does not replace the certificate issued by the calibration laboratory.', 'Das tatsächliche Kalibrierzertifikat referenzieren und das erfasste Messmittel dokumentieren. Dieses Protokoll ersetzt nicht das Zertifikat des Kalibrierlabors.', [['reference', 'Calibration certificate number', 'Kalibrierzertifikat-Nummer'], ['equipment', 'Equipment ID and measuring range', 'Messmittel-ID und Messbereich'], ['issuer', 'Calibration laboratory / accreditation', 'Kalibrierlabor / Akkreditierung'], ['due', 'Calibration date and next due date', 'Kalibrierdatum und nächster Termin'], ['results', 'Deviation found and acceptance decision', 'Festgestellte Abweichung und Annahmeentscheidung', 'textarea']], [['Certificate matches the equipment ID.', 'Zertifikat entspricht der Messmittel-ID.'], ['Calibration is valid for the intended measuring range.', 'Kalibrierung gilt für den vorgesehenen Messbereich.'], ['Next due date is scheduled.', 'Nächster Termin ist eingeplant.']]),
    'welding-record': compact('Welding execution record', 'Schweißausführungsprotokoll', 'Record who welded what, with which procedure and the actual parameters used.', 'Erfassen, wer was mit welchem Verfahren und mit welchen tatsächlichen Parametern geschweißt hat.', [['reference', 'WPS reference used', 'Verwendete WPS-Referenz'], ['inspector', 'Welder and qualification reference', 'Schweißer und Qualifikationsreferenz'], ['material', 'Material, filler and batch identification', 'Werkstoff, Zusatzwerkstoff und Chargenkennzeichnung'], ['results', 'Actual parameters (current, voltage, interpass temperature)', 'Tatsächliche Parameter (Strom, Spannung, Zwischenlagentemperatur)', 'textarea']], [['Welder qualification valid for this joint.', 'Schweißerqualifikation gilt für diese Naht.'], ['Parameters within the approved WPS range.', 'Parameter innerhalb des freigegebenen WPS-Bereichs.'], ['Joint and component identification recorded.', 'Naht- und Bauteilkennzeichnung erfasst.']]),
    'traceability-record': compact('Component traceability record', 'Bauteil-Rückverfolgbarkeitsnachweis', 'Link the component marking to its material, order and inspection records.', 'Die Bauteilkennzeichnung mit Material-, Auftrags- und Prüfnachweisen verknüpfen.', [['reference', 'Component marking / serial number', 'Bauteilkennzeichnung / Seriennummer'], ['heat', 'Linked heat / batch numbers', 'Verknüpfte Schmelzen- / Chargennummern'], ['inspector', 'Checked by', 'Geprüft durch'], ['results', 'Traceability result and discrepancies', 'Rückverfolgbarkeitsergebnis und Abweichungen', 'textarea']], [['Marking on the component matches ASTRA.', 'Kennzeichnung am Bauteil entspricht ASTRA.'], ['Material records linked to the marking.', 'Materialnachweise mit der Kennzeichnung verknüpft.'], ['Discrepancies recorded.', 'Abweichungen dokumentiert.']]),
    'operation-check': compact('Operational monitoring record', 'Betriebsüberwachungsprotokoll', 'Record the monitored condition, measurement method and actual readings against the applicable limit.', 'Überwachte Bedingung, Messmethode und tatsächliche Messwerte gegenüber dem geltenden Grenzwert erfassen.', [['reference', 'Monitoring procedure / permit condition reference', 'Überwachungsverfahren / Auflagenreferenz'], ['equipment', 'Measuring equipment ID', 'Messmittel-ID'], ['criteria', 'Applicable limit and source', 'Geltender Grenzwert und Quelle'], ['results', 'Readings and period covered', 'Messwerte und erfasster Zeitraum', 'textarea']], [['Limit taken from the authoritative source.', 'Grenzwert aus der maßgeblichen Quelle übernommen.'], ['Measuring equipment calibrated.', 'Messmittel kalibriert.'], ['Exceedances recorded with actions.', 'Überschreitungen mit Maßnahmen erfasst.']]),
    'release-package': compact('Release and conformity record', 'Freigabe- und Konformitätsprotokoll', 'List the records that support release and who authorized it.', 'Nachweise auflisten, die die Freigabe stützen, und wer sie autorisiert hat.', [['reference', 'Release / declaration reference', 'Freigabe- / Erklärungsreferenz'], ['criteria', 'Applicable requirements or customer specification', 'Anwendbare Anforderungen oder Kundenspezifikation'], ['inspector', 'Released by', 'Freigegeben durch'], ['results', 'Supporting records and open items', 'Unterstützende Nachweise und offene Punkte', 'textarea']], [['All required inspection records are attached.', 'Alle erforderlichen Prüfnachweise sind beigefügt.'], ['No open nonconformities remain.', 'Keine offenen Nichtkonformitäten.'], ['Authorized person identified.', 'Autorisierte Person benannt.']]),
    'internal-audit-report': compact('Internal audit report', 'Interner Auditbericht', 'Record scope, criteria, findings and follow-up of the internal audit.', 'Geltungsbereich, Kriterien, Feststellungen und Folgemaßnahmen des internen Audits erfassen.', [['reference', 'Audit programme reference', 'Auditprogramm-Referenz'], ['inspector', 'Auditor and independence statement', 'Auditor und Unabhängigkeitserklärung'], ['criteria', 'Audit scope and criteria', 'Auditumfang und -kriterien'], ['results', 'Findings and follow-up actions', 'Feststellungen und Folgemaßnahmen', 'textarea']], [['Auditor is independent of the audited area.', 'Auditor ist vom auditierten Bereich unabhängig.'], ['Findings link to criteria.', 'Feststellungen sind den Kriterien zugeordnet.'], ['Follow-up owners and dates set.', 'Verantwortliche und Termine für Folgemaßnahmen festgelegt.']]),
    'management-review': compact('Management review record', 'Managementbewertungsprotokoll', 'Record who reviewed which inputs and the decisions and actions taken.', 'Erfassen, wer welche Eingaben bewertet hat sowie Entscheidungen und Maßnahmen.', [['reference', 'Meeting reference and date', 'Besprechungsreferenz und Datum'], ['inspector', 'Participants (top management)', 'Teilnehmer (oberste Leitung)'], ['criteria', 'Inputs reviewed', 'Bewertete Eingaben'], ['results', 'Decisions and actions', 'Entscheidungen und Maßnahmen', 'textarea']], [['Top management took part.', 'Oberste Leitung hat teilgenommen.'], ['Required inputs were reviewed.', 'Erforderliche Eingaben wurden bewertet.'], ['Actions have owners and dates.', 'Maßnahmen haben Verantwortliche und Termine.']]),
    'corrective-action': compact('Nonconformity and corrective action record', 'Nichtkonformitäts- und Korrekturmaßnahmenprotokoll', 'Describe the nonconformity, its cause, the action taken and how effectiveness is checked.', 'Nichtkonformität, Ursache, ergriffene Maßnahme und Wirksamkeitsprüfung beschreiben.', [['reference', 'Nonconformity reference', 'Nichtkonformitäts-Referenz'], ['criteria', 'Requirement not met', 'Nicht erfüllte Anforderung'], ['cause', 'Root cause', 'Ursache'], ['results', 'Action taken and effectiveness check', 'Ergriffene Maßnahme und Wirksamkeitsprüfung', 'textarea']], [['Nonconformity described against a requirement.', 'Nichtkonformität anhand einer Anforderung beschrieben.'], ['Root cause analysed.', 'Ursache analysiert.'], ['Effectiveness check scheduled.', 'Wirksamkeitsprüfung eingeplant.']]),
    'controlled-document': compact('Controlled document record', 'Gelenktes Dokument', 'Register the document with its owner, version, approval and scope.', 'Das Dokument mit Verantwortlichem, Version, Freigabe und Geltungsbereich erfassen.', [['reference', 'Document title and number', 'Dokumenttitel und -nummer'], ['version', 'Version and approval date', 'Version und Freigabedatum'], ['inspector', 'Owner and approver', 'Verantwortlicher und Freigebender'], ['results', 'Scope and summary of content', 'Geltungsbereich und Inhaltszusammenfassung', 'textarea']], [['Document owner and approver identified.', 'Dokumentverantwortlicher und Freigebender benannt.'], ['Current version confirmed.', 'Aktuelle Version bestätigt.'], ['Scope matches the audit scope.', 'Geltungsbereich entspricht dem Auditumfang.']]),
    'competence-record': compact('Competence and training record', 'Kompetenz- und Schulungsnachweis', 'Record who holds which competence, how it was assessed and when it expires.', 'Erfassen, wer welche Kompetenz besitzt, wie sie bewertet wurde und wann sie abläuft.', [['reference', 'Training / qualification reference', 'Schulungs- / Qualifikationsreferenz'], ['inspector', 'Person and role', 'Person und Rolle'], ['criteria', 'Competence required', 'Erforderliche Kompetenz'], ['results', 'Assessment result and validity', 'Bewertungsergebnis und Gültigkeit', 'textarea']], [['Competence compared with the role requirement.', 'Kompetenz mit der Rollenanforderung abgeglichen.'], ['Evidence of training or qualification seen.', 'Schulungs- oder Qualifikationsnachweis eingesehen.'], ['Expiry or refresh date recorded.', 'Ablauf- oder Auffrischungsdatum erfasst.']]),
    'risk-assessment': compact('Risk assessment record', 'Risikobeurteilungsprotokoll', 'Record identified hazards, aspects or risks, their rating and treatment.', 'Erkannte Gefährdungen, Aspekte oder Risiken sowie Bewertung und Behandlung erfassen.', [['reference', 'Assessment reference and method', 'Beurteilungsreferenz und Methode'], ['inspector', 'Assessors', 'Beurteilende'], ['scope', 'Scope and activities assessed', 'Umfang und beurteilte Tätigkeiten'], ['results', 'Risks, rating and treatment', 'Risiken, Bewertung und Behandlung', 'textarea']], [['Relevant activities and sites covered.', 'Relevante Tätigkeiten und Standorte erfasst.'], ['Risks rated by the defined method.', 'Risiken nach definierter Methode bewertet.'], ['Treatment owners assigned.', 'Verantwortliche für die Behandlung zugewiesen.']]),
    'legal-register': compact('Obligations register record', 'Pflichtenregister-Eintrag', 'Record the applicable legal or permit obligations and how compliance is evaluated.', 'Anwendbare rechtliche oder genehmigungsrechtliche Pflichten und deren Bewertung erfassen.', [['reference', 'Legal source / permit condition reference', 'Rechtsquelle / Auflagenreferenz'], ['inspector', 'Responsible person', 'Verantwortliche Person'], ['criteria', 'Obligation and applicability', 'Pflicht und Anwendbarkeit'], ['results', 'Compliance evaluation and date', 'Konformitätsbewertung und Datum', 'textarea']], [['Obligation taken from the authoritative source.', 'Pflicht aus der maßgeblichen Quelle übernommen.'], ['Applicability to the site confirmed.', 'Anwendbarkeit auf den Standort bestätigt.'], ['Evaluation date recorded.', 'Bewertungsdatum erfasst.']]),
    'energy-data': compact('Energy data record', 'Energiedatenprotokoll', 'Record the energy boundary, data source and period, with the baseline or consumption values.', 'Energiegrenze, Datenquelle und Zeitraum mit Baseline- oder Verbrauchswerten erfassen.', [['reference', 'Meter / data source reference', 'Zähler- / Datenquellenreferenz'], ['scope', 'Boundary and period', 'Systemgrenze und Zeitraum'], ['criteria', 'Relevant variables and normalisation', 'Relevante Einflussgrößen und Normalisierung'], ['results', 'Values and baseline comparison', 'Werte und Baselinevergleich', 'textarea']], [['Meter calibration status known.', 'Kalibrierstatus des Zählers bekannt.'], ['Boundary matches the energy review.', 'Systemgrenze entspricht der energetischen Bewertung.'], ['Normalisation method documented.', 'Normalisierungsmethode dokumentiert.']]),
    'access-review': compact('Access review record', 'Zugriffsprüfungsprotokoll', 'Record the system reviewed, who reviewed it and the access changes decided.', 'Das geprüfte System, die prüfende Person und die beschlossenen Zugriffsänderungen erfassen.', [['reference', 'System and review reference', 'System und Prüfungsreferenz'], ['inspector', 'Reviewer and system owner', 'Prüfer und Systemverantwortlicher'], ['scope', 'Accounts and roles reviewed', 'Geprüfte Konten und Rollen'], ['results', 'Findings and access changes', 'Feststellungen und Zugriffsänderungen', 'textarea']], [['Account list taken from the system source.', 'Kontenliste aus der Systemquelle übernommen.'], ['Excess access removed or justified.', 'Übermäßiger Zugriff entfernt oder begründet.'], ['System owner confirmed the result.', 'Systemverantwortlicher bestätigte das Ergebnis.']]),
    'security-log': compact('Security monitoring record', 'Sicherheitsüberwachungsnachweis', 'Record the monitored systems, log sources, review period and events handled.', 'Überwachte Systeme, Logquellen, Prüfzeitraum und bearbeitete Ereignisse erfassen.', [['reference', 'Log source / tool reference', 'Logquelle / Werkzeugreferenz'], ['inspector', 'Reviewer', 'Prüfer'], ['scope', 'Systems and period covered', 'Erfasste Systeme und Zeitraum'], ['results', 'Events reviewed and actions taken', 'Geprüfte Ereignisse und Maßnahmen', 'textarea']], [['Log retention covers the review period.', 'Log-Aufbewahrung deckt den Prüfzeitraum ab.'], ['Events reviewed by a competent person.', 'Ereignisse durch fachkundige Person geprüft.'], ['Incidents followed up.', 'Vorfälle nachverfolgt.']])
  };
  function profile() {
    return profiles[task.kind] || extra[task.kind] || {
      title: [task.title + ' record', task.title + ' - Protokoll'],
      instruction: ['Record the work performed, source references and actual findings for this task. Missing facts must be collected from the responsible person, not inferred.', 'Durchgeführte Arbeit, Quellreferenzen und tatsächliche Befunde für diesen Schritt erfassen. Fehlende Fakten bei der zuständigen Person erheben, nicht ableiten.'],
      fields: [['reference', 'Record / procedure reference', 'Protokoll- / Verfahrensreferenz'], ['inspector', 'Responsible person / qualification', 'Verantwortliche Person / Qualifikation'], ['criteria', 'Scope and acceptance criteria', 'Umfang und Annahmekriterien'], ['results', 'Actual results and source references', 'Tatsächliche Ergebnisse und Quellreferenzen', 'textarea']],
      checks: [['Task and component identity checked.', 'Arbeitsschritt und Bauteilidentität geprüft.'], ['Source data and results reviewed.', 'Quelldaten und Ergebnisse geprüft.'], ['Outstanding issues recorded for the reviewer.', 'Offene Punkte für die Prüfung erfasst.']]
    };
  }
  const translated = values => text(...values);
  const refLabel = item => `${item.standard} ${/^(\d|A\.)/.test(item.ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')}${item.ref} · ${translated(item.title)}`;
  const clauseBlock = () => task.clauses?.length ? `<div class="evidence-clauses"><strong>${text('This document will address', 'Dieses Dokument bezieht sich auf')}</strong><ul>${task.clauses.map(item => `<li>${escapeHtml(refLabel(item))}</li>`).join('')}</ul></div>` : '';
  function completeness() {
    const template = profile();
    const parts = [...template.fields.map(([name]) => !!String(draft[name] || '').trim()), !!String(draft.author || '').trim(), !!draft.date, ...template.checks.map((label, index) => !!draft['check' + index]), !!draft.contextConfirmed];
    const done = parts.filter(Boolean).length;
    return { done, total: parts.length, percent: Math.round(done / parts.length * 100) };
  }
  function completenessHtml() {
    const score = completeness();
    return `<p class="evidence-completeness" data-completeness>${text('Completeness against the required content', 'Vollständigkeit gegenüber den Pflichtinhalten')}: <strong>${score.percent}%</strong> (${score.done}/${score.total}). ${task.virtual ? text('Formal compliance is confirmed only by authorized verification in MIRA; ROSNIE checks that the required content is present.', 'Formale Konformität bestätigt nur die autorisierte Verifizierung in MIRA; ROSNIE prüft, dass die Pflichtinhalte vorhanden sind.') : ''}</p>`;
  }
  const draftKey = () => JSON.stringify([order.id, task.id]);
  function persist(nextDraft, remove = false, evidence = null) {
    const operations = app().operations;
    const drafts = { ...operations.evidenceDrafts };
    if (remove) delete drafts[draftKey()];
    else drafts[draftKey()] = { ...nextDraft, step, updatedAt: new Date().toISOString() };
    const audit = evidence ? [{ id: 'LOG-' + crypto.randomUUID(), action: 'Created operational evidence in ASTRA', detail: `${evidence.fileName} · ${order.id}`, time: evidence.createdAt, user: app().settings.user }, ...(operations.audit || [])] : operations.audit;
    const next = { ...operations, evidenceDrafts: drafts, evidence: evidence ? [evidence, ...operations.evidence] : operations.evidence, audit };
    try { localStorage.setItem(storageKey, JSON.stringify(next)); }
    catch { body.querySelector('[data-editor-error]').textContent = text('Could not save. Browser storage may be full; your open draft is still available.', 'Speichern fehlgeschlagen. Möglicherweise ist der Browserspeicher voll; der geöffnete Entwurf bleibt verfügbar.'); return false; }
    Object.assign(operations, next);
    return true;
  }
  function field(name, label, type = 'text', required = true) {
    const value = escapeHtml(draft[name]);
    return `<label class="field ${type === 'textarea' ? 'evidence-field-wide' : ''}">${escapeHtml(label)}${required ? ' *' : ''}${type === 'textarea' ? `<textarea name="${name}" rows="4" ${required ? 'required' : ''}>${value}</textarea>` : `<input name="${name}" type="${type}" value="${value}" ${required ? 'required' : ''}>`}</label>`;
  }
  function collect() {
    const form = body.querySelector('form');
    if (!form) return;
    for (const input of form.querySelectorAll('[name]')) draft[input.name] = input.type === 'checkbox' ? input.checked : input.value;
  }
  function documentContent() {
    const template = profile();
    const rows = [
      [text('Order', 'Auftrag'), order.id], [text('Order name', 'Auftragsname'), order.name],
      [text('Customer', 'Kunde'), order.customer], [text('Site', 'Standort'), order.site],
      [text('Purchase order', 'Bestellung'), order.po], [text('Component', 'Bauteil'), task.componentId],
      [text('Task', 'Arbeitsschritt'), task.title], ...(task.clauses?.length ? [[text('Addresses', 'Bezieht sich auf'), task.clauses.map(refLabel).join('\n')]] : []), [text('Prepared by', 'Erstellt von'), draft.author],
      [text('Record date', 'Protokolldatum'), draft.date],
      ...template.fields.map(([name, english, german]) => [text(english, german), draft[name]]),
      [text('Assessment', 'Bewertung'), draft.assessment === 'conforming' ? text('Reported conforming; pending review', 'Als konform berichtet; Prüfung ausstehend') : draft.assessment === 'nonconforming' ? text('Nonconforming / action required', 'Nicht konform / Maßnahme erforderlich') : text('Incomplete / not assessed', 'Unvollständig / nicht bewertet')],
      [text('Open issues / reviewer notes', 'Offene Punkte / Prüfhinweise'), draft.notes]
    ];
    return `<article class="authored-document"><p class="document-watermark">${text('DEMO · INTERNAL OPERATIONAL RECORD · NOT A SUPPLIER-ISSUED CERTIFICATE', 'DEMO · INTERNES BETRIEBSPROTOKOLL · KEIN LIEFERANTENZEUGNIS')}</p><h2>${escapeHtml(translated(template.title))}</h2><p>${text('Prepared in ASTRA. Awaiting authorized MIRA review. This document does not grant certification or replace original third-party evidence.', 'In ASTRA erstellt. Autorisierte MIRA-Prüfung ausstehend. Dieses Dokument erteilt keine Zertifizierung und ersetzt keine Originalnachweise Dritter.')}</p><dl>${rows.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value || text('Not provided', 'Nicht angegeben'))}</dd></div>`).join('')}</dl><h3>${text('Review checklist', 'Prüfliste')}</h3><ul>${template.checks.map((label, index) => `<li>${draft['check' + index] ? text('Checked', 'Geprüft') : text('Open', 'Offen')}: ${escapeHtml(translated(label))}</li>`).join('')}</ul><p>${text('Prefill: ASTRA order/component data. Assistance: local rule-based demo suggestion, no connected AI model. Factual results entered by the preparer; independent review required.', 'Vorausfüllung: ASTRA-Auftrags-/Bauteildaten. Unterstützung: lokaler regelbasierter Demovorschlag, kein verbundenes KI-Modell. Sachliche Ergebnisse durch erstellende Person erfasst; unabhängige Prüfung erforderlich.')}</p></article>`;
  }
  function validate() {
    const form = body.querySelector('form');
    if (!form.reportValidity()) return false;
    const blank = [...form.querySelectorAll('[required]:not([type="checkbox"])')].find(input => !input.value.trim());
    if (blank) { blank.focus(); return false; }
    return true;
  }
  function render() {
    const template = profile();
    const steps = [text('Context', 'Kontext'), text('Record details', 'Protokolldetails'), text('Checks & findings', 'Prüfung & Befunde'), text('Preview & submit', 'Vorschau & Einreichen')];
    dialog.querySelector('#evidence-editor-title').textContent = translated(template.title);
    const close = dialog.querySelector('.evidence-editor-close');
    close.textContent = '×';
    close.setAttribute('aria-label', text('Close and keep draft', 'Schließen und Entwurf behalten'));
    let content = '';
    if (step === 0) {
      const context = [[text('Order', 'Auftrag'), order.id], [text('Customer', 'Kunde'), order.customer], [text('Site', 'Standort'), order.site], [text('Component', 'Bauteil'), task.componentId], [text('Purchase order', 'Bestellung'), order.po], [text('Task', 'Arbeitsschritt'), task.title]];
      content = `<p class="audit-prefill-note">${text('Prefilled from ASTRA operational data. Certificate references, material grades, batch numbers and test results are never invented.', 'Aus ASTRA-Betriebsdaten vorausgefüllt. Zeugnisreferenzen, Werkstoffgüten, Chargennummern und Prüfergebnisse werden niemals erfunden.')}</p><div class="audit-launch-summary">${context.map(([label, value]) => `<div><small>${escapeHtml(label)}</small><strong>${escapeHtml(value || text('Not available', 'Nicht verfügbar'))}</strong></div>`).join('')}</div><p>${escapeHtml(translated(template.instruction))}</p>${clauseBlock()}<label class="audit-guide-confirm"><input type="checkbox" name="contextConfirmed" required ${draft.contextConfirmed ? 'checked' : ''}>${text('I confirm this order, component and task are the intended scope.', 'Ich bestätige Auftrag, Bauteil und Arbeitsschritt als vorgesehenen Umfang.')}</label>`;
    }
    if (step === 1) content = `<p>${escapeHtml(translated(template.instruction))}</p><div class="form-grid">${field('author', text('Prepared by', 'Erstellt von'))}${field('date', text('Record date', 'Protokolldatum'), 'date')}${template.fields.map(([name, english, german, type]) => field(name, text(english, german), type || 'text')).join('')}</div>`;
    if (step === 2) content = `<div class="evidence-assistance"><h4>${text('AI-style preparation suggestion · Demo rules', 'KI-ähnlicher Vorbereitungsvorschlag · Demoregeln')}</h4><p>${text('Based on this task type, compare the source records with the component and document any exceptions. No AI service is connected and no factual test values are generated.', 'Auf Basis dieses Arbeitsschritttyps Quellnachweise mit dem Bauteil vergleichen und Abweichungen dokumentieren. Kein KI-Dienst verbunden; keine Erzeugung sachlicher Prüfwerte.')}</p><button type="button" class="button secondary" data-use-suggestion>${text('Insert review prompts', 'Prüfhinweise einfügen')}</button></div><fieldset class="evidence-checks"><legend>${text('Record completed checks; leave unperformed checks open', 'Durchgeführte Prüfungen erfassen; nicht durchgeführte offen lassen')}</legend>${template.checks.map((label, index) => `<label class="audit-guide-confirm"><input type="checkbox" name="check${index}" ${draft['check' + index] ? 'checked' : ''}>${escapeHtml(translated(label))}</label>`).join('')}</fieldset><div class="form-grid"><label class="field">${text('Assessment', 'Bewertung')}<select name="assessment"><option value="incomplete" ${draft.assessment === 'incomplete' ? 'selected' : ''}>${text('Incomplete / not assessed', 'Unvollständig / nicht bewertet')}</option><option value="conforming" ${draft.assessment === 'conforming' ? 'selected' : ''}>${text('Reported conforming', 'Als konform berichtet')}</option><option value="nonconforming" ${draft.assessment === 'nonconforming' ? 'selected' : ''}>${text('Nonconforming / action required', 'Nicht konform / Maßnahme erforderlich')}</option></select></label>${field('notes', text('Open issues / reviewer notes', 'Offene Punkte / Prüfhinweise'), 'textarea', false)}</div><p class="audit-prefill-note">${text('Your assessment is not an approval. The task remains open until MIRA review; failed or incomplete findings must be resolved.', 'Ihre Bewertung ist keine Freigabe. Der Arbeitsschritt bleibt bis zur MIRA-Prüfung offen; fehlerhafte oder unvollständige Befunde müssen geklärt werden.')}</p>`;
    if (step === 3) content = `${completenessHtml()}${documentContent()}<label class="audit-guide-confirm"><input type="checkbox" name="submissionConfirmed" required ${draft.submissionConfirmed ? 'checked' : ''}>${text('I confirm this record reflects the available source evidence and requires authorized review.', 'Ich bestätige, dass das Protokoll die verfügbaren Quellnachweise wiedergibt und autorisiert geprüft werden muss.')}</label>`;
    body.innerHTML = `<ol class="audit-stepper evidence-stepper" aria-label="${text('Evidence creation steps', 'Schritte der Nachweiserstellung')}">${steps.map((label, index) => `<li ${index === step ? 'aria-current="step"' : ''} class="${index < step ? 'complete' : ''}"><span>${index + 1}</span>${escapeHtml(label)}</li>`).join('')}</ol><h3 tabindex="-1" data-editor-heading>${steps[step]}</h3><form id="evidence-editor-form">${content}<p role="alert" class="evidence-editor-error" data-editor-error></p><div class="evidence-editor-navigation"><span>${text('Step', 'Schritt')} ${step + 1} / 4</span><div><button class="button text" type="button" data-save-draft>${text('Save draft & close', 'Entwurf speichern & schließen')}</button><button class="button secondary" type="button" data-editor-back ${step === 0 ? 'disabled' : ''}>${text('Back', 'Zurück')}</button><button class="button primary" type="submit">${step === 3 ? text('Submit for review', 'Zur Prüfung einreichen') : text('Continue', 'Weiter')}</button></div></div></form>`;
    body.querySelector('[data-save-draft]').addEventListener('click', closeEditor);
    body.querySelector('[data-editor-back]').addEventListener('click', () => { collect(); if (!persist(draft)) return; step = Math.max(0, step - 1); render(); focusHeading(); });
    body.querySelector('[data-use-suggestion]')?.addEventListener('click', () => {
      collect();
      const suggestion = text('Review prompts (not findings): ', 'Prüfhinweise (keine Befunde): ') + template.checks.map(translated).join(' ');
      if (!draft.notes.includes(suggestion)) draft.notes = [draft.notes, suggestion].filter(Boolean).join('\n');
      body.querySelector('[name="notes"]').value = draft.notes;
      draft.assistanceSource = 'Local rule-based demo suggestion; no connected AI service';
    });
    body.querySelector('form').addEventListener('submit', event => {
      event.preventDefault();
      if (!validate()) return;
      collect();
      if (step === 2 && task.virtual && (draft.assessment === 'incomplete' || template.checks.some((label, index) => !draft['check' + index]))) {
        body.querySelector('[data-editor-error]').textContent = text('Complete every check and choose conforming or nonconforming before continuing.', 'Alle Prüfungen durchführen und konform oder nicht konform wählen, bevor Sie fortfahren.');
        return;
      }
      if (step === 2 && draft.assessment === 'conforming' && template.checks.some((label, index) => !draft['check' + index])) {
        body.querySelector('[data-editor-error]').textContent = text('Complete all checks before reporting conformity, or select incomplete / nonconforming.', 'Vor einer Konformitätsbewertung alle Prüfungen durchführen oder unvollständig / nicht konform wählen.');
        return;
      }
      if (step < 3) { if (!persist(draft)) return; step++; render(); focusHeading(); return; }
      submit();
    });
  }
  function focusHeading() { body.scrollTop = 0; body.querySelector('[data-editor-heading]')?.focus(); }
  function closeEditor() {
    if (!completed) { collect(); if (!persist(draft)) return; }
    dialog.close();
  }
  function submit() {
    if (!draft.contextConfirmed || !draft.submissionConfirmed) return;
    if (task.virtual && completeness().percent < 100) { body.querySelector('[data-editor-error]').textContent = text('Required content is incomplete.', 'Pflichtinhalte sind unvollständig.'); return; }
    const now = new Date().toISOString();
    const id = 'EV-' + crypto.randomUUID();
    const fileName = `${task.kind}-${id}.html`;
    const html = `<!doctype html><html lang="${app().settings.language === 'de' ? 'de' : 'en'}"><head><meta charset="utf-8"><title>${escapeHtml(translated(profile().title))}</title><style>body{font:14px sans-serif;line-height:1.6;max-width:900px;margin:32px auto;padding:16px;color:#1d2722}h2{font-size:22px}dt{font-weight:bold}dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}dl>div{padding:8px 0;border-bottom:1px solid #ddd}.document-watermark{font-weight:bold;color:#7a4220}@media print{body{margin:0}}</style></head><body>${documentContent()}<p>${escapeHtml(id)} · ${escapeHtml(now)}</p></body></html>`;
    const bytes = new TextEncoder().encode(html);
    const base64 = btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join(''));
    const record = {
      id, orderId: order.id, componentId: task.componentId, kind: task.kind, title: translated(profile().title), fileName,
      mimeType: 'text/html', size: bytes.length, dataUrl: 'data:text/html;base64,' + base64,
      status: 'submitted', createdAt: now, createdBy: app().settings.user, origin: 'astra-authored', addresses: task.clauses || null,
      documentType: 'Internal operational evidence record; not an original third-party certificate',
      result: draft.assessment === 'nonconforming' ? 'Fail' : draft.assessment === 'conforming' ? 'Pass' : 'Incomplete',
      authoredData: { ...draft, orderId: order.id, taskId: task.id, componentId: task.componentId },
      provenance: { prefilledFrom: 'ASTRA operational data', suggestions: draft.assistanceSource || 'None used', factualValues: 'Entered by preparer; not generated by AI' }
    };
    if (!persist(draft, true, record)) return;
    completed = true;
    app().render();
    document.dispatchEvent(new Event('demov2:evidence-changed'));
    body.innerHTML = `<div class="audit-modal-confirmation"><span class="tag">${text('Awaiting review', 'Prüfung ausstehend')}</span><h3>${text('Evidence created in ASTRA', 'Nachweis in ASTRA erstellt')}</h3><p>${escapeHtml(record.title)} · ${escapeHtml(order.id)} · ${escapeHtml(task.componentId)}</p><p>${text('The document is linked to this task and available to MIRA. No evidence was automatically approved.', 'Das Dokument ist mit dem Arbeitsschritt verknüpft und in MIRA verfügbar. Kein Nachweis wurde automatisch freigegeben.')}</p><div class="evidence-complete-actions"><button type="button" class="button secondary" data-download-record>${text('Download document', 'Dokument herunterladen')}</button><button type="button" class="button primary" data-close-editor>${text('Return to task', 'Zurück zum Arbeitsschritt')}</button></div></div>`;
    body.querySelector('[data-download-record]').addEventListener('click', () => { const link = document.createElement('a'); link.href = record.dataUrl; link.download = record.fileName; link.click(); });
    body.querySelector('[data-close-editor]').addEventListener('click', closeEditor);
    body.scrollTop = 0;
    body.querySelector('[data-close-editor]').focus();
  }
  function decorate(currentOrder) {
    document.querySelectorAll('.task-row [data-upload-task]').forEach(upload => {
      if (upload.closest('.task-evidence-actions')) return;
      const currentTask = currentOrder.tasks.find(item => item.id === upload.dataset.uploadTask);
      if (!currentTask) return;
      const actions = document.createElement('div');
      actions.className = 'task-evidence-actions';
      upload.before(actions);
      const create = document.createElement('button');
      create.type = 'button';
      create.className = 'button secondary';
      create.dataset.createEvidence = currentTask.id;
      create.dataset.orderId = currentOrder.id;
      create.textContent = app().operations.evidenceDrafts?.[JSON.stringify([currentOrder.id, currentTask.id])] ? text('Resume draft', 'Entwurf fortsetzen') : text('Create in ASTRA', 'In ASTRA erstellen');
      upload.textContent = text('Upload file', 'Datei hochladen');
      actions.append(create, upload);
    });
  }
  function start(targetOrder, targetTask, trigger) {
    order = targetOrder;
    task = targetTask;
    opener = trigger;
    completed = false;
    const existing = app().operations.evidenceDrafts?.[draftKey()];
    draft = existing ? { ...existing } : { author: app().settings.user, date: new Date().toISOString().slice(0, 10), notes: '', assessment: 'incomplete', contextConfirmed: false, submissionConfirmed: false };
    step = existing ? Math.min(Math.max(existing.step || 0, 0), 3) : 0;
    render();
    document.body.classList.add('audit-modal-open');
    dialog.showModal();
    focusHeading();
  }
  function open(orderId, taskId, trigger) {
    const targetOrder = app().operations.orders.find(item => item.id === orderId);
    const targetTask = targetOrder?.tasks.find(item => item.id === taskId);
    if (targetTask) start(targetOrder, targetTask, trigger);
  }
  function openFor(spec, trigger) {
    const targetOrder = app().operations.orders.find(item => item.id === spec.orderId);
    if (!targetOrder || !spec.kind) return;
    start(targetOrder, { id: 'GAP-' + spec.kind + '-' + (spec.componentId || ''), title: spec.title, kind: spec.kind, componentId: spec.componentId || targetOrder.componentIds[0], virtual: true, clauses: spec.clauses || [] }, trigger);
  }
  document.addEventListener('click', event => {
    const trigger = event.target.closest('[data-create-evidence]');
    if (trigger) open(trigger.dataset.orderId, trigger.dataset.createEvidence, trigger);
  });
  dialog.querySelector('.evidence-editor-close').addEventListener('click', closeEditor);
  dialog.addEventListener('cancel', event => { event.preventDefault(); closeEditor(); });
  dialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); closeEditor(); } });
  dialog.addEventListener('close', () => {
    if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open');
    app().render();
    const trigger = [...document.querySelectorAll('[data-create-evidence]')].find(item => item.dataset.createEvidence === task.id);
    (trigger || (opener?.isConnected ? opener : null))?.focus();
  });
  window.DemoV2Evidence = { decorate, open, openFor };
  app().operations.orders.forEach(decorate);
})();