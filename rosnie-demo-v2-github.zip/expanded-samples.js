(() => {
  const keys = ['rosnie-demo-v2-operations-v1', 'rosnie-demo-v2-compliance-v1', 'rosnie-demo-v2-settings-v1'];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  function seed() {
    const app = window.DemoV2;
    const helpers = window.DemoV2Auditors;
    const library = window.DemoV2Library;
    const modal = window.DemoV2AuditModalInternals;
    if (!app || !helpers || !modal || app.operations.expandedSamplesV1) return;
    const operations = structuredClone(app.operations);
    const compliance = structuredClone(app.compliance);
    const settings = structuredClone(app.settings);
    const now = new Date().toISOString();
    const definitions = [
      ['Nordstahl Anlagenbau GmbH (demo)', 'Dortmund Fabrication Workshop', 'Boiler support frame', 'steel', 14, 'High'],
      ['Rheinland Process Systems (demo)', 'Dortmund Fabrication Workshop', 'Pressure vessel skid', 'steel', 28, 'Medium'],
      ['Hanse Bulk Handling (demo)', 'North Workshop', 'Transfer chute relining', 'wear', 7, 'High'],
      ['Bergwerk Service GmbH (demo)', 'North Workshop', 'Crusher liner replacement', 'wear', 21, 'Medium'],
      ['Elbe Bioenergie GmbH (demo)', 'Rheinpark Biomass CHP Plant', 'Fuel conveyor overhaul', 'steel', 35, 'Medium'],
      ['Alpen Fernwaerme AG (demo)', 'Rheinpark Biomass CHP Plant', 'Heat exchanger maintenance', 'final', 10, 'High'],
      ['Nordstahl Anlagenbau GmbH (demo)', 'Hamburg Assembly Centre (demo)', 'Loading gantry assembly', 'steel', 42, 'Low'],
      ['Hanse Bulk Handling (demo)', 'Hamburg Assembly Centre (demo)', 'Port conveyor acceptance', 'final', 16, 'Medium'],
      ['Westfalen Recycling GmbH (demo)', 'Essen Recovery Plant (demo)', 'Sorting drum refurbishment', 'wear', 25, 'Medium'],
      ['Westfalen Recycling GmbH (demo)', 'Essen Recovery Plant (demo)', 'Emission monitoring service', 'monitoring', 5, 'Critical'],
      ['Baltic Utilities GmbH (demo)', 'Kiel Service Depot (demo)', 'Pump station refurbishment', 'final', 32, 'Medium'],
      ['Baltic Utilities GmbH (demo)', 'Kiel Service Depot (demo)', 'Metering equipment inspection', 'monitoring', 18, 'Low']
    ];
    const workflows = {
      steel: ['material-certificate', 'wps', 'wpqr', 'welding-record', 'inspection-report', 'ndt-report', 'release-package'],
      wear: ['material-certificate', 'surface-preparation', 'lining-application', 'coating-inspection', 'inspection-report', 'release-package'],
      final: ['material-certificate', 'traceability-record', 'inspection-report', 'calibration-certificate', 'release-package'],
      monitoring: ['calibration-certificate', 'operation-check', 'inspection-report', 'release-package']
    };
    const titles = { 'surface-preparation': 'Surface preparation record', 'lining-application': 'Lining application record', 'coating-inspection': 'Coating inspection record' };
    const label = kind => library.kinds[kind]?.label[0] || titles[kind] || kind;
    const newOrders = [];
    function addEvidence(order, kind, status, reference, source, title = label(kind)) {
      const id = 'EV-EXP-' + reference;
      if (operations.evidence.some(record => record.id === id)) return;
      const createdAt = helpers.inDays(-10) + 'T10:00:00Z';
      const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{font:14px/1.6 sans-serif;max-width:820px;margin:32px auto;padding:20px;color:#26342b}dt{font-weight:bold}dd{margin:0 0 12px;overflow-wrap:anywhere}.mark{color:#956222;font-weight:bold}</style></head><body><p class="mark">FICTIONAL DEMO DOCUMENT - NOT FOR CERTIFICATION OR OPERATIONAL USE</p><h1>${esc(title)}</h1><dl><dt>Reference</dt><dd>${esc(reference)}</dd><dt>Customer</dt><dd>${esc(order.customer)}</dd><dt>Site</dt><dd>${esc(order.site)}</dd><dt>Order / component</dt><dd>${esc(order.id)} / ${esc(order.componentIds[0])}</dd><dt>Illustrative source</dt><dd>${esc(source)} - sample attachment, not a live integration</dd><dt>Scope</dt><dd>${esc(order.name)}</dd><dt>Sample review finding</dt><dd>Illustrative documentation assembled for this order. References and source authenticity require verification in a real audit. No actual measurements or third-party certificate are represented.</dd><dt>Demo status</dt><dd>${esc(status)}</dd></dl><p>All names, identifiers, content and recorded reviews in this document are demonstration data.</p></body></html>`;
      const bytes = new TextEncoder().encode(html);
      operations.evidence.push({ id, orderId: order.id, componentId: order.componentIds[0], kind, title: title + ' (sample)', fileName: reference + '-sample.html', mimeType: 'text/html', size: bytes.length, dataUrl: 'data:text/html;base64,' + btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join('')), status, result: status === 'approved' ? 'Pass' : 'Incomplete', createdAt, createdBy: 'Demo sample preparation', sample: true, provenance: { source: 'Fictional demo attachment', illustrativeSystem: source, notLiveIntegration: true }, ...(status === 'approved' ? { verifiedAt: createdAt } : {}) });
      if (status === 'approved') compliance.verifiedBy.push({ id: 'VERIFY-' + id, evidenceId: id, user: 'Anna Weber (demo reviewer)', time: createdAt });
    }
    definitions.forEach(([customer, site, name, workflow, offset, priority], index) => {
      const id = 'ASTRA-DEMO-EXP-' + String(index + 1).padStart(3, '0');
      if (operations.orders.some(order => order.id === id)) return;
      const componentId = 'COMP-EXP-' + String(index + 1).padStart(3, '0');
      const kinds = workflows[workflow];
      const ready = index === 1 || index === 6 || index === 10;
      const pendingIndex = index === 3 || index === 8 ? kinds.length - 2 : -1;
      const missingIndex = ready ? -1 : kinds.length - 1;
      const order = { id, customer, site, name: name + ' (demo)', po: 'PO-DEMO-' + String(index + 1).padStart(4, '0'), delivery: helpers.inDays(offset), priority, projectType: workflow === 'steel' ? 'Steel Fabrication' : workflow === 'wear' ? 'Wear Protection' : 'Maintenance Project', componentIds: [componentId], componentDescription: name, sample: true, tasks: kinds.map((kind, taskIndex) => ({ id: 'TASK-' + id + '-' + taskIndex, title: label(kind), kind, componentId, workflow, requiresReview: true, done: taskIndex !== missingIndex && taskIndex !== pendingIndex })) };
      operations.orders.push(order);
      newOrders.push(order);
      kinds.forEach((kind, taskIndex) => {
        if (taskIndex === missingIndex) return;
        const source = kind === 'material-certificate' ? 'SAP / ERP goods receipt' : ['wps', 'wpqr', 'calibration-certificate'].includes(kind) ? 'SharePoint controlled records' : 'ASTRA operational record';
        addEvidence(order, kind, taskIndex === pendingIndex ? 'submitted' : 'approved', 'EXP-' + (index + 1) + '-' + taskIndex, source);
      });
    });
    const baseOrder = operations.orders.find(order => order.id === 'ASTRA-2026-001');
    const documents = [
      ['controlled-document', 'Management system scope and process map', 'SharePoint'],
      ['competence-record', 'Annual competence and training matrix', 'SAP / HR'],
      ['legal-register', 'Site obligations and permit review', 'SharePoint'],
      ['internal-audit-report', 'Supplier process internal audit report', 'SharePoint'],
      ['management-review', 'Quarterly management review minutes', 'SharePoint'],
      ['corrective-action', 'Closed corrective action effectiveness check', 'ASTRA'],
      ['energy-data', 'Monthly energy baseline comparison', 'Data Lake export'],
      ['access-review', 'Contractor access recertification review', 'IT system export']
    ];
    if (baseOrder) documents.forEach(([kind, title, source], index) => addEvidence(baseOrder, kind, 'approved', 'ORG-EXP-' + index, source, title));
    const merge = (key, values) => { const existing = settings.masterData[key] || []; settings.masterData[key] = [...existing, ...values.filter(value => !existing.includes(value))]; };
    merge('customers', definitions.map(row => row[0]).filter((value, index, values) => values.indexOf(value) === index));
    merge('sites', definitions.map(row => row[1]).filter((value, index, values) => values.indexOf(value) === index));
    merge('assets', newOrders.flatMap(order => order.componentIds));
    merge('materials', ['S235JR (demo)', 'S355J2+N (demo)', '1.4301 stainless (demo)', 'Hardfacing wire (demo)', 'Ceramic liner (demo)']);
    merge('suppliers', ['Nordblech Supplies (demo)', 'Rhein Weld Consumables (demo)', 'Baltic Calibration Services (demo)', 'Alpen Protective Linings (demo)']);
    merge('employees', ['Eva Schneider (demo)', 'Lukas Meyer (demo)', 'Marta Nowak (demo)', 'Daniel Hoffmann (demo)', 'Sven Petersen (demo)']);
    merge('reportTemplates', ['Site audit readiness (demo)', 'Evidence source register (demo)', 'Open actions by customer (demo)']);
    merge('documentTemplates', ['Calibration evidence cover sheet (demo)', 'Supplier record review (demo)', 'Site monitoring summary (demo)']);
    const catalogue = modal.catalogue();
    catalogue.forEach((entry, index) => {
      const id = 'AUDIT-DEMO-EXP-' + String(index + 1).padStart(3, '0');
      if (compliance.audits.some(audit => audit.id === id)) return;
      const order = newOrders[index % newOrders.length];
      if (!order) return;
      const directory = helpers.directory[index % helpers.directory.length];
      const personal = index % 4 === 0;
      const auditor = personal ? settings.user : directory.name;
      const offset = [6, 13, 22, 35, 48, 65][index % 6];
      const records = operations.evidence.filter(record => record.orderId === order.id);
      const hold = index === 7 || index === 13 || index === 17;
      const audit = { id, catalogId: entry.id, title: entry.name, framework: entry.name, type: ['Regulation', 'Permit condition'].includes(entry.type) ? 'Regulatory compliance review' : 'Certification readiness review', version: entry.version, source: entry.source, site: order.site, orderIds: [order.id], componentIds: order.componentIds.slice(), plannedDate: helpers.inDays(offset), status: hold ? 'On hold' : 'Planned', auditor, sample: true, createdAt: helpers.inDays(-20) + 'T09:00:00Z', createdBy: 'Expanded demo samples', notes: 'Fictional audit engagement and contract; not a real certification decision.', evidenceIds: records.map(record => record.id), evidenceSnapshot: records.map(({ dataUrl, ...record }) => record), missingEvidence: [], pendingEvidence: [], controlIds: [], reviews: {}, requests: [], history: [], assignedAuditor: { id: personal ? 'DEMO-CURRENT-AUDITOR' : directory.id, name: auditor, firm: personal ? 'ROSNIE Demo Audit Practice' : directory.firm, dayRate: directory.dayRate, days: 2, cost: directory.dayRate * 2, assignedAt: now, assignedBy: 'Demo sample data' }, contract: { reference: 'DEMO-EXP-CTR-' + (index + 1), customer: order.customer, start: helpers.inDays(-15), end: helpers.inDays(offset + 25), status: index % 5 === 0 ? 'proposed' : 'agreed', fee: String(directory.dayRate * 2), signer: auditor, sample: true } };
      if (hold) {
        const profile = library.checklist(entry);
        const clause = profile.clauses[0];
        audit.requests.push({ id: id + '-REQUEST', standard: profile.standard, ref: clause.ref, title: clause.title, kind: clause.evidence[0].kind, note: 'Demo request: provide the signed source document and clarify its scope for this customer and site.', due: helpers.inDays(10), status: 'open', createdAt: now, createdBy: auditor });
        audit.decision = { state: 'hold', note: 'Demo hold pending customer source documentation.', by: auditor, at: now, sample: true, exceptions: 0 };
      }
      compliance.audits.push(audit);
    });
    operations.physicalAI ||= { running: true, devices: {}, alerts: [] };
    operations.physicalAI.customDevices ||= [];
    const sensorExamples = [[9, 'EXP-SNS-EMISSION', 'Recovery plant dust monitor', 'Dust concentration', 10, 'mg/m3', 'ISO 14001', '9.1.1'], [11, 'EXP-SNS-METER', 'Service depot meter monitor', 'Equipment temperature', 70, 'deg C', 'ISO 9001', '7.1.5']];
    sensorExamples.forEach(([orderIndex, id, name, measure, max, unit, standard, ref]) => {
      const order = newOrders[orderIndex];
      if (!order || operations.physicalAI.customDevices.some(device => device.id === id)) return;
      operations.physicalAI.customDevices.push({ id, name: [name + ' (demo)', name + ' (demo)'], site: order.site, orderId: order.id, componentId: order.componentIds[0], protocol: 'MQTT', kind: 'operation-check', max, unit, label: [measure, measure], limit: [`Illustrative demo upper limit: ${max} ${unit}`, `Beispielhafter Demo-Grenzwert: ${max} ${unit}`], title: [name + ' record (demo)', name + ' record (demo)'], caveat: ['Simulated measurements, not an actual permit or calibrated device.', 'Simulierte Messwerte, keine tatsächliche Genehmigung oder kalibriertes Gerät.'], targets: [[standard, ref, [measure + ' monitoring (demo)', measure + ' monitoring (demo)']]] });
    });
    const meteringSensor = operations.physicalAI.customDevices.find(device => device.id === 'EXP-SNS-METER');
    if (meteringSensor) meteringSensor.kind = 'inspection-report';
    operations.expandedSamplesV1 = true;
    const previous = keys.map(key => localStorage.getItem(key));
    try {
      [operations, compliance, settings].forEach((value, index) => localStorage.setItem(keys[index], JSON.stringify(value)));
    } catch {
      keys.forEach((key, index) => { try { if (previous[index] === null) localStorage.removeItem(key); else localStorage.setItem(key, previous[index]); } catch {} });
      return;
    }
    Object.assign(app.operations, operations);
    Object.assign(app.compliance, compliance);
    Object.assign(app.settings, settings);
    operations.physicalAI.customDevices.filter(device => device.id.startsWith('EXP-SNS-')).forEach(device => {
      window.DemoV2PhysicalAI?.registerSample(device);
    });
    app.render();
  }
  document.addEventListener('DOMContentLoaded', seed);
})();