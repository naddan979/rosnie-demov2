(() => {
  const app = () => window.DemoV2;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const certOf = requirement => requirement.framework.split(' · ')[0];
  const kindLabel = kind => { const item = window.DemoV2Library?.kinds[kind]; return item ? text(item.label[0], item.label[1]) : kind.replaceAll('-', ' '); };
  const when = value => value ? new Date(value).toLocaleString(app().settings.language === 'de' ? 'de-DE' : 'en-GB') : '—';

  const dialog = document.createElement('dialog');
  dialog.id = 'auditor-package-dialog';
  dialog.className = 'audit-modal auditor-package';
  dialog.setAttribute('aria-labelledby', 'auditor-package-title');
  dialog.innerHTML = '<header class="audit-modal-header"><div><small>MIRA</small><h2 id="auditor-package-title"></h2></div><button class="button secondary evidence-editor-close" type="button"></button></header><div class="audit-modal-body" id="auditor-package-body"></div>';
  document.body.append(dialog);
  const body = dialog.querySelector('#auditor-package-body');
  let scope = { cert: 'all', site: 'all' };
  let opener;

  function sourceOf(record) {
    if (record.origin === 'sensor-captured') return `${text('Live connection', 'Live-Verbindung')} ${record.deviceId}`;
    if (record.origin === 'astra-authored') return text('Created in ASTRA', 'In ASTRA erstellt');
    return text('Uploaded or sample file', 'Hochgeladene Datei oder Beispieldatei');
  }
  function verification(record) {
    if (record.status !== 'approved') return record.result === 'Fail' ? text('Deviation: not verifiable', 'Abweichung: nicht verifizierbar') : text('Not yet verified', 'Noch nicht verifiziert');
    const entry = app().compliance.verifiedBy.find(item => item.evidenceId === record.id);
    return entry ? `${entry.user} · ${when(entry.time)}` : text('Sample data: no verification record', 'Beispieldaten: kein Verifizierungsnachweis');
  }
  function build() {
    const { operations, compliance } = app();
    const orders = operations.orders.filter(order => scope.site === 'all' || order.site === scope.site);
    const orderIds = new Set(orders.map(order => order.id));
    const requirements = compliance.requirements.filter(requirement => scope.cert === 'all' || certOf(requirement) === scope.cert);
    const open = (window.DemoV2MiraExtras?.openItems() || []).filter(item => (scope.cert === 'all' || item.certification === scope.cert) && orderIds.has(item.order.id));
    let total = 0;
    let verified = 0;
    const sections = requirements.map(requirement => {
      const state = app().readiness(requirement);
      const relevant = state.orders.filter(order => orderIds.has(order.id));
      if (!relevant.length) return '';
      const records = state.related.filter(record => orderIds.has(record.orderId));
      let pairs = 0;
      let done = 0;
      for (const order of relevant) for (const kind of requirement.kinds) {
        if (!order.tasks.some(task => task.kind === kind)) continue;
        pairs++;
        if (records.some(record => record.orderId === order.id && record.kind === kind && record.status === 'approved')) done++;
      }
      total += pairs;
      verified += done;
      const rows = records.map(record => `<tr><td>${esc(record.title)}<br><small>${esc(kindLabel(record.kind))}</small></td><td>${esc(record.orderId)}<br><small>${esc(record.componentId)}</small></td><td>${esc(sourceOf(record))}</td><td>${esc(record.createdBy || '—')}<br><small>${esc(when(record.createdAt))}</small></td><td>${esc(verification(record))}</td></tr>`).join('');
      return `<section><h3>${esc(requirement.title)}</h3><p class="meta">${esc(requirement.framework)} · ${esc(requirement.id)} · ${esc(text('Sites', 'Standorte'))}: ${esc([...new Set(relevant.map(order => order.site))].join(', '))} · ${done}/${pairs} ${esc(text('evidence items verified', 'Nachweise verifiziert'))}</p>${rows ? `<table><thead><tr><th>${esc(text('Evidence', 'Nachweis'))}</th><th>${esc(text('Order / component', 'Auftrag / Bauteil'))}</th><th>${esc(text('Source', 'Quelle'))}</th><th>${esc(text('Captured by / at', 'Erfasst von / am'))}</th><th>${esc(text('Verification', 'Verifizierung'))}</th></tr></thead><tbody>${rows}</tbody></table>` : `<p>${esc(text('No evidence recorded yet.', 'Noch kein Nachweis erfasst.'))}</p>`}</section>`;
    }).join('');
    const label = text('DEMO AUDITOR PACKAGE · SAMPLE DATA · NOT A CERTIFICATION DECISION', 'DEMO-AUDITORENPAKET · BEISPIELDATEN · KEINE ZERTIFIZIERUNGSENTSCHEIDUNG');
    const openRows = open.map(item => `<tr><td>${esc(kindLabel(item.kind))}</td><td>${esc(item.certification)}</td><td>${esc(item.order.site)}</td><td>${esc(item.order.id)} · ${esc(item.order.componentIds[0])}</td><td>${esc({ missing: text('Missing', 'Fehlt'), awaiting: text('Awaiting verification', 'Verifizierung ausstehend'), deviation: text('Deviation', 'Abweichung'), collecting: text('Collecting', 'Wird erfasst') }[item.status])}</td></tr>`).join('');
    return `<!doctype html><html lang="${app().settings.language === 'de' ? 'de' : 'en'}"><head><meta charset="utf-8"><title>${esc(text('Auditor package', 'Auditorenpaket'))}</title><style>body{font:13px/1.55 "Segoe UI",sans-serif;color:#1d2722;margin:0;padding:24px}h1{font-size:22px;margin:4px 0}h2{font-size:15px;margin:26px 0 8px}h3{font-size:13px;margin:18px 0 2px}.mark{font-weight:700;color:#7a4220;font-size:11px}.meta,small{color:#59655e;font-size:11px}table{width:100%;border-collapse:collapse;margin:6px 0 4px;table-layout:fixed}th,td{border:1px solid #d8ddd5;padding:6px 8px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#f1f4ef;font-size:11px}.summary{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}.summary div{border:1px solid #d8ddd5;border-radius:6px;padding:8px 12px;min-width:120px}.summary strong{display:block;font-size:18px}@media print{body{padding:0}section{break-inside:avoid}}</style></head><body><p class="mark">${esc(label)}</p><h1>${esc(text('Auditor package', 'Auditorenpaket'))}</h1><p class="meta">${esc(text('Certification', 'Zertifizierung'))}: ${esc(scope.cert === 'all' ? text('All', 'Alle') : scope.cert)} · ${esc(text('Site', 'Standort'))}: ${esc(scope.site === 'all' ? text('All sites', 'Alle Standorte') : scope.site)} · ${esc(text('Generated', 'Erstellt'))}: ${esc(when(new Date().toISOString()))} · ${esc(app().settings.user)}</p><div class="summary"><div><small>${esc(text('Evidence items', 'Nachweise'))}</small><strong>${total}</strong></div><div><small>${esc(text('Verified', 'Verifiziert'))}</small><strong>${verified}</strong></div><div><small>${esc(text('Still open', 'Noch offen'))}</small><strong>${open.length}</strong></div></div><h2>${esc(text('Open items before approval', 'Offene Punkte vor der Freigabe'))}</h2>${openRows ? `<table><thead><tr><th>${esc(text('Evidence', 'Nachweis'))}</th><th>${esc(text('Certification', 'Zertifizierung'))}</th><th>${esc(text('Site', 'Standort'))}</th><th>${esc(text('Order / component', 'Auftrag / Bauteil'))}</th><th>${esc(text('Status', 'Status'))}</th></tr></thead><tbody>${openRows}</tbody></table>` : `<p>${esc(text('Nothing open for this scope.', 'F\u00fcr diesen Umfang ist nichts offen.'))}</p>`}<h2>${esc(text('Requirements and evidence', 'Anforderungen und Nachweise'))}</h2>${sections || `<p>${esc(text('No requirements apply to this scope.', 'F\u00fcr diesen Umfang gelten keine Anforderungen.'))}</p>`}<h2>${esc(text('Limitations', 'Einschr\u00e4nkungen'))}</h2><p>${esc(text('This is a demo snapshot. Live connection data is simulated. Evidence listed as verified was verified by the named person in the demo. Formal approval is decided by the auditor or certification body.', 'Dies ist ein Demo-Auszug. Live-Verbindungsdaten sind simuliert. Als verifiziert aufgef\u00fchrte Nachweise wurden in der Demo von der genannten Person verifiziert. Die formale Freigabe entscheidet der Auditor bzw. die Zertifizierungsstelle.'))}</p></body></html>`;
  }
  function render() {
    const certs = [...new Set(app().compliance.requirements.map(certOf))];
    const sites = [...new Set(app().operations.orders.map(order => order.site))];
    dialog.querySelector('#auditor-package-title').textContent = text('Auditor package', 'Auditorenpaket');
    const close = dialog.querySelector('.evidence-editor-close');
    close.textContent = '\u00d7';
    close.setAttribute('aria-label', text('Close', 'Schlie\u00dfen'));
    body.innerHTML = `<div class="package-controls"><label class="field">${text('Certification', 'Zertifizierung')}<select data-package-cert><option value="all">${text('All', 'Alle')}</option>${certs.map(item => `<option value="${esc(item)}" ${scope.cert === item ? 'selected' : ''}>${esc(item)}</option>`).join('')}</select></label><label class="field">${text('Site', 'Standort')}<select data-package-site><option value="all">${text('All sites', 'Alle Standorte')}</option>${sites.map(item => `<option value="${esc(item)}" ${scope.site === item ? 'selected' : ''}>${esc(item)}</option>`).join('')}</select></label><div class="package-actions"><button class="button primary" type="button" data-package-print>${text('Print / save as PDF', 'Drucken / als PDF speichern')}</button><button class="button secondary" type="button" data-package-download>${text('Download HTML', 'HTML herunterladen')}</button></div></div><iframe class="package-frame" title="${text('Auditor package preview', 'Vorschau Auditorenpaket')}" data-package-frame sandbox="allow-modals allow-same-origin"></iframe>`;
    body.querySelector('[data-package-frame]').srcdoc = build();
    body.querySelector('[data-package-cert]').addEventListener('change', event => { scope.cert = event.target.value; render(); });
    body.querySelector('[data-package-site]').addEventListener('change', event => { scope.site = event.target.value; render(); });
    body.querySelector('[data-package-print]').addEventListener('click', () => { const frame = body.querySelector('[data-package-frame]').contentWindow; frame.focus(); frame.print(); });
    body.querySelector('[data-package-download]').addEventListener('click', () => {
      const blob = new Blob([build()], { type: 'text/html' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'auditor-package-demo.html';
      link.click();
      setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    });
  }
  function open(options = {}, trigger) {
    scope = { cert: options.cert || 'all', site: options.site || 'all' };
    opener = trigger;
    render();
    document.body.classList.add('audit-modal-open');
    dialog.showModal();
    dialog.querySelector('[data-package-cert]').focus();
  }
  dialog.querySelector('.evidence-editor-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); dialog.close(); } });
  dialog.addEventListener('close', () => {
    if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open');
    if (opener?.isConnected) opener.focus();
  });
  document.addEventListener('click', event => {
    const trigger = event.target.closest('[data-open-package]');
    if (trigger) open({}, trigger);
  });
  window.DemoV2AuditorPackage = { open, build: (options = {}) => { scope = { cert: options.cert || 'all', site: options.site || 'all' }; return build(); } };
})();
