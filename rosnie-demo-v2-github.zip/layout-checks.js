window.runDemoV2LayoutChecks = function () {
  const issues = [];
  const selectors = [
    '.order-row', '.task-row', '.evidence-row', '.mira-bridge',
    '.compliance-overview', '.heading-row', '.section-head', '.topbar',
    '.form-grid', '.audit-register-row', '.settings-content',
    '.audit-modal-entry', '.audit-modal-filters', '.audit-launch-summary',
    '.audit-stepper', '.audit-guide-content', '.audit-guide-navigation',
    '.audit-guide-totals', '.audit-recommendations', '.audit-recommendation',
    '.task-evidence-actions', '.evidence-editor-navigation', '.authored-document',
    '.evidence-assistance', '.evidence-complete-actions',
    '.physical-ai', '.physical-ai-summary', '.physical-ai-grid', '.physical-ai-card', '.physical-ai-reading',
    '.physical-ai-card-foot', '.physical-ai-lower', '.physical-ai-alert', '.physical-ai-links > div',
    '.requirements-panel > .section-head', '.mira-tabs', '.tour-banner', '.tour-actions', '.package-controls',
    '.mode-switch', '.av-picker', '.av-audit', '.av-meters', '.av-request', '.av-decision-buttons', '.trace-chain > li', '.auditor-card', '.auditor-facts > div', '.audit-modal-entry', '.audit-row-extra', '.open-items', '.open-item', '.requirement-scope',
    '.portfolio-summary', '.portfolio-filters', '.portfolio-row', '.portfolio-actions', '.portfolio-context',
    '.audit-clause', '.audit-clause > header', '.audit-clause-item', '.audit-gap', '.audit-gap-choose', '.evidence-clauses'
  ];
  const tolerance = 2;
  const visible = element => {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== 'hidden';
  };
  for (const selector of selectors) {
    for (const element of document.querySelectorAll(selector)) {
      if (!visible(element)) continue;
      const bounds = element.getBoundingClientRect();
      const children = [...element.children].filter(child => visible(child) && !child.classList.contains('sr-only'));
      if (element.scrollWidth > element.clientWidth + tolerance) {
        issues.push({ selector, kind: 'horizontal overflow', width: element.clientWidth, contentWidth: element.scrollWidth });
      }
      for (const child of children) {
        const rect = child.getBoundingClientRect();
        if (rect.left < bounds.left - tolerance || rect.right > bounds.right + tolerance || rect.top < bounds.top - tolerance || rect.bottom > bounds.bottom + tolerance) {
          issues.push({ selector, kind: 'child outside container', child: child.className || child.tagName });
        }
      }
      for (let first = 0; first < children.length; first++) {
        for (let second = first + 1; second < children.length; second++) {
          const left = children[first].getBoundingClientRect();
          const right = children[second].getBoundingClientRect();
          if (Math.min(left.right, right.right) - Math.max(left.left, right.left) > tolerance && Math.min(left.bottom, right.bottom) - Math.max(left.top, right.top) > tolerance) {
            issues.push({ selector, kind: 'overlapping siblings', children: [children[first].className, children[second].className] });
          }
        }
      }
    }
  }
  if (document.documentElement.scrollWidth > innerWidth + tolerance) {
    issues.push({ kind: 'document horizontal overflow', width: innerWidth, contentWidth: document.documentElement.scrollWidth });
  }
  for (const modal of document.querySelectorAll('#audit-catalog-dialog[open], #evidence-editor-dialog[open]')) {
    const rect = modal.getBoundingClientRect();
    const body = modal.querySelector('.audit-modal-body');
    if (rect.left < 0 || rect.right > innerWidth + tolerance || rect.top < 0 || rect.bottom > innerHeight + tolerance || body.scrollWidth > body.clientWidth + tolerance) {
      issues.push({ kind: 'audit modal outside viewport or overflowing' });
    }
  }
  return { passed: issues.length === 0, viewport: { width: innerWidth, height: innerHeight }, issues };
};