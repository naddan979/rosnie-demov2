(() => {
  const OPS_KEY = 'rosnie-demo-v2-operations-v1';
  const SETTINGS_KEY = 'rosnie-demo-v2-settings-v1';
  const INTEGRATION = 'Site sensors & cameras (edge gateway)';
  const TICK_MS = 1000;
  const SAVE_MS = 8000;
  const SAMPLES = 60;
  const MIN_READINGS = 5;
  const reviewers = ['Quality Manager', 'Compliance Manager', 'Auditor', 'Administrator'];
  const app = () => window.DemoV2;
  const route = () => new URL(location.href).searchParams.get('workspace') || 'astra';
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const tx = pair => text(pair[0], pair[1]);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const makeId = prefix => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

  const devices = [
    { id: 'CAM-WELD-01', type: 'camera', name: ['Weld seam vision camera', 'Schweißnaht-Kamera'], site: 'Dortmund Fabrication Workshop', protocol: 'RTSP + edge vision model', kind: 'inspection-report', rule: 'camera', scene: 'weld', nominal: 97, label: ['Seam acceptance score', 'Nahtbewertung'], unit: '%', limit: ['No flagged surface indication', 'Keine markierte Oberflächenauffälligkeit'], title: ['Visual weld seam scan record (camera)', 'Sichtprüfprotokoll Schweißnaht (Kamera)'], caveat: ['AI-assisted visual screening supports, but does not replace, qualified NDT or visual-testing personnel.', 'KI-gestützte Sichtprüfung unterstützt, ersetzt aber nicht qualifiziertes ZfP- oder Sichtprüfpersonal.'] },
    { id: 'SNS-WELD-01', type: 'sensor', name: ['Weld parameter sensor', 'Schweißparameter-Sensor'], site: 'Dortmund Fabrication Workshop', protocol: 'OPC UA', kind: 'welding-record', nominal: 190, spread: 6, max: 250, label: ['Interpass temperature', 'Zwischenlagentemperatur'], unit: '°C', limit: ['Maximum 250 °C (illustrative WPS value)', 'Maximal 250 °C (beispielhafter WPS-Wert)'], title: ['Welding parameter monitoring record', 'Schweißparameter-Überwachungsprotokoll'], caveat: ['Compare limits with the approved WPS; this demo value is illustrative.', 'Grenzwerte mit der freigegebenen WPS abgleichen; dieser Demowert ist beispielhaft.'] },
    { id: 'SNS-ENV-01', type: 'sensor', name: ['Consumable storage climate sensor', 'Klimasensor Zusatzwerkstofflager'], site: 'North Workshop', protocol: 'MQTT', kind: 'operation-check', nominal: 42, spread: 1.2, max: 60, label: ['Relative humidity', 'Relative Luftfeuchte'], unit: '% RH', limit: ['Maximum 60 % RH (illustrative)', 'Maximal 60 % rF (beispielhaft)'], title: ['Storage condition monitoring record', 'Lagerbedingungs-Überwachungsprotokoll'], caveat: ['Use the limits specified for the actual consumable.', 'Die für den tatsächlichen Zusatzwerkstoff festgelegten Grenzwerte verwenden.'] },
    { id: 'SNS-EMIS-01', type: 'sensor', name: ['Stack dust emission sensor', 'Staubemissionssensor Kamin'], site: 'Rheinpark Biomass CHP Plant', protocol: 'OPC UA', kind: 'operation-check', nominal: 4.2, spread: 0.3, max: 10, label: ['Dust concentration', 'Staubkonzentration'], unit: 'mg/m³', limit: ['Maximum 10 mg/m³ (illustrative, not a permit value)', 'Maximal 10 mg/m³ (beispielhaft, kein Genehmigungswert)'], title: ['Emission monitoring record', 'Emissions-Überwachungsprotokoll'], caveat: ['Permit limits and measurement methods must come from the actual permit.', 'Genehmigungsgrenzwerte und Messverfahren müssen aus der tatsächlichen Genehmigung stammen.'] },
    { id: 'CAM-GATE-01', type: 'camera', name: ['Gate tag-reading camera', 'Tor-Kamera Kennzeichnungserkennung'], site: 'Rheinpark Biomass CHP Plant', protocol: 'RTSP + edge vision model', kind: 'traceability-record', rule: 'camera', scene: 'tag', nominal: 99, label: ['Component tag match', 'Bauteilkennzeichnung-Übereinstimmung'], unit: '%', limit: ['Tag matches the ASTRA component', 'Kennzeichnung entspricht dem ASTRA-Bauteil'], title: ['Component identification record (camera)', 'Bauteilidentifikationsprotokoll (Kamera)'], caveat: ['A tag match supports traceability checks; a responsible person still confirms release.', 'Eine Kennzeichnungsübereinstimmung unterstützt die Rückverfolgbarkeit; die Freigabe bestätigt weiterhin eine verantwortliche Person.'] }
  ];

  const rt = {};
  const events = [];
  const config = { randomDeviations: false };
  let dirty = false;
  let lastSave = 0;
  let storageError = false;
  let scanCounter = 0;
  let lastTickTime = 0;
  let timer;
  let leader = !navigator.locks;

  const state = () => (app().operations.physicalAI ||= { running: true, devices: {}, alerts: [] });
  const reviewer = () => reviewers.includes(app().settings.role);
  const integrationOn = () => app().settings.integrations.find(item => item.name === INTEGRATION)?.enabled !== false;
  const running = () => state().running !== false && integrationOn() && !storageError;
  const connected = device => state().devices[device.id]?.connected !== false;
  const windowFor = device => app().operations.evidence.find(record => record.origin === 'sensor-captured' && record.deviceId === device.id && record.status === 'submitted');
  const deviceName = device => tx(device.name);
  const fmt = (device, value) => device.rule === 'camera' ? String(Math.round(value)) : Number(value).toFixed(device.max && device.max < 10 ? 2 : 1);

  function link(device) {
    if (device.orderId) {
      const pinned = app().operations.orders.find(order => order.id === device.orderId);
      if (pinned) return { orderId: pinned.id, componentId: device.componentId || pinned.componentIds[0] };
    }
    const orders = app().operations.orders.filter(order => order.site === device.site);
    const order = orders.find(item => item.tasks.some(task => !task.done)) || orders[0];
    return order ? { orderId: order.id, componentId: order.componentIds[0] } : null;
  }
  function requirementsFor(device, orderId) {
    return app().compliance.requirements.filter(item => item.kinds.includes(device.kind) && item.appliesTo.includes(orderId));
  }
  function persist() {
    if (window.__demoResetting) return true;
    try {
      localStorage.setItem(OPS_KEY, JSON.stringify(app().operations));
      lastSave = Date.now();
      dirty = false;
      return true;
    } catch {
      storageError = true;
      return false;
    }
  }
  function addEvent(device, message, tone = '') {
    events.unshift({ time: new Date(), device: device ? device.id : 'ASTRA', message, tone });
    events.length = Math.min(events.length, 8);
  }
  function log(action, detail) {
    app().operations.audit.unshift({ id: makeId('LOG'), time: new Date().toISOString(), user: app().settings.user, action, detail });
  }

  function documentHtml(device, record) {
    const tl = record.telemetry;
    const avg = tl.count ? tl.sum / tl.count : 0;
    const status = record.status === 'superseded' ? text('Closed after deviation review', 'Nach Abweichungsprüfung geschlossen') : record.result === 'Fail' ? text('Deviation detected; not eligible for verification', 'Abweichung erkannt; nicht zur Verifizierung geeignet') : text('Within rule; awaiting authorized human verification', 'Innerhalb der Regel; autorisierte Verifizierung ausstehend');
    const rows = [
      [text('Device', 'Gerät'), `${device.id} · ${deviceName(device)}`], [text('Protocol', 'Protokoll'), device.protocol],
      [text('Site', 'Standort'), device.site], [text('ASTRA order', 'ASTRA-Auftrag'), record.orderId], [text('Component', 'Bauteil'), record.componentId],
      [text('Window start', 'Fensterbeginn'), tl.startedAt], [text('Last reading', 'Letzter Messwert'), tl.lastAt || '—'],
      [device.rule === 'camera' ? text('Scans', 'Scans') : text('Readings', 'Messwerte'), tl.count], [tx(device.label), device.rule === 'camera' ? `${text('average', 'Mittel')} ${fmt(device, avg)} ${device.unit}` : `${text('min', 'min')} ${fmt(device, tl.min ?? 0)} / ${text('avg', 'Mittel')} ${fmt(device, avg)} / ${text('max', 'max')} ${fmt(device, tl.max ?? 0)} ${device.unit}`],
      [text('Rule', 'Regel'), tx(device.limit)], [text('Deviations', 'Abweichungen'), tl.exceedances.length ? tl.exceedances.map(item => `${item.t} · ${fmt(device, item.value)} ${device.unit}`).join('\n') : text('None', 'Keine')],
      [text('Status', 'Status'), status]
    ];
    return `<!doctype html><html lang="${app().settings.language === 'de' ? 'de' : 'en'}"><head><meta charset="utf-8"><title>${esc(tx(device.title))}</title><style>body{font:14px sans-serif;line-height:1.6;max-width:900px;margin:32px auto;padding:16px;color:#1d2722}dt{font-weight:bold}dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}dl>div{padding:8px 0;border-bottom:1px solid #ddd}.mark{font-weight:bold;color:#7a4220}</style></head><body><p class="mark">${text('DEMO · SIMULATED FEED GENERATED IN THE BROWSER · NOT FROM PHYSICAL DEVICES', 'DEMO · SIMULIERTER DATENSTROM IM BROWSER ERZEUGT · NICHT VON PHYSISCHEN GERÄTEN')}</p><h2>${esc(tx(device.title))}</h2><dl>${rows.map(([label, value]) => `<div><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`).join('')}</dl><p>${esc(tx(device.caveat))}</p><p>${text('Machine-captured data. It is not approved evidence until an authorized reviewer verifies it in MIRA.', 'Maschinell erfasste Daten. Sie sind erst nach Verifizierung durch autorisierte Personen in MIRA freigegebener Nachweis.')}</p></body></html>`;
  }
  function refresh(record) {
    const device = devices.find(item => item.id === record.deviceId);
    if (!device) return;
    const bytes = new TextEncoder().encode(documentHtml(device, record));
    record.size = bytes.length;
    record.dataUrl = 'data:text/html;base64,' + btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join(''));
    record.title = tx(device.title);
  }
  function openWindow(device, target) {
    const now = new Date().toISOString();
    const record = {
      id: 'EV-LIVE-' + device.id + '-' + Date.now().toString(36), orderId: target.orderId, componentId: target.componentId, kind: device.kind,
      title: tx(device.title), fileName: `${device.id}-live-record.html`, mimeType: 'text/html', size: 0, dataUrl: '', status: 'submitted',
      createdAt: now, createdBy: 'Edge gateway · ' + device.id, origin: 'sensor-captured', deviceId: device.id, result: 'Incomplete',
      documentType: 'Machine-captured site monitoring record; not an approved certificate',
      telemetry: { count: 0, sum: 0, min: null, max: null, startedAt: now, lastAt: null, exceedances: [] },
      provenance: { source: 'SIMULATED demo feed generated in the browser', protocol: device.protocol, humanVerification: 'Required in MIRA' }
    };
    refresh(record);
    app().operations.evidence.unshift(record);
    log('Live site evidence window opened', `${device.id} · ${target.orderId}`);
    addEvent(device, text('Evidence window opened and linked to ', 'Nachweisfenster geöffnet und verknüpft mit ') + target.orderId);
    return record;
  }
  function read(device, runtime) {
    const forced = runtime.force;
    runtime.force = false;
    if (device.rule === 'camera') {
      scanCounter++;
      const flagged = forced || (config.randomDeviations && Math.random() < 0.015);
      const value = flagged ? 38 + Math.random() * 20 : device.nominal - Math.random() * 2.5;
      return { value, exceeded: flagged };
    }
    runtime.t = (runtime.t || 0) + 1;
    const t = runtime.t;
    const noise = scale => (Math.random() - 0.5) * scale;
    let value;
    if (device.id === 'SNS-WELD-01') {
      const cycle = t % 45;
      value = 172 + 38 * (cycle < 12 ? cycle / 12 : Math.exp(-(cycle - 12) / 10)) + noise(3);
    } else if (device.id === 'SNS-ENV-01') {
      runtime.drift = (runtime.drift || 0) * 0.98 + noise(0.25);
      value = 41 + 3 * Math.sin(t / 55) + runtime.drift + noise(0.3);
    } else if (device.id === 'SNS-EMIS-01') {
      const phase = t % 90;
      value = 4.1 + 0.5 * Math.sin(t / 22) + (phase > 84 ? 1.8 * Math.sin((phase - 84) / 6 * Math.PI) : 0) + noise(0.35);
    } else {
      runtime.value += (device.nominal - runtime.value) * 0.25 + noise(2 * device.spread);
      value = runtime.value + 0.5 * device.spread * Math.sin(t / 20);
    }
    value = forced ? device.max * 1.08 : Math.min(value, device.max * 0.98);
    if (forced) runtime.value = device.nominal;
    return { value, exceeded: value > device.max };
  }
  function raiseAlert(device, record, reading) {
    const alerts = state().alerts;
    alerts.unshift({ id: makeId('ALERT'), deviceId: device.id, recordId: record.id, time: new Date().toISOString(), value: reading.value, status: 'open' });
    alerts.splice(40);
    log('Live site deviation detected', `${device.id} · ${record.orderId}`);
    addEvent(device, text('Deviation detected; window blocked from verification', 'Abweichung erkannt; Fenster für Verifizierung gesperrt'), 'red');
  }
  function sampleDevice(device) {
    const runtime = rt[device.id] ||= { value: device.nominal, history: [], force: false, last: null };
    if (!connected(device)) return false;
    const target = link(device);
    if (!target) return false;
    const reading = read(device, runtime);
    runtime.last = reading;
    runtime.history.push(reading.value);
    (runtime.times ||= []).push(performance.now());
    if (runtime.history.length > SAMPLES) { runtime.history.shift(); runtime.times.shift(); }
    let structural = false;
    let record = windowFor(device);
    if (!record) { record = openWindow(device, target); structural = true; }
    const tl = record.telemetry;
    tl.count++;
    tl.sum += reading.value;
    tl.min = tl.min === null ? reading.value : Math.min(tl.min, reading.value);
    tl.max = tl.max === null ? reading.value : Math.max(tl.max, reading.value);
    tl.lastAt = new Date().toISOString();
    if (record.result === 'Incomplete' && tl.count >= MIN_READINGS) { record.result = 'Pass'; structural = true; }
    if (reading.exceeded) {
      tl.exceedances.push({ t: tl.lastAt, value: reading.value });
      tl.exceedances.splice(20);
      if (record.result !== 'Fail') { record.result = 'Fail'; raiseAlert(device, record, reading); structural = true; }
    }
    dirty = true;
    return structural;
  }
  function flush() {
    for (const device of devices) { const record = windowFor(device); if (record) refresh(record); }
    persist();
  }
  function canRerender() {
    const active = document.activeElement;
    return !document.querySelector('dialog[open]') && !(active && active.matches('input, textarea, select'));
  }
  function rerender() {
    if (!canRerender() || route() === 'settings') return;
    const page = document.querySelector('#page-scroll');
    const top = page ? page.scrollTop : 0;
    const windowTop = window.scrollY;
    app().render();
    if (page) page.scrollTop = top;
    window.scrollTo(0, windowTop);
  }

  function scene(device) {
    return `<canvas data-live-canvas="camera" data-device="${esc(device.id)}" role="img" aria-label="${esc(tx(device.name))} · ${text('simulated live view', 'simulierte Live-Ansicht')}"></canvas>`;
  }
  function spark(device) {
    return `<canvas data-live-canvas="chart" data-device="${esc(device.id)}" role="img" aria-label="${esc(tx(device.label))} · ${text('live chart', 'Live-Diagramm')}"></canvas>`;
  }
  function legacyScene(device, flagged) {
    const x = (scanCounter * 17) % 160;
    const color = flagged ? '#e05a47' : '#6fcf97';
    if (device.scene === 'tag') {
      const label = flagged ? 'ASTRA-XX-000' : (app().operations.orders.find(order => order.site === device.site && order.tasks.some(task => !task.done))?.componentIds[0] || 'ASTRA');
      return `<svg viewBox="0 0 240 110" role="img" aria-label="${text('Simulated camera frame', 'Simulierter Kamerabildausschnitt')}"><rect width="240" height="110" fill="#2b3430"/><rect x="40" y="30" width="160" height="50" rx="3" fill="#59655e"/><text x="120" y="61" text-anchor="middle" fill="#e8ede7" font-size="14" font-family="monospace">${esc(label)}</text><rect x="34" y="24" width="172" height="62" fill="none" stroke="${color}" stroke-width="2"/><text x="8" y="14" fill="#c9d3cc" font-size="8">SIMULATED</text></svg>`;
    }
    return `<svg viewBox="0 0 240 110" role="img" aria-label="${text('Simulated camera frame', 'Simulierter Kamerabildausschnitt')}"><rect width="240" height="110" fill="#2b3430"/><rect y="40" width="240" height="36" fill="#46524b"/><path d="M0 58q15-8 30 0t30 0 30 0 30 0 30 0 30 0 30 0 30 0" stroke="#c9b27a" stroke-width="9" fill="none" stroke-linecap="round"/><rect x="${x}" y="32" width="64" height="52" fill="none" stroke="${color}" stroke-width="2"/><text x="8" y="14" fill="#c9d3cc" font-size="8">SIMULATED</text></svg>`;
  }
  function legacySpark(device, values) {
    if (!values.length) return '';
    let high = Math.max(...values, device.max || 0);
    const low = Math.min(...values);
    if (high === low) high = low + 1;
    const y = value => (34 - ((value - low) / (high - low)) * 30).toFixed(1);
    const points = values.map((value, index) => `${(index / Math.max(SAMPLES - 1, 1) * 118 + 1).toFixed(1)},${y(value)}`).join(' ');
    const limit = device.max ? `<line x1="0" x2="120" y1="${y(device.max)}" y2="${y(device.max)}" stroke="#a3483c" stroke-dasharray="3 3"/>` : '';
    return `<svg viewBox="0 0 120 36" preserveAspectRatio="none" role="img" aria-label="${text('Recent readings', 'Letzte Messwerte')}">${limit}<polyline points="${points}" fill="none" stroke="#285f4a" stroke-width="1.6"/></svg>`;
  }
  function statusFor(device) {
    const record = windowFor(device);
    if (!running() || !connected(device)) return { tone: '', label: !connected(device) ? text('Disconnected', 'Getrennt') : text('Paused', 'Pausiert') };
    if (!record) return { tone: '', label: text('Waiting for data', 'Warte auf Daten') };
    if (record.result === 'Fail') return { tone: 'red', label: text('Deviation', 'Abweichung') };
    if (record.result === 'Incomplete') return { tone: 'amber', label: `${text('Collecting', 'Erfasst')} ${record.telemetry.count}/${MIN_READINGS}` };
    return { tone: 'amber', label: text('Ready for verification', 'Bereit zur Verifizierung') };
  }
  function cardHtml(device) {
    const target = link(device);
    const record = windowFor(device);
    const requirements = target ? requirementsFor(device, target.orderId) : [];
    const status = statusFor(device);
    const last = rt[device.id]?.last;
    const history = rt[device.id]?.history || [];
    const canVerify = reviewer() && record && record.result === 'Pass';
    return `<article class="physical-ai-card" data-device-card="${device.id}"><div class="physical-ai-card-top"><div><span class="tag">${device.type === 'camera' ? text('Camera', 'Kamera') : text('Sensor', 'Sensor')}</span><h3>${esc(deviceName(device))}</h3><small>${esc(device.id)} · ${esc(device.site)} · ${esc(device.protocol)}</small></div><label class="physical-ai-connect"><input class="toggle" type="checkbox" data-pai-connect="${device.id}" ${connected(device) ? 'checked' : ''} ${reviewer() ? '' : 'disabled'} aria-label="${esc(text('Connected', 'Verbunden'))}: ${esc(deviceName(device))}"></label></div>${device.type === 'camera' ? `<div class="physical-ai-frame" data-live-frame="${device.id}">${scene(device, last?.exceeded)}</div>` : ''}<div class="physical-ai-reading"><div><small>${esc(tx(device.label))}</small><strong data-live-value="${device.id}">${last ? esc(fmt(device, last.value)) + ' ' + esc(device.unit) : '—'}</strong></div><div class="physical-ai-spark" data-live-spark="${device.id}">${spark(device, history)}</div></div><p class="physical-ai-rule">${esc(tx(device.limit))}</p><dl class="physical-ai-links"><div><dt>ASTRA</dt><dd>${target ? esc(target.orderId + ' · ' + target.componentId) : '—'}</dd></div><div><dt>${text('Evidence for', 'Nachweis für')}</dt><dd class="source-chips">${targetsHtml(device)}</dd></div><div><dt>MIRA</dt><dd>${requirements.length ? requirements.map(item => esc(item.title)).join(', ') : esc(text('Stored as supporting ASTRA evidence; no MIRA requirement is mapped in this demo.', 'Als ergänzender ASTRA-Nachweis gespeichert; in dieser Demo ist keine MIRA-Anforderung zugeordnet.'))}</dd></div></dl><div class="physical-ai-card-foot"><span class="tag ${status.tone}" data-live-state="${device.id}">${esc(status.label)}</span><span class="physical-ai-actions">${canVerify ? `<button class="button secondary" type="button" data-action="verify-evidence" data-evidence-id="${esc(record.id)}">${text('Verify window', 'Fenster verifizieren')}</button>` : ''}<button class="button text" type="button" data-pai-deviation="${device.id}" ${running() && connected(device) ? '' : 'disabled'}>${text('Simulate deviation', 'Abweichung simulieren')}</button></span></div></article>`;
  }
  function alertsHtml() {
    const open = state().alerts.filter(item => item.status === 'open');
    if (!open.length) return `<p class="physical-ai-empty">${text('No open deviations.', 'Keine offenen Abweichungen.')}</p>`;
    return open.map(item => {
      const device = devices.find(entry => entry.id === item.deviceId);
      if (!device) return '';
      const detail = device.rule === 'camera' ? text('Visual indication flagged', 'Visuelle Auffälligkeit markiert') : `${tx(device.label)} ${fmt(device, item.value)} ${device.unit}`;
      return `<form class="physical-ai-alert" data-pai-resolve="${esc(item.id)}"><strong>${esc(deviceName(device))}</strong><small>${esc(detail)} · ${new Date(item.time).toLocaleTimeString()}</small>${reviewer() ? `<label class="field">${text('Corrective action note', 'Notiz zur Korrekturmaßnahme')}<input name="note" required minlength="5" maxlength="200"></label><button class="button secondary" type="submit">${text('Close window with note', 'Fenster mit Notiz schließen')}</button>` : `<small>${text('A reviewer role must resolve this deviation.', 'Diese Abweichung muss durch eine Prüfrolle geklärt werden.')}</small>`}</form>`;
    }).join('');
  }
  function eventsHtml() {
    if (!events.length) return `<p class="physical-ai-empty">${text('Waiting for first device data.', 'Warte auf erste Gerätedaten.')}</p>`;
    return events.map(item => `<li class="${item.tone}"><time>${item.time.toLocaleTimeString()}</time><span><strong>${esc(item.device)}</strong> ${esc(item.message)}</span></li>`).join('');
  }
  function summary() {
    const records = app().operations.evidence.filter(record => record.origin === 'sensor-captured');
    const online = devices.filter(connected).length;
    const readings = records.reduce((sum, record) => sum + (record.telemetry?.count || 0), 0);
    const waiting = records.filter(record => record.status === 'submitted' && record.result === 'Pass' && record.telemetry.count >= MIN_READINGS).length;
    return { online: running() ? online : 0, readings, waiting, open: state().alerts.filter(item => item.status === 'open').length };
  }
  function targetsHtml(device) {
    const targets = device.targets || window.DemoV2Library?.deviceTargets[device.id] || [];
    return targets.map(([standard, ref, title]) => `<span class="source-chip clause">${esc(standard)} ${/^\d/.test(ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')}${esc(ref)} · ${esc(tx(title))}</span>`).join('');
  }
  function connectorsHtml() {
    const lib = window.DemoV2Library;
    if (!lib) return '';
    const cards = ['sap', 'sharepoint', 'datalake'].map(id => {
      const source = lib.sources[id];
      const enabled = app().settings.integrations.find(item => item.name === source.integration)?.enabled;
      const used = lib.usedBy(id);
      return `<article class="physical-ai-card"><div class="physical-ai-card-top"><div><span class="tag">${text('Data source', 'Datenquelle')}</span><h3>${esc(tx(source.name))}</h3><small>${esc(source.integration)}</small></div><span class="tag ${enabled ? 'green' : ''}">${enabled ? text('Connected (demo)', 'Verbunden (Demo)') : text('Off in Settings', 'In Einstellungen aus')}</span></div><p class="physical-ai-rule">${esc(tx(source.supplies))}</p><dl class="physical-ai-links"><div><dt>${text('Evidence for', 'Nachweis für')}</dt><dd class="source-chips">${used.slice(0, 5).map(([standard, ref, title]) => `<span class="source-chip clause">${esc(standard)} ${/^(\d|A\.)/.test(ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')}${esc(ref)}</span>`).join('')}${used.length > 5 ? `<span class="source-chip">+${used.length - 5}</span>` : ''}</dd></div></dl><p class="physical-ai-rule">${text('Demo connector: sample catalogue only, no live synchronization. Evidence is attached through ASTRA or upload.', 'Demo-Konnektor: nur Beispielkatalog, keine Live-Synchronisation. Nachweise werden über ASTRA oder Upload zugeordnet.')}</p></article>`;
    }).join('');
    return `<div class="physical-ai-lower" style="display:block"><h3>${text('Data source connectors', 'Datenquellen-Konnektoren')}</h3><div class="physical-ai-grid">${cards}</div></div>`;
  }
  function panelHtml() {
    const sum = summary();
    return `<section class="physical-ai" id="physical-ai-panel" aria-labelledby="physical-ai-title"><div class="section-head"><div><p class="heading-kicker">${text('Live connections', 'Live-Verbindungen')}</p><h2 id="physical-ai-title">${text('Connected cameras and sensors', 'Verbundene Kameras und Sensoren')}</h2><p>${text('Each connection streams into MIRA, is linked to an ASTRA order and component, and creates evidence for the certification and clause shown. It becomes compliance evidence only after human verification.', 'Jede Verbindung liefert Daten an MIRA, wird einem ASTRA-Auftrag und Bauteil zugeordnet und erzeugt Nachweise für die angezeigte Zertifizierung und Klausel. Zum Compliance-Nachweis wird sie erst nach menschlicher Verifizierung.')}</p></div><div class="physical-ai-actions"><span class="tag amber">${text('SIMULATED FEED', 'SIMULIERTER DATENSTROM')}</span><button class="button primary" type="button" data-pai-add-device ${reviewer() ? '' : 'disabled'}>${text('Connect a device', 'Gerät verbinden')}</button><button class="button secondary" type="button" data-pai-toggle ${reviewer() ? '' : 'disabled'}>${running() ? text('Pause live capture', 'Live-Erfassung pausieren') : text('Resume live capture', 'Live-Erfassung fortsetzen')}</button></div></div><p class="physical-ai-note">${text('Demo simulation: no physical devices are connected. A production setup would use an edge gateway (for example OPC UA, MQTT or RTSP) with device authentication, calibration records and camera privacy controls. Live data is collected while this page is open.', 'Demo-Simulation: Es sind keine physischen Geräte verbunden. Ein Produktivbetrieb nutzt ein Edge-Gateway (z. B. OPC UA, MQTT oder RTSP) mit Geräteauthentifizierung, Kalibriernachweisen und Datenschutzkontrollen für Kameras. Live-Daten werden erfasst, solange diese Seite geöffnet ist.')}</p>${storageError ? `<p class="physical-ai-note physical-ai-error" role="alert">${text('Browser storage is full. Live capture is paused and no further data is saved.', 'Der Browserspeicher ist voll. Die Live-Erfassung ist pausiert; weitere Daten werden nicht gespeichert.')}</p>` : ''}<div class="physical-ai-summary"><div><small>${text('Devices online', 'Geräte online')}</small><strong data-live-sum="online">${sum.online}/${devices.length}</strong></div><div><small>${text('Readings captured', 'Erfasste Messwerte')}</small><strong data-live-sum="readings">${sum.readings}</strong></div><div><small>${text('Windows ready to verify', 'Fenster zur Verifizierung')}</small><strong data-live-sum="waiting">${sum.waiting}</strong></div><div><small>${text('Open deviations', 'Offene Abweichungen')}</small><strong data-live-sum="open">${sum.open}</strong></div></div><div class="physical-ai-grid">${devices.map(cardHtml).join('')}</div><div class="physical-ai-lower"><div><h3>${text('Live events', 'Live-Ereignisse')}</h3><ul class="physical-ai-events" data-live-events>${eventsHtml()}</ul></div><div><h3>${text('Deviations', 'Abweichungen')}</h3><div role="status" data-live-alerts data-count="${sum.open}">${alertsHtml()}</div></div></div>${connectorsHtml()}</section>`;
  }
  function decorate() {
    const content = document.querySelector('#connections-view');
    if (!content || content.querySelector('#physical-ai-panel')) return;
    content.innerHTML = panelHtml();
  }
  function replacePanel() {
    const panel = document.querySelector('#physical-ai-panel');
    if (!panel || !canRerender()) return;
    panel.outerHTML = panelHtml();
  }
  function updateLive() {
    if (!document.querySelector('#physical-ai-panel')) return;
    const sum = summary();
    const set = (selector, value) => { const node = document.querySelector(selector); if (node && node.textContent !== value) node.textContent = value; };
    set('[data-live-sum="online"]', `${sum.online}/${devices.length}`);
    set('[data-live-sum="readings"]', String(sum.readings));
    set('[data-live-sum="waiting"]', String(sum.waiting));
    set('[data-live-sum="open"]', String(sum.open));
    for (const device of devices) {
      const runtime = rt[device.id];
      if (runtime?.last) {
        set(`[data-live-value="${device.id}"]`, `${fmt(device, runtime.last.value)} ${device.unit}`);
      }
      const status = statusFor(device);
      const badge = document.querySelector(`[data-live-state="${device.id}"]`);
      if (badge) { badge.textContent = status.label; badge.className = 'tag ' + status.tone; }
    }
    const list = document.querySelector('[data-live-events]');
    if (list) list.innerHTML = eventsHtml();
    const alerts = document.querySelector('[data-live-alerts]');
    if (alerts && alerts.dataset.count !== String(sum.open) && !alerts.contains(document.activeElement)) { alerts.innerHTML = alertsHtml(); alerts.dataset.count = String(sum.open); }
  }
  function tick() {
    if (!running()) { updateLive(); return; }
    let structural = false;
    for (const device of devices) if (sampleDevice(device)) structural = true;
    lastTickTime = performance.now();
    if (structural) { flush(); if (storageError) addEvent(null, text('Storage full; capture paused', 'Speicher voll; Erfassung pausiert'), 'red'); rerender(); replacePanel(); }
    else if (dirty && Date.now() - lastSave > SAVE_MS) flush();
    updateLive();
  }
  function resolveAlert(id, note) {
    const alert = state().alerts.find(item => item.id === id && item.status === 'open');
    const record = alert && app().operations.evidence.find(item => item.id === alert.recordId);
    if (!alert || !record || !reviewer() || note.trim().length < 5) return false;
    const now = new Date().toISOString();
    alert.status = 'resolved';
    alert.resolution = { note: note.trim(), by: app().settings.user, at: now };
    record.status = 'superseded';
    record.resolution = alert.resolution;
    refresh(record);
    log('Live site deviation resolved', `${alert.deviceId} · ${note.trim()}`);
    addEvent(devices.find(device => device.id === alert.deviceId), text('Deviation window closed with corrective note; new window starts', 'Abweichungsfenster mit Korrekturnotiz geschlossen; neues Fenster beginnt'));
    persist();
    return true;
  }
  function simulateDeviation(id) {
    const device = devices.find(item => item.id === id);
    if (!device || !running()) return;
    (rt[id] ||= { value: device.nominal, history: [], force: false, last: null }).force = true;
    tick();
  }

  const connectDialog = document.createElement('dialog');
  connectDialog.id = 'connect-device-dialog';
  connectDialog.className = 'audit-modal evidence-editor connect-device';
  connectDialog.setAttribute('aria-labelledby', 'connect-device-title');
  connectDialog.innerHTML = '<header class="audit-modal-header"><div><small>MIRA</small><h2 id="connect-device-title"></h2></div><button class="button secondary evidence-editor-close" type="button"></button></header><div class="audit-modal-body" id="connect-device-body"></div>';
  document.body.append(connectDialog);
  const connectBody = connectDialog.querySelector('#connect-device-body');
  function hydrateDevice(saved) {
    return { ...saved, type: 'sensor', custom: true, nominal: saved.max * 0.7, spread: saved.max * 0.03 };
  }
  function addCustomDevice(spec) {
    if (spec.id === 'EXP-SNS-METER') {
      spec.kind = 'supporting-telemetry';
      spec.targets = [];
      spec.name = ['Equipment temperature monitor (demo)', 'Gerätetemperatur-Monitor (Demo)'];
      spec.label = ['Equipment temperature', 'Gerätetemperatur'];
      for (const record of app().operations.evidence.filter(item => item.deviceId === spec.id && item.origin === 'sensor-captured')) {
        record.originalKind ||= record.kind;
        record.kind = 'supporting-telemetry';
      }
    }
    if (spec.id === 'EXP-SNS-EMISSION') spec.label = ['Dust concentration', 'Staubkonzentration'];
    const device = hydrateDevice(spec);
    devices.push(device);
    window.DemoV2Library?.registerSource(device.kind, device.id);
    return device;
  }
  function openConnect() {
    const lib = window.DemoV2Library;
    const orders = app().operations.orders;
    const clauses = lib.allClauses();
    const field = (label, control) => `<label class="field">${esc(label)}${control}</label>`;
    connectDialog.querySelector('#connect-device-title').textContent = text('Connect a device', 'Gerät verbinden');
    const close = connectDialog.querySelector('.evidence-editor-close');
    close.textContent = '×';
    close.setAttribute('aria-label', text('Close', 'Schließen'));
    connectBody.innerHTML = `<p class="audit-prefill-note">${text('Demo wizard: no real device is contacted. It shows how a sensor is registered, tied to an order and a certification clause, and given limits from your own document. The simulated feed then produces readings for it.', 'Demo-Assistent: Es wird kein echtes Gerät kontaktiert. Er zeigt, wie ein Sensor registriert, einem Auftrag und einer Zertifizierungsklausel zugeordnet und mit Grenzwerten aus Ihrem eigenen Dokument versehen wird. Der simulierte Datenstrom liefert danach Messwerte.')}</p><form id="connect-device-form"><h3>1 · ${text('Device', 'Gerät')}</h3><div class="form-grid">${field(text('Device name', 'Gerätename'), '<input name="name" required maxlength="60">')}${field(text('Protocol', 'Protokoll'), '<select name="protocol"><option>OPC UA</option><option>MQTT</option><option>Modbus TCP</option></select>')}${field(text('What it measures', 'Was gemessen wird'), '<input name="measure" required maxlength="60">')}${field(text('Unit', 'Einheit'), '<input name="unit" required maxlength="12">')}</div><h3>2 · ${text('Where it is installed', 'Wo es installiert ist')}</h3>${field(text('ASTRA order and component', 'ASTRA-Auftrag und Bauteil'), `<select name="target">${orders.flatMap(order => order.componentIds.map(componentId => `<option value="${esc(JSON.stringify([order.id, componentId]))}">${esc(order.id + ' · ' + componentId + ' · ' + order.site)}</option>`)).join('')}</select>`)}<h3>3 · ${text('What it proves', 'Was es belegt')}</h3><div class="form-grid">${field(text('Certification clause', 'Zertifizierungsklausel'), `<select name="clause">${clauses.map(item => `<option value="${esc(item.key)}">${esc(item.standard + ' ' + (/^(\d|A\.)/.test(item.ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')) + item.ref + ' · ' + tx(item.title))}</option>`).join('')}</select>`)}${field(text('Evidence type', 'Nachweisart'), '<select name="kind"></select>')}</div><h3>4 · ${text('Limit', 'Grenzwert')}</h3><div class="form-grid">${field(text('Upper limit', 'Oberer Grenzwert'), '<input name="max" type="number" step="any" min="0.001" required>')}${field(text('Where does this limit come from?', 'Woher stammt dieser Grenzwert?'), '<input name="source" required maxlength="80">')}</div><p class="audit-prefill-note">${text('Enter the limit from your approved procedure, permit or customer specification (for example WPS number and revision). ROSNIE does not invent limits.', 'Tragen Sie den Grenzwert aus Ihrer freigegebenen Verfahrensanweisung, Genehmigung oder Kundenspezifikation ein (z. B. WPS-Nummer und Revision). ROSNIE erfindet keine Grenzwerte.')}</p><p role="alert" class="evidence-editor-error" data-connect-error></p><div class="evidence-editor-navigation"><span></span><div><button class="button text" type="button" data-connect-cancel>${text('Cancel', 'Abbrechen')}</button><button class="button primary" type="submit">${text('Connect device (simulated)', 'Gerät verbinden (simuliert)')}</button></div></div></form>`;
    const form = connectBody.querySelector('form');
    const syncKinds = () => {
      const item = clauses.find(entry => entry.key === form.elements.clause.value);
      form.elements.kind.innerHTML = [...new Set(item.kinds)].map(kind => `<option value="${kind}">${esc(tx(lib.kinds[kind].label))}</option>`).join('');
    };
    form.elements.clause.addEventListener('change', syncKinds);
    syncKinds();
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!reviewer()) return;
      const data = new FormData(form);
      const max = Number(data.get('max'));
      const error = connectBody.querySelector('[data-connect-error]');
      if (!(max > 0) || !data.get('name').trim() || !data.get('source').trim()) { error.textContent = text('Enter a name, a limit above zero and its source.', 'Namen, einen Grenzwert größer als null und dessen Quelle angeben.'); return; }
      const [orderId, componentId] = JSON.parse(data.get('target'));
      const order = app().operations.orders.find(item => item.id === orderId);
      const clause = clauses.find(item => item.key === data.get('clause'));
      const name = data.get('name').trim();
      const unit = data.get('unit').trim();
      const measure = data.get('measure').trim();
      const source = data.get('source').trim();
      let number = state().customDevices.length + 1;
      while (devices.some(item => item.id === 'CUS-' + String(number).padStart(2, '0'))) number++;
      const spec = {
        id: 'CUS-' + String(number).padStart(2, '0'), name: [name, name], site: order.site, orderId, componentId, protocol: data.get('protocol'), kind: data.get('kind'), max, unit,
        label: [measure, measure], limit: [`Maximum ${max} ${unit} (source: ${source})`, `Maximal ${max} ${unit} (Quelle: ${source})`],
        title: [`${name} monitoring record`, `${name} Überwachungsprotokoll`],
        caveat: [`The limit was entered by a user from: ${source}. Verify it against the authoritative document.`, `Der Grenzwert wurde von einer Person aus folgender Quelle eingetragen: ${source}. Anhand des maßgeblichen Dokuments prüfen.`],
        targets: [[clause.standard, clause.ref, clause.title]]
      };
      state().customDevices.push(spec);
      const device = addCustomDevice(spec);
      log('Registered live connection', `${device.id} · ${orderId}`);
      addEvent(device, text('Registered and linked to ', 'Registriert und verknüpft mit ') + orderId);
      persist();
      connectDialog.close();
      rerender();
      replacePanel();
      tick();
    });
    connectBody.querySelector('[data-connect-cancel]').addEventListener('click', () => connectDialog.close());
    document.body.classList.add('audit-modal-open');
    connectDialog.showModal();
    connectBody.querySelector('input').focus();
  }
  connectDialog.querySelector('.evidence-editor-close').addEventListener('click', () => connectDialog.close());
  connectDialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); connectDialog.close(); } });
  connectDialog.addEventListener('close', () => { if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open'); });

  document.addEventListener('click', event => {
    if (event.target.closest('[data-pai-add-device]') && reviewer()) openConnect();
    const verify = event.target.closest('[data-action="verify-evidence"]');
    if (verify) { const record = app().operations.evidence.find(item => item.id === verify.dataset.evidenceId); if (record?.origin === 'sensor-captured') flush(); }
    const toggle = event.target.closest('[data-pai-toggle]');
    if (toggle && reviewer()) {
      state().running = !running();
      if (state().running) storageError = false;
      addEvent(null, state().running ? text('Live capture resumed', 'Live-Erfassung fortgesetzt') : text('Live capture paused', 'Live-Erfassung pausiert'));
      persist();
      replacePanel();
    }
    const deviation = event.target.closest('[data-pai-deviation]');
    if (deviation) simulateDeviation(deviation.dataset.paiDeviation);
  }, true);
  document.addEventListener('change', event => {
    const input = event.target.closest('[data-pai-connect]');
    if (!input || !reviewer()) return;
    const device = devices.find(item => item.id === input.dataset.paiConnect);
    state().devices[device.id] = { connected: input.checked };
    addEvent(device, input.checked ? text('Connected', 'Verbunden') : text('Disconnected; no data is captured', 'Getrennt; keine Daten werden erfasst'));
    persist();
    replacePanel();
  });
  document.addEventListener('submit', event => {
    const form = event.target.closest('[data-pai-resolve]');
    if (!form) return;
    event.preventDefault();
    if (resolveAlert(form.dataset.paiResolve, form.elements.note.value)) { rerender(); replacePanel(); }
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden && dirty) flush(); });
  window.addEventListener('pagehide', () => { if (dirty) flush(); });

  if (!app().settings.integrations.some(item => item.name === INTEGRATION)) {
    app().settings.integrations.push({ name: INTEGRATION, enabled: true, description: 'Simulated OPC UA, MQTT and RTSP site feeds; no physical devices connected' });
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(app().settings)); } catch { /* demo settings remain in memory */ }
  }
  state();
  (state().customDevices ||= []).forEach(saved => { if (!devices.some(item => item.id === saved.id)) addCustomDevice(saved); });
  let releaseLead = null;
  function tryLead() {
    if (leader || document.hidden || !navigator.locks) return;
    navigator.locks.request('rosnie-demo-v2-physical-ai', { ifAvailable: true }, lock => {
      if (!lock) return undefined;
      leader = true;
      return new Promise(resolve => { releaseLead = () => { leader = false; releaseLead = null; resolve(); }; });
    });
  }
  function dropLead() { if (releaseLead) releaseLead(); }
  document.addEventListener('visibilitychange', () => { if (document.hidden) dropLead(); else tryLead(); });
  window.addEventListener('pagehide', dropLead);
  timer = setInterval(() => { tryLead(); if (leader && !document.hidden) tick(); }, TICK_MS);
  window.DemoV2PhysicalAI = { decorate, tick, devices, config, simulateDeviation, resolveAlert, flush, state, rt, link, TICK_MS, SAMPLES, registerSample: spec => { if (!devices.some(device => device.id === spec.id)) addCustomDevice(spec); }, getLastTick: () => lastTickTime, isLive: device => running() && connected(device), stop: () => clearInterval(timer) };
  decorate();
})();
