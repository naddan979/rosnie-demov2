(() => {
  const A = () => window.DemoV2Auditors;
  const app = () => window.DemoV2;
  const lib = () => window.DemoV2Library;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const tx = pair => text(pair[0], pair[1]);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const day = value => value ? new Date(value + 'T00:00:00').toLocaleDateString(app().settings.language === 'de' ? 'de-DE' : 'en-GB') : '\u2014';
  const mayPlan = () => ['Quality Manager', 'Compliance Manager', 'Auditor', 'Administrator'].includes(app().settings.role);
  const clauseLabel = (standard, ref) => `${standard} ${/^(\d|A\.)/.test(ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')}${ref}`;
  const kindLabel = kind => { const item = lib().kinds[kind]; return item ? tx(item.label) : kind; };
  const tagNames = { iso9001: 'ISO 9001', iso14001: 'ISO 14001', iso45001: 'ISO 45001', iso50001: 'ISO 50001', iso27001: 'ISO 27001', welding: text('Welding', 'Schwei\u00dfen'), steel: text('Steel', 'Stahlbau'), quality: text('Quality', 'Qualit\u00e4t'), customer: text('Customer audits', 'Kundenaudits'), environment: text('Environment', 'Umwelt'), permit: text('Permits', 'Genehmigungen'), energy: text('Energy', 'Energie'), safety: text('Safety', 'Arbeitsschutz'), security: text('Security', 'Sicherheit'), sustainability: text('Sustainability', 'Nachhaltigkeit') };
  let sort = 'match';
  let onlyAvailable = false;
  let assignId = '';
  let respondId = '';

  const assignDialog = document.createElement('dialog');
  assignDialog.id = 'assign-auditor-dialog';
  assignDialog.className = 'audit-modal assign-auditor';
  assignDialog.setAttribute('aria-labelledby', 'assign-auditor-title');
  assignDialog.innerHTML = '<header class="audit-modal-header"><div><small>MIRA</small><h2 id="assign-auditor-title"></h2></div><button class="button secondary evidence-editor-close" type="button"></button></header><div class="audit-modal-body" id="assign-auditor-body"></div>';
  document.body.append(assignDialog);
  const assignBody = assignDialog.querySelector('#assign-auditor-body');
  const respondDialog = document.createElement('dialog');
  respondDialog.id = 'respond-dialog';
  respondDialog.className = 'audit-modal respond-dialog';
  respondDialog.setAttribute('aria-labelledby', 'respond-title');
  respondDialog.innerHTML = '<header class="audit-modal-header"><div><small>MIRA</small><h2 id="respond-title"></h2></div><button class="button secondary evidence-editor-close" type="button"></button></header><div class="audit-modal-body" id="respond-body"></div>';
  document.body.append(respondDialog);
  const respondBody = respondDialog.querySelector('#respond-body');
  const toast = message => { const node = document.querySelector('#toast'); if (!node) return; node.textContent = message; node.classList.add('show'); setTimeout(() => node.classList.remove('show'), 2600); };
  const audit = id => A().audits().find(item => item.id === id);
  const setClose = dialog => { const close = dialog.querySelector('.evidence-editor-close'); close.textContent = '\u00d7'; close.setAttribute('aria-label', text('Close', 'Schlie\u00dfen')); };

  function ranked(target) {
    const rows = A().directory.map(auditor => {
      const score = A().matchScore(auditor, target);
      const busy = A().isBusy(auditor, target.plannedDate);
      return { auditor, score, busy, free: A().nextFree(auditor, A().iso(new Date())), estimate: A().estimate(auditor, target) };
    }).filter(row => !onlyAvailable || !row.busy);
    const by = {
      match: (a, b) => b.score - a.score || Number(a.busy) - Number(b.busy) || b.auditor.rating - a.auditor.rating,
      price: (a, b) => a.auditor.dayRate - b.auditor.dayRate,
      experience: (a, b) => b.auditor.experience - a.auditor.experience,
      availability: (a, b) => Number(a.busy) - Number(b.busy) || String(a.free).localeCompare(String(b.free))
    };
    return rows.sort(by[sort]);
  }
  function renderAssign() {
    const target = audit(assignId);
    if (!target) return;
    assignDialog.querySelector('#assign-auditor-title').textContent = text('Assign an auditor', 'Auditor zuweisen');
    setClose(assignDialog);
    const tags = A().tagsFor(target);
    const rows = ranked(target);
    const best = sort === 'match' ? rows.find(row => row.score > 0 && !row.busy) : null;
    const days = rows[0]?.estimate.days || 1;
    assignBody.innerHTML = `<div class="audit-launch-summary"><div><small>${text('Audit', 'Audit')}</small><strong>${esc(target.framework)}</strong></div><div><small>${text('Site', 'Standort')}</small><strong>${esc(A().siteOf(target) || text('All sites in scope', 'Alle Standorte im Umfang'))}</strong></div><div><small>${text('Planned date', 'Geplantes Datum')}</small><strong>${esc(day(target.plannedDate))}</strong></div><div><small>${text('Estimated effort', 'Gesch\u00e4tzter Aufwand')}</small><strong>${days} ${text('days (demo estimate)', 'Tage (Demoannahme)')}</strong></div></div><p class="audit-prefill-note">${text('Demo directory: all auditors, firms, rates, references and availability are fictional sample data. Price = day rate \u00d7 estimated days. Availability is checked against the planned date.', 'Demo-Verzeichnis: Alle Auditoren, Firmen, Tagess\u00e4tze, Referenzen und Verf\u00fcgbarkeiten sind fiktive Beispieldaten. Preis = Tagessatz \u00d7 gesch\u00e4tzte Tage. Die Verf\u00fcgbarkeit wird gegen das geplante Datum gepr\u00fcft.')}</p><div class="package-controls"><label class="field">${text('Sort by', 'Sortieren nach')}<select data-assign-sort>${[['match', text('Best match', 'Beste \u00dcbereinstimmung')], ['price', text('Price (low to high)', 'Preis (aufsteigend)')], ['experience', text('Experience', 'Erfahrung')], ['availability', text('Availability', 'Verf\u00fcgbarkeit')]].map(([value, label]) => `<option value="${value}" ${sort === value ? 'selected' : ''}>${esc(label)}</option>`).join('')}</select></label><label class="audit-guide-confirm"><input type="checkbox" data-assign-available ${onlyAvailable ? 'checked' : ''}>${text('Only available on the planned date', 'Nur am geplanten Datum verf\u00fcgbar')}</label></div>${target.assignedAuditor ? `<p class="audit-prefill-note">${text('Currently assigned', 'Derzeit zugewiesen')}: <strong>${esc(target.assignedAuditor.name)}</strong> \u00b7 ${esc(target.assignedAuditor.firm)} <button type="button" class="button text" data-assign-remove>${text('Remove assignment', 'Zuweisung entfernen')}</button></p>` : ''}${mayPlan() ? '' : `<p class="audit-prefill-note">${text('Your role cannot assign auditors.', 'Ihre Rolle darf keine Auditoren zuweisen.')}</p>`}<div class="auditor-list">${rows.map(row => { const a = row.auditor; const matched = tags.filter(tag => a.tags.includes(tag)); const current = target.assignedAuditor?.id === a.id; return `<article class="auditor-card ${current ? 'current' : ''}"><div class="auditor-main"><div class="auditor-title"><h3>${esc(a.name)}</h3>${best === row ? `<span class="tag green">${text('Best fit', 'Beste Wahl')}</span>` : ''}${current ? `<span class="tag">${text('Assigned', 'Zugewiesen')}</span>` : ''}</div><small>${esc(a.firm)} \u00b7 ${esc(a.languages.join(' / '))}</small><div class="source-chips">${matched.length ? matched.map(tag => `<span class="source-chip live">${esc(text('Matches', 'Passt zu'))}: ${esc(tagNames[tag] || tag)}</span>`).join('') : `<span class="source-chip clause">${text('No direct match for this standard', 'Keine direkte \u00dcbereinstimmung mit dieser Norm')}</span>`}${a.tags.filter(tag => !matched.includes(tag)).slice(0, 3).map(tag => `<span class="source-chip">${esc(tagNames[tag] || tag)}</span>`).join('')}</div><dl class="auditor-facts"><div><dt>${text('Experience', 'Erfahrung')}</dt><dd>${a.experience} ${text('years', 'Jahre')} \u00b7 ${a.audits} ${text('audits', 'Audits')}</dd></div><div><dt>${text('Rating', 'Bewertung')}</dt><dd>${a.rating.toFixed(1)} / 5</dd></div><div><dt>${text('References', 'Referenzen')}</dt><dd>${esc(a.references.join(', '))}</dd></div></dl></div><div class="auditor-side"><strong class="auditor-rate">${esc(A().money(a.dayRate))} <small>/ ${text('day', 'Tag')}</small></strong><small>${row.estimate.days} ${text('days', 'Tage')} \u2248 ${esc(A().money(row.estimate.cost))}</small><span class="tag ${row.busy ? 'amber' : 'green'}">${row.busy ? text('Busy on planned date', 'Am Termin belegt') : text('Available on planned date', 'Am Termin verf\u00fcgbar')}</span>${row.busy ? `<small>${text('Next free', 'N\u00e4chster freier Tag')}: ${esc(day(row.free))}</small>` : ''}<button type="button" class="button ${current ? 'secondary' : 'primary'}" data-assign-pick="${esc(a.id)}" ${mayPlan() && !current ? '' : 'disabled'}>${current ? text('Assigned', 'Zugewiesen') : text('Assign', 'Zuweisen')}</button></div></article>`; }).join('') || `<p class="physical-ai-empty">${text('No auditor matches these filters.', 'Kein Auditor passt zu diesen Filtern.')}</p>`}</div>`;
  }
  function openAssign(id, trigger) {
    assignId = id;
    assignDialog.dataset.opener = '';
    renderAssign();
    document.body.classList.add('audit-modal-open');
    assignDialog.showModal();
    assignBody.querySelector('select')?.focus();
  }
  function pick(auditorId) {
    const target = audit(assignId);
    const auditor = A().directory.find(item => item.id === auditorId);
    if (!target || !auditor || !mayPlan()) return;
    const estimate = A().estimate(auditor, target);
    target.assignedAuditor = { id: auditor.id, name: auditor.name, firm: auditor.firm, dayRate: auditor.dayRate, days: estimate.days, cost: estimate.cost, assignedAt: new Date().toISOString(), assignedBy: app().settings.user };
    target.auditor = auditor.name;
    (target.history ||= []).push({ at: new Date().toISOString(), by: app().settings.user, action: text('assigned auditor', 'hat Auditor zugewiesen'), note: `${auditor.name} \u00b7 ${A().money(auditor.dayRate)}/${text('day', 'Tag')}` });
    A().saveCompliance();
    assignDialog.close();
    app().render();
    toast(`${auditor.name} ${text('assigned to', 'zugewiesen f\u00fcr')} ${target.framework}.`);
  }
  assignBody.addEventListener('change', event => {
    if (event.target.matches('[data-assign-sort]')) { sort = event.target.value; renderAssign(); }
    if (event.target.matches('[data-assign-available]')) { onlyAvailable = event.target.checked; renderAssign(); }
  });
  assignBody.addEventListener('click', event => {
    const choose = event.target.closest('[data-assign-pick]');
    if (choose) { pick(choose.dataset.assignPick); return; }
    if (event.target.closest('[data-assign-remove]')) {
      const target = audit(assignId);
      if (target && mayPlan()) { target.assignedAuditor = null; target.auditor = 'Unassigned'; (target.history ||= []).push({ at: new Date().toISOString(), by: app().settings.user, action: text('removed the auditor assignment', 'hat die Auditorzuweisung entfernt'), note: '' }); A().saveCompliance(); renderAssign(); app().render(); }
    }
  });
  assignDialog.querySelector('.evidence-editor-close').addEventListener('click', () => assignDialog.close());
  assignDialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); assignDialog.close(); } });
  assignDialog.addEventListener('close', () => { if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open'); });

  function targetOptions(target) {
    const site = A().siteOf(target);
    const orders = app().operations.orders.filter(order => (target.orderIds || []).includes(order.id) && (!site || order.site === site) && (!target.contract?.customer || order.customer === target.contract.customer));
    return orders.flatMap(order => order.componentIds.map(componentId => ({ orderId: order.id, componentId, site: order.site })));
  }
  function renderRespond() {
    const target = audit(respondId);
    if (!target) return;
    A().syncRequests(target);
    respondDialog.querySelector('#respond-title').textContent = text('Auditor requests', 'Auditor-Anforderungen') + ' \u00b7 ' + target.framework;
    setClose(respondDialog);
    const requests = (target.requests || []).filter(request => ['open', 'provided'].includes(request.status));
    const options = targetOptions(target);
    respondBody.innerHTML = `<p class="audit-prefill-note">${text('The auditor asked for the evidence below. Upload a file or create the document here, guided by ROSNIE. New evidence is submitted for review, never approved automatically.', 'Der Auditor hat die folgenden Nachweise angefordert. Laden Sie eine Datei hoch oder erstellen Sie das Dokument hier, gef\u00fchrt durch ROSNIE. Neue Nachweise werden zur Pr\u00fcfung eingereicht und nie automatisch freigegeben.')}</p><div class="audit-gaps">${requests.map(request => `<div class="audit-gap" data-request="${esc(request.id)}"><div class="audit-gap-main"><strong>${esc(clauseLabel(request.standard, request.ref))} \u00b7 ${esc(tx(request.title))}</strong><small>${esc(kindLabel(request.kind))} \u00b7 ${text('due', 'f\u00e4llig')} ${esc(day(request.due))}</small><p>${esc(request.note)}</p></div>${request.status === 'provided' ? `<span class="tag green">${text('Provided: awaiting auditor', 'Geliefert: wartet auf Auditor')}</span>` : `<span class="tag amber">${text('Open', 'Offen')}</span><div class="audit-gap-choose"><label class="field">${text('Link to order / component', 'Mit Auftrag / Bauteil verkn\u00fcpfen')}<select data-request-target>${options.map(option => `<option value="${esc(JSON.stringify([option.orderId, option.componentId]))}">${esc(option.orderId + ' \u00b7 ' + option.componentId + ' \u00b7 ' + option.site)}</option>`).join('')}</select></label><button type="button" class="button secondary" data-request-upload="${esc(request.id)}">${text('Upload file', 'Datei hochladen')}</button><button type="button" class="button primary" data-request-create="${esc(request.id)}">${text('Create document with ROSNIE', 'Dokument mit ROSNIE erstellen')}</button></div>`}</div>`).join('') || `<p class="physical-ai-empty">${text('No open requests.', 'Keine offenen Anforderungen.')}</p>`}</div>`;
  }
  function openRespond(id) {
    respondId = id;
    renderRespond();
    document.body.classList.add('audit-modal-open');
    respondDialog.showModal();
  }
  respondBody.addEventListener('click', event => {
    const upload = event.target.closest('[data-request-upload]');
    const create = event.target.closest('[data-request-create]');
    const button = upload || create;
    if (!button) return;
    const target = audit(respondId);
    const request = target.requests.find(item => item.id === (upload ? upload.dataset.requestUpload : create.dataset.requestCreate));
    const select = button.closest('[data-request]').querySelector('[data-request-target]');
    if (!select?.value) { toast(text('No order matches this audit scope. Check its customer and site assignment.', 'Kein Auftrag entspricht diesem Auditumfang. Kunden- und Standortzuweisung prüfen.')); return; }
    const [orderId, componentId] = JSON.parse(select.value);
    const clauses = [{ standard: request.standard, ref: request.ref, title: request.title }];
    const title = kindLabel(request.kind);
    if (upload) {
      const input = document.querySelector('#evidence-file-input');
      Object.assign(input.dataset, { taskId: '', orderId, componentId, kind: request.kind, title, clauses: JSON.stringify(clauses) });
      input.click();
    } else window.DemoV2Evidence.openFor({ orderId, componentId, kind: request.kind, title, clauses }, button);
  });
  respondDialog.querySelector('.evidence-editor-close').addEventListener('click', () => respondDialog.close());
  respondDialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); respondDialog.close(); } });
  respondDialog.addEventListener('close', () => { if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open'); });
  document.addEventListener('demov2:evidence-changed', () => { if (respondDialog.open) renderRespond(); });

  function decorate() {
    if (window.DemoV2AuditorView?.seed()) { app().render(); return; }
    document.querySelectorAll('.audit-register-row').forEach(row => {
      if (row.querySelector('.audit-row-extra')) return;
      const id = row.querySelector('[data-audit-id]')?.dataset.auditId;
      const item = id && audit(id);
      if (!item) return;
      A().syncRequests(item);
      const tag = row.querySelector(':scope > .tag');
      if (tag) { tag.className = 'tag ' + A().statusTone(item.status); tag.textContent = A().statusLabel(item.status); }
      const site = A().siteOf(item);
      const entry = A().entryOf(item);
      const percent = entry ? window.DemoV2AuditModalInternals.coverage(entry).percent : null;
      const tone = percent === null ? '' : percent < 50 ? 'red' : percent < 70 ? 'amber' : 'green';
      const open = A().openRequests(item).length;
      const assigned = item.assignedAuditor;
      row.insertAdjacentHTML('beforeend', `<div class="audit-row-extra">${percent === null ? '' : `<span class="source-chip ${tone}">${text('Evidence coverage', 'Nachweisabdeckung')}: ${percent}%</span>`}<span class="source-chip">${text('Site', 'Standort')}: ${esc(site || text('All sites in scope', 'Alle Standorte im Umfang'))}</span><span class="source-chip ${assigned ? 'live' : 'clause'}">${assigned ? esc(assigned.name + ' \u00b7 ' + assigned.firm + ' \u00b7 ' + A().money(assigned.dayRate) + '/' + text('day', 'Tag')) : text('No auditor assigned', 'Kein Auditor zugewiesen')}</span>${item.decision ? `<span class="source-chip clause">${esc(A().statusLabel(item.status))}: ${esc(item.decision.note)}</span>` : ''}</div>`);
      const actions = row.querySelector('.audit-row-actions');
      if (actions) {
        actions.insertAdjacentHTML('afterbegin', `<button type="button" class="button secondary" data-assign-auditor="${esc(item.id)}">${assigned ? text('Change auditor', 'Auditor wechseln') : text('Assign auditor', 'Auditor zuweisen')}</button>${open ? `<button type="button" class="button primary" data-respond-requests="${esc(item.id)}">${text('Respond to requests', 'Auf Anforderungen antworten')} (${open})</button>` : ''}`);
      }
    });
  }
  document.addEventListener('click', event => {
    const assign = event.target.closest('[data-assign-auditor]');
    if (assign) { openAssign(assign.dataset.assignAuditor, assign); return; }
    const respond = event.target.closest('[data-respond-requests]');
    if (respond) openRespond(respond.dataset.respondRequests);
  });

  window.DemoV2CustomerAudits = { decorate, openAssign, openRespond, ranked };
  decorate();
  document.addEventListener('DOMContentLoaded', () => { if (!document.querySelector('#auditor-view')) decorate(); });
})();
