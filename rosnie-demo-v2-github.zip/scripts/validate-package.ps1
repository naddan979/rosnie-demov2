$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$indexPath = Join-Path $root 'index.html'
$workflowPath = Join-Path $root '.github\workflows\pages.yml'

if (-not (Test-Path -LiteralPath $indexPath -PathType Leaf)) {
  throw 'index.html is missing from the project root.'
}
if (-not (Test-Path -LiteralPath $workflowPath -PathType Leaf)) {
  throw 'GitHub Pages workflow is missing.'
}

$html = Get-Content -LiteralPath $indexPath -Raw
$references = [regex]::Matches($html, '(?i)\b(?:src|href)\s*=\s*["'']([^"'']+)["'']')
$checked = 0
$missing = [System.Collections.Generic.List[string]]::new()

foreach ($match in $references) {
  $reference = $match.Groups[1].Value
  if ([string]::IsNullOrWhiteSpace($reference) -or $reference.StartsWith('#') -or $reference -match '^(?i)([a-z][a-z0-9+.-]*:|//)') {
    continue
  }

  $relativePath = [Uri]::UnescapeDataString(($reference -split '[?#]', 2)[0]).Replace('/', [IO.Path]::DirectorySeparatorChar)
  if ([string]::IsNullOrWhiteSpace($relativePath)) {
    continue
  }

  $checked++
  if (-not (Test-Path -LiteralPath (Join-Path $root $relativePath) -PathType Leaf)) {
    $missing.Add($reference)
  }
}

if ($missing.Count -gt 0) {
  throw "Missing local app assets: $($missing -join ', ')"
}

$fileCount = (Get-ChildItem -LiteralPath $root -File -Recurse -Force).Count
Write-Output "PASS: $checked local HTML asset references resolved; $fileCount files are present."
