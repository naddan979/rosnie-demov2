(() => {
  const kinds = {
    'material-certificate': { label: ['Material certificate with heat/batch traceability', 'Materialzeugnis mit Schmelzen-/Chargenrückverfolgbarkeit'], sources: ['sap', 'astra'] },
    wps: { label: ['Approved welding procedure specification (WPS)', 'Freigegebene Schweißanweisung (WPS)'], sources: ['sharepoint', 'astra'] },
    wpqr: { label: ['Welding procedure qualification record (WPQR)', 'Verfahrensprüfung (WPQR)'], sources: ['sharepoint', 'astra'] },
    'welding-record': { label: ['Welding execution record with parameters', 'Schweißprotokoll mit Parametern'], sources: ['SNS-WELD-01', 'astra'] },
    'ndt-report': { label: ['NDT inspection report', 'ZfP-Prüfbericht'], sources: ['astra'] },
    'inspection-report': { label: ['Inspection or dimensional report', 'Prüf- oder Maßprüfbericht'], sources: ['CAM-WELD-01', 'astra'] },
    'calibration-certificate': { label: ['Calibration certificate for measuring equipment', 'Kalibrierzertifikat für Messmittel'], sources: ['sharepoint', 'astra'] },
    'traceability-record': { label: ['Component identification and traceability record', 'Bauteilidentifikation und Rückverfolgbarkeitsnachweis'], sources: ['CAM-GATE-01', 'astra'] },
    'operation-check': { label: ['Operational monitoring record (conditions, emissions)', 'Betriebsüberwachungsprotokoll (Bedingungen, Emissionen)'], sources: ['SNS-EMIS-01', 'SNS-ENV-01', 'astra'] },
    'release-package': { label: ['Release and conformity package', 'Freigabe- und Konformitätspaket'], sources: ['astra', 'sharepoint'] },
    'internal-audit-report': { label: ['Internal audit report', 'Interner Auditbericht'], sources: ['sharepoint', 'astra'] },
    'management-review': { label: ['Management review record', 'Managementbewertungsprotokoll'], sources: ['sharepoint', 'astra'] },
    'corrective-action': { label: ['Nonconformity and corrective action record', 'Nichtkonformitäts- und Korrekturmaßnahmenprotokoll'], sources: ['sharepoint', 'astra'] },
    'controlled-document': { label: ['Controlled document (policy, procedure or scope statement)', 'Gelenktes Dokument (Richtlinie, Verfahren oder Geltungsbereich)'], sources: ['sharepoint', 'astra'] },
    'competence-record': { label: ['Competence and training record', 'Kompetenz- und Schulungsnachweis'], sources: ['sap', 'sharepoint', 'astra'] },
    'risk-assessment': { label: ['Risk, aspect or hazard assessment', 'Risiko-, Aspekt- oder Gefährdungsbeurteilung'], sources: ['sharepoint', 'astra'] },
    'legal-register': { label: ['Legal and compliance obligations register', 'Rechts- und Compliance-Pflichtenregister'], sources: ['sharepoint', 'astra'] },
    'energy-data': { label: ['Energy baseline and monitoring data', 'Energiebaseline und Überwachungsdaten'], sources: ['datalake', 'astra'] },
    'access-review': { label: ['Access control review record', 'Zugriffsprüfungsprotokoll'], sources: ['datalake', 'astra'] },
    'security-log': { label: ['Security monitoring and logging record', 'Sicherheitsüberwachungs- und Protokollnachweis'], sources: ['datalake', 'astra'] }
  };
  const sources = {
    astra: { name: ['ASTRA guided document', 'ASTRA-geführtes Dokument'] },
    sap: { name: ['SAP / ERP', 'SAP / ERP'], integration: 'SAP / ERP', supplies: ['Purchase orders, goods receipts and supplier certificates', 'Bestellungen, Wareneingänge und Lieferantenzeugnisse'] },
    sharepoint: { name: ['SharePoint / file systems', 'SharePoint / Dateisysteme'], integration: 'SharePoint / File systems', supplies: ['Controlled procedures, policies, qualification records and certificates', 'Gelenkte Verfahren, Richtlinien, Qualifikationsnachweise und Zertifikate'] },
    datalake: { name: ['APIs / Data Lake', 'APIs / Data Lake'], integration: 'APIs / Data Lake', supplies: ['Energy meter, access and log data exports', 'Energiezähler-, Zugriffs- und Protokolldaten'] }
  };
  const l = (en, de) => [en, de];
  const clause = (ref, en, de, evidenceKinds) => ({ ref, title: l(en, de), evidence: evidenceKinds.map((kind, index) => ({ id: String.fromCharCode(65 + index), kind })) });
  const standardNote = l('Clause numbers and titles follow the published standard structure. Requirement wording is not reproduced; verify clause content against the licensed standard text.', 'Klauselnummern und Titel folgen der veröffentlichten Normstruktur. Anforderungstexte werden nicht wiedergegeben; Inhalte anhand des lizenzierten Normtexts prüfen.');
  const demoNote = l('Demo requirement set: clause IDs are internal demo references, not standard clause numbers. Confirm the real requirements and clause numbers from the authoritative source.', 'Demo-Anforderungssatz: Klausel-IDs sind interne Demo-Referenzen, keine Normklauselnummern. Reale Anforderungen und Klauselnummern aus der maßgeblichen Quelle bestätigen.');

  const welding = { standard: 'Welding demo set', note: demoNote, clauses: [
    clause('D1', 'Material and heat traceability', 'Material- und Schmelzenrückverfolgbarkeit', ['material-certificate']),
    clause('D2', 'Welding procedures and qualification', 'Schweißverfahren und Qualifikation', ['wps', 'wpqr']),
    clause('D3', 'Welding execution control', 'Steuerung der Schweißausführung', ['welding-record']),
    clause('D4', 'Inspection and testing', 'Prüfung und Test', ['inspection-report', 'ndt-report']),
    clause('D5', 'Measuring and inspection equipment', 'Mess- und Prüfmittel', ['calibration-certificate']),
    clause('D6', 'Records and release', 'Aufzeichnungen und Freigabe', ['release-package'])
  ] };
  const steel = { standard: 'Steel construction demo set', note: demoNote, clauses: [
    clause('D1', 'Material identification and traceability', 'Materialkennzeichnung und Rückverfolgbarkeit', ['material-certificate', 'traceability-record']),
    clause('D2', 'Welding procedures and qualification', 'Schweißverfahren und Qualifikation', ['wps', 'wpqr']),
    clause('D3', 'Inspection and testing', 'Prüfung und Test', ['inspection-report', 'ndt-report']),
    clause('D4', 'Storage and consumables conditions', 'Lager- und Zusatzwerkstoffbedingungen', ['operation-check']),
    clause('D5', 'Conformity documentation and release', 'Konformitätsdokumentation und Freigabe', ['release-package'])
  ] };
  const customer = { standard: 'Customer quality plan demo set', note: demoNote, clauses: [
    clause('Q1', 'Hold points and inspection', 'Haltepunkte und Prüfung', ['inspection-report', 'ndt-report']),
    clause('Q2', 'Material traceability', 'Materialrückverfolgbarkeit', ['material-certificate', 'traceability-record']),
    clause('Q3', 'Welding documentation', 'Schweißdokumentation', ['wps', 'wpqr', 'welding-record']),
    clause('Q4', 'Customer release package', 'Kundenfreigabepaket', ['release-package'])
  ] };
  const permit = { standard: 'Permit and monitoring demo set', note: demoNote, clauses: [
    clause('P1', 'Applicable permit conditions and obligations', 'Anwendbare Genehmigungsauflagen und Pflichten', ['legal-register']),
    clause('P2', 'Monitoring results', 'Überwachungsergebnisse', ['operation-check']),
    clause('P3', 'Monitoring equipment calibration', 'Kalibrierung der Überwachungsmittel', ['calibration-certificate']),
    clause('P4', 'Deviations and corrective action', 'Abweichungen und Korrekturmaßnahmen', ['corrective-action'])
  ] };
  const energy = { standard: 'Energy demo set', note: demoNote, clauses: [
    clause('E1', 'Energy baseline and boundaries', 'Energiebaseline und Systemgrenzen', ['energy-data', 'controlled-document']),
    clause('E2', 'Monitoring and metering', 'Überwachung und Messung', ['energy-data', 'calibration-certificate']),
    clause('E3', 'Reporting obligations', 'Berichtspflichten', ['legal-register']),
    clause('E4', 'Corrective action', 'Korrekturmaßnahmen', ['corrective-action'])
  ] };
  const security = { standard: 'Cybersecurity demo set', note: demoNote, clauses: [
    clause('S1', 'Scope and risk assessment', 'Geltungsbereich und Risikobewertung', ['risk-assessment', 'controlled-document']),
    clause('S2', 'Access control', 'Zugriffskontrolle', ['access-review']),
    clause('S3', 'Logging and monitoring', 'Protokollierung und Überwachung', ['security-log']),
    clause('S4', 'Incident and corrective action', 'Vorfälle und Korrekturmaßnahmen', ['corrective-action'])
  ] };
  const safety = { standard: 'Occupational safety demo set', note: demoNote, clauses: [
    clause('H1', 'Hazard assessment', 'Gefährdungsbeurteilung', ['risk-assessment']),
    clause('H2', 'Competence and instruction', 'Kompetenz und Unterweisung', ['competence-record']),
    clause('H3', 'Safety inspection', 'Sicherheitsprüfung', ['inspection-report']),
    clause('H4', 'Incidents and corrective action', 'Vorfälle und Korrekturmaßnahmen', ['corrective-action'])
  ] };
  const sustainability = { standard: 'Sustainability demo set', note: demoNote, clauses: [
    clause('B1', 'Supplier declarations and scheme scope', 'Lieferantenerklärungen und Regelwerksumfang', ['controlled-document']),
    clause('B2', 'Material origin and traceability', 'Materialherkunft und Rückverfolgbarkeit', ['material-certificate', 'traceability-record']),
    clause('B3', 'Verification and corrective action', 'Verifizierung und Korrekturmaßnahmen', ['corrective-action'])
  ] };
  const governance = { standard: 'Governance demo set', note: demoNote, clauses: [
    clause('G1', 'Applicable requirement and scope', 'Anwendbare Anforderung und Geltungsbereich', ['controlled-document']),
    clause('G2', 'Control records', 'Kontrollnachweise', ['inspection-report']),
    clause('G3', 'Review and corrective action', 'Prüfung und Korrekturmaßnahmen', ['internal-audit-report', 'corrective-action'])
  ] };

  const profiles = {
    'CAT-QMS-9001': { standard: 'ISO 9001', note: standardNote, clauses: [
      clause('4.1', 'Understanding the organization and its context', 'Verstehen der Organisation und ihres Kontextes', ['controlled-document']),
      clause('7.1.5', 'Monitoring and measuring resources', 'Ressourcen zur Überwachung und Messung', ['calibration-certificate', 'inspection-report']),
      clause('7.2', 'Competence', 'Kompetenz', ['competence-record']),
      clause('7.5', 'Documented information', 'Dokumentierte Information', ['controlled-document']),
      clause('8.4', 'Control of externally provided processes, products and services', 'Steuerung extern bereitgestellter Prozesse, Produkte und Dienstleistungen', ['material-certificate']),
      clause('8.5.1', 'Control of production and service provision', 'Steuerung der Produktion und Dienstleistungserbringung', ['welding-record']),
      clause('8.5.2', 'Identification and traceability', 'Kennzeichnung und Rückverfolgbarkeit', ['traceability-record']),
      clause('8.5.4', 'Preservation', 'Erhaltung', ['operation-check']),
      clause('8.6', 'Release of products and services', 'Freigabe von Produkten und Dienstleistungen', ['inspection-report', 'release-package']),
      clause('9.2', 'Internal audit', 'Internes Audit', ['internal-audit-report']),
      clause('9.3', 'Management review', 'Managementbewertung', ['management-review']),
      clause('10.2', 'Nonconformity and corrective action', 'Nichtkonformität und Korrekturmaßnahmen', ['corrective-action'])
    ] },
    'CAT-QMS-14001': { standard: 'ISO 14001', note: standardNote, clauses: [
      clause('4.1', 'Understanding the organization and its context', 'Verstehen der Organisation und ihres Kontextes', ['controlled-document']),
      clause('6.1.2', 'Environmental aspects', 'Umweltaspekte', ['risk-assessment']),
      clause('6.1.3', 'Compliance obligations', 'Bindende Verpflichtungen', ['legal-register']),
      clause('7.2', 'Competence', 'Kompetenz', ['competence-record']),
      clause('8.1', 'Operational planning and control', 'Betriebliche Planung und Steuerung', ['operation-check']),
      clause('9.1.1', 'Monitoring, measurement, analysis and evaluation', 'Überwachung, Messung, Analyse und Bewertung', ['operation-check', 'calibration-certificate']),
      clause('9.1.2', 'Evaluation of compliance', 'Bewertung der Einhaltung von Verpflichtungen', ['legal-register']),
      clause('9.2', 'Internal audit', 'Internes Audit', ['internal-audit-report']),
      clause('10.2', 'Nonconformity and corrective action', 'Nichtkonformität und Korrekturmaßnahmen', ['corrective-action'])
    ] },
    'CAT-OHS-45001': { standard: 'ISO 45001', note: standardNote, clauses: [
      clause('4.1', 'Understanding the organization and its context', 'Verstehen der Organisation und ihres Kontextes', ['controlled-document']),
      clause('6.1.2', 'Hazard identification and assessment of risks and opportunities', 'Ermittlung von Gefährdungen und Bewertung von Risiken und Chancen', ['risk-assessment']),
      clause('6.1.3', 'Determination of legal requirements and other requirements', 'Ermittlung rechtlicher Anforderungen und anderer Anforderungen', ['legal-register']),
      clause('7.2', 'Competence', 'Kompetenz', ['competence-record']),
      clause('8.1.2', 'Eliminating hazards and reducing OH&S risks', 'Beseitigen von Gefährdungen und Verringern von Risiken', ['inspection-report']),
      clause('8.2', 'Emergency preparedness and response', 'Notfallvorsorge und Gefahrenabwehr', ['controlled-document']),
      clause('9.1.1', 'Monitoring, measurement, analysis and performance evaluation', 'Überwachung, Messung, Analyse und Leistungsbewertung', ['operation-check']),
      clause('9.1.2', 'Evaluation of compliance', 'Bewertung der Einhaltung', ['legal-register']),
      clause('10.2', 'Incident, nonconformity and corrective action', 'Vorfälle, Nichtkonformitäten und Korrekturmaßnahmen', ['corrective-action'])
    ] },
    'CAT-ENERGY-50001': { standard: 'ISO 50001', note: standardNote, clauses: [
      clause('4.1', 'Understanding the organization and its context', 'Verstehen der Organisation und ihres Kontextes', ['controlled-document']),
      clause('6.3', 'Energy review', 'Energetische Bewertung', ['energy-data']),
      clause('6.5', 'Energy baseline', 'Energetische Ausgangsbasis', ['energy-data']),
      clause('6.6', 'Planning for collection of energy data', 'Planung der Erfassung von Energiedaten', ['controlled-document']),
      clause('8.1', 'Operational planning and control', 'Betriebliche Planung und Steuerung', ['operation-check']),
      clause('9.1.1', 'Monitoring, measurement, analysis and evaluation', 'Überwachung, Messung, Analyse und Bewertung', ['energy-data', 'calibration-certificate']),
      clause('9.2', 'Internal audit', 'Internes Audit', ['internal-audit-report']),
      clause('10.1', 'Nonconformity and corrective action', 'Nichtkonformität und Korrekturmaßnahmen', ['corrective-action'])
    ] },
    'CAT-ISMS-27001': { standard: 'ISO 27001', note: standardNote, clauses: [
      clause('4.1', 'Understanding the organization and its context', 'Verstehen der Organisation und ihres Kontextes', ['controlled-document']),
      clause('6.1.2', 'Information security risk assessment', 'Informationssicherheits-Risikobeurteilung', ['risk-assessment']),
      clause('6.1.3', 'Information security risk treatment', 'Informationssicherheits-Risikobehandlung', ['controlled-document']),
      clause('7.2', 'Competence', 'Kompetenz', ['competence-record']),
      clause('9.1', 'Monitoring, measurement, analysis and evaluation', 'Überwachung, Messung, Analyse und Bewertung', ['security-log']),
      clause('9.2', 'Internal audit', 'Internes Audit', ['internal-audit-report']),
      clause('A.5.15', 'Access control (Annex A)', 'Zugangssteuerung (Anhang A)', ['access-review']),
      clause('A.8.15', 'Logging (Annex A)', 'Protokollierung (Anhang A)', ['security-log']),
      clause('10.2', 'Nonconformity and corrective action', 'Nichtkonformität und Korrekturmaßnahmen', ['corrective-action'])
    ] },
    'CAT-WELD-3834': welding, 'CAT-WELD-PACK': welding,
    'CAT-EN1090': steel, 'CAT-FPC': steel,
    'CAT-CUSTOMER': customer, 'CAT-PIPE-PACK': customer,
    'CAT-PERMIT': permit, 'CAT-EMISSIONS': permit, 'CAT-EMISSION-REG': permit,
    'CAT-ENERGY-CERT': energy, 'CAT-ENERGY-REG': energy,
    'CAT-CYBER': security,
    'CAT-OHS-SITE': safety,
    'CAT-BIOMASS': sustainability, 'CAT-SUST-CERT': sustainability,
    'CAT-INTERNAL': governance, 'CAT-CUSTOM-REG': governance
  };

  const deviceTargets = {
    'CAM-WELD-01': [['ISO 3834 demo set', 'D4', l('Inspection and testing', 'Prüfung und Test')], ['ISO 9001', '8.6', l('Release of products and services', 'Freigabe von Produkten und Dienstleistungen')]],
    'SNS-WELD-01': [['ISO 3834 demo set', 'D3', l('Welding execution control', 'Steuerung der Schweißausführung')], ['ISO 9001', '8.5.1', l('Control of production and service provision', 'Steuerung der Produktion und Dienstleistungserbringung')]],
    'SNS-ENV-01': [['ISO 9001', '8.5.4', l('Preservation', 'Erhaltung')], ['EN 1090 demo set', 'D4', l('Storage and consumables conditions', 'Lager- und Zusatzwerkstoffbedingungen')]],
    'SNS-EMIS-01': [['ISO 14001', '9.1.1', l('Monitoring, measurement, analysis and evaluation', 'Überwachung, Messung, Analyse und Bewertung')], ['Environmental permit demo set', 'P2', l('Monitoring results', 'Überwachungsergebnisse')]],
    'CAM-GATE-01': [['ISO 9001', '8.5.2', l('Identification and traceability', 'Kennzeichnung und Rückverfolgbarkeit')], ['EN 1090 demo set', 'D1', l('Material identification and traceability', 'Materialkennzeichnung und Rückverfolgbarkeit')]]
  };

  const fallback = entry => {
    const topic = entry.topic || '';
    if (/Welding/.test(topic)) return welding;
    if (/Pipeline/.test(topic)) return customer;
    if (/Environmental|Energy and Power/.test(topic)) return permit;
    if (/Energy Management/.test(topic)) return energy;
    if (/Cyber/.test(topic)) return security;
    if (/Occupational/.test(topic)) return safety;
    if (/Sustainability/.test(topic)) return sustainability;
    return governance;
  };
  const checklist = entry => profiles[entry.id] || fallback(entry);
  const usedBy = sourceId => {
    const found = [];
    for (const [id, profile] of Object.entries(profiles)) {
      for (const item of profile.clauses) {
        if (item.evidence.some(evidence => (kinds[evidence.kind]?.sources || []).includes(sourceId))) found.push([profile.standard, item.ref, item.title]);
      }
    }
    const seen = new Set();
    return found.filter(([standard, ref]) => { const key = standard + ref; if (seen.has(key)) return false; seen.add(key); return true; });
  };

  const allClauses = () => {
    const seen = new Map();
    for (const profile of Object.values(profiles)) for (const item of profile.clauses) {
      const key = profile.standard + '|' + item.ref;
      if (!seen.has(key)) seen.set(key, { key, standard: profile.standard, ref: item.ref, title: item.title, kinds: item.evidence.map(evidence => evidence.kind) });
    }
    return [...seen.values()];
  };
  const registerSource = (kind, id) => { const list = kinds[kind]?.sources; if (list && !list.includes(id)) list.unshift(id); };

  function sourceApplicable(device, standard, ref, sites = []) {
    if (!device || (sites.length && !sites.includes(device.site))) return false;
    const aliases = { 'Welding demo set': 'ISO 3834 demo set', 'Steel construction demo set': 'EN 1090 demo set', 'Permit and monitoring demo set': 'Environmental permit demo set' };
    const targetStandard = aliases[standard] || standard;
    return (device.targets || deviceTargets[device.id] || []).some(([name, reference]) => name === targetStandard && reference === ref);
  }
  window.DemoV2Library = { kinds, sources, checklist, deviceTargets, usedBy, allClauses, registerSource, sourceApplicable };
})();
