(() => {
  const text = (english, german) => window.DemoV2.settings.language === 'de' ? german : english;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  const pages = { audits: 0, gaps: 0 };
  const pageSize = 5;
  const filters = { certification: '', site: '', status: '' };
  const evidenceSource = record => record.origin === 'sensor-captured' ? text('Live connection', 'Live-Verbindung') + ' · ' + record.deviceId : record.origin === 'astra-authored' ? text('Created in ASTRA', 'In ASTRA erstellt') : record.provenance?.illustrativeSystem ? record.provenance.illustrativeSystem + text(' (sample)', ' (Beispiel)') : text('Uploaded / sample file', 'Upload / Beispieldatei');
  const kindLabel = kind => { const item = window.DemoV2Library.kinds[kind]; return item ? text(...item.label) : kind; };
  function recordsFor(item) {
    const primary = item.pairs.map(pair => pair.record).filter(Boolean);
    const supporting = window.DemoV2.operations.evidence.filter(record => record.kind === item.kind && !['superseded', 'deleted', 'withdrawn'].includes(record.status) && item.pairs.some(pair => pair.orderId === record.orderId && pair.componentId === record.componentId) && (record.origin !== 'sensor-captured' || window.DemoV2Library.sourceApplicable(window.DemoV2PhysicalAI?.devices.find(device => device.id === record.deviceId), item.standard, item.clauseRef, item.sites)));
    return [...new Map([...primary, ...supporting].map(record => [record.id, record])).values()];
  }
  function auditState(audit) {
    const app = window.DemoV2;
    const modal = window.DemoV2AuditModalInternals;
    const entry = modal.catalogue().find(item => item.id === audit.catalogId);
    if (!entry) return { clauses: [], items: [], percent: 0, records: [], missing: 0, pending: 0 };
    const scope = app.operations.orders.filter(order => (audit.orderIds || []).includes(order.id) && (!audit.site || audit.site === 'all' || order.site === audit.site) && (!audit.contract?.customer || order.customer === audit.contract.customer));
    const checklist = modal.checklistFor(entry, { ...modal.coverage(entry), orders: scope });
    const items = checklist.clauses.flatMap(clause => clause.evidence);
    const records = [...new Map(items.flatMap(recordsFor).map(record => [record.id, record])).values()];
    const percent = items.length ? Math.round(items.reduce((sum, item) => sum + item.pairs.filter(pair => pair.verified).length / Math.max(item.pairs.length, 1), 0) / items.length * 100) : 0;
    return { ...checklist, items, records, percent, missing: items.filter(item => item.status === 'missing').length, pending: items.filter(item => item.status === 'pending').length };
  }
  function auditEvidence(audit, state) {
    const scope = window.DemoV2.operations.orders.filter(order => (audit.orderIds || []).includes(order.id) && (!audit.site || audit.site === 'all' || order.site === audit.site) && (!audit.contract?.customer || order.customer === audit.contract.customer));
    return state.clauses.map(clause => {
      const interpretation = window.DemoV2ClauseGuidance.describe(state.standard, clause);
      const clauseReference = interpretation.referenceType === 'standard' ? text('Clause ', 'Abschnitt ') + clause.ref : text('Demo reference ', 'Demo-Referenz ') + clause.ref;
      return `<section class="customer-audit-clause"><h4>${esc(state.standard)} ${esc(clauseReference)} · ${esc(text(...clause.title))}</h4><div class="customer-clause-description"><strong>${interpretation.specific ? text('Requirement summary (paraphrase)', 'Anforderungszusammenfassung (Paraphrase)') : text('Audit topic — confirm the authoritative requirement', 'Auditthema — maßgebliche Anforderung bestätigen')}</strong><p>${esc(text(...interpretation.summary))}</p><small>${esc(audit.version || '')} · ${esc(audit.source || '')}. ${interpretation.referenceType === 'standard' ? text('Not verbatim standard text or a complete legal interpretation. Check the licensed edition and applicability.', 'Kein wörtlicher Normtext und keine vollständige rechtliche Auslegung. Lizenzierte Ausgabe und Anwendbarkeit prüfen.') : text('This is an internal demo reference, not a real legal paragraph. No authoritative law or permit text has been provided.', 'Dies ist eine interne Demo-Referenz, kein tatsächlicher Rechtsparagraph. Maßgeblicher Rechts- oder Genehmigungstext wurde nicht bereitgestellt.')}</small></div>${clause.evidence.map(item => {
      const records = recordsFor(item);
      const gap = item.pairs.find(pair => !pair.verified && !pair.pending);
      const target = gap && (scope.find(order => order.id === gap.orderId) || scope[0]);
      const spec = target ? { orderId: target.id, componentId: gap.componentId || target.componentIds[0], kind: item.kind, title: kindLabel(item.kind), clauses: [{ standard: state.standard, ref: clause.ref, title: clause.title }] } : null;
      const expectation = window.DemoV2ClauseGuidance.evidenceExamples[item.kind];
      const sources = item.sources || window.DemoV2Library.kinds[item.kind]?.sources || [];
      const sourceLabel = id => {
        const device = window.DemoV2PhysicalAI?.devices.find(entry => entry.id === id);
        const source = window.DemoV2Library.sources[id];
        return device ? id : source ? text(...source.name) : id;
      };
      return `<div class="customer-audit-evidence"><div><strong>${esc(item.id)} · ${esc(kindLabel(item.kind))}</strong>${expectation ? `<p class="customer-evidence-expectation"><b>${text('Evidence expected', 'Erwarteter Nachweis')}:</b> ${esc(text(...expectation))}</p>` : ''}<div class="source-chips">${records.length ? [...new Set(records.map(evidenceSource))].map(source => `<span class="source-chip ${source.includes('Live') ? 'live' : ''}">${esc(source)}</span>`).join('') : sources.map(id => `<span class="source-chip">${esc(text('Suggested source', 'Vorgeschlagene Quelle'))}: ${esc(sourceLabel(id))}</span>`).join('')}</div>${records.map(record => `<div class="customer-audit-file"><span>${esc(record.title)}</span>${record.dataUrl ? `<button type="button" class="button text" data-action="open-evidence" data-evidence-id="${esc(record.id)}">${text('Open file', 'Datei öffnen')}</button>` : `<small>${text('Sample metadata only', 'Nur Beispielmetadaten')}</small>`}<details class="customer-record-details"><summary>${text('Record details & source chain', 'Datensatzdetails & Quellenkette')}</summary><p>${esc(state.standard)} ${esc(clauseReference)} → ${esc(record.id)} → ${esc(record.orderId)} / ${esc(record.componentId)} → ${esc(evidenceSource(record))}</p>${record.sample || record.origin === 'sensor-captured' ? `<p class="customer-record-disclaimer">${record.origin === 'sensor-captured' ? text('These are values captured by the simulated feed, not physical device measurements.', 'Dies sind Werte des simulierten Datenstroms, keine physischen Gerätemessungen.') : text('Detailed fictional example, not actual measurements or an original third-party certificate.', 'Detailliertes fiktives Beispiel, keine tatsächlichen Messwerte oder Originalzertifikate Dritter.')}</p>` : ''}<dl>${window.DemoV2EvidenceDetail.details(record).map(field => `<div><dt>${esc(text(...field.label))}</dt><dd>${esc(field.value)}</dd></div>`).join('')}</dl>${record.deviceId ? `<button type="button" class="button secondary" data-customer-live="${esc(record.deviceId)}">${text('View live source', 'Live-Quelle ansehen')}</button>` : ''}</details></div>`).join('')}</div><div class="customer-audit-evidence-actions"><span class="tag ${item.status === 'verified' ? 'green' : item.status === 'pending' ? 'amber' : 'red'}">${item.status === 'verified' ? text('Verified', 'Verifiziert') : item.status === 'pending' ? text('Awaiting review', 'In Prüfung') : text('Missing', 'Fehlt')}</span>${spec ? `<details class="customer-audit-add"><summary>${text('Add evidence', 'Nachweis hinzufügen')}</summary><button type="button" class="button secondary" data-customer-upload="${esc(JSON.stringify(spec))}">${text('Upload file', 'Datei hochladen')}</button><button type="button" class="button primary" data-customer-create="${esc(JSON.stringify(spec))}">${text('Create document', 'Dokument erstellen')}</button></details>` : ''}</div></div>`;
      }).join('')}</section>`;
    }).join('');
  }
  function workspace(panel, auditPanel) {
    const app = window.DemoV2;
    const audits = app.compliance.audits;
    const matching = audits.filter(audit => (!filters.certification || audit.framework === filters.certification) && (!filters.site || audit.site === filters.site) && (!filters.status || audit.status === filters.status)).slice().sort((first, second) => Number(['Approved', 'Declined'].includes(first.status)) - Number(['Approved', 'Declined'].includes(second.status)) || (first.plannedDate || '').localeCompare(second.plannedDate || ''));
    const select = (key, label, values) => `<label class="field">${label}<select data-customer-audit-filter="${key}"><option value="">${text('All', 'Alle')}</option>${values.filter(Boolean).map(value => `<option value="${esc(value)}" ${filters[key] === value ? 'selected' : ''}>${esc(value)}</option>`).join('')}</select></label>`;
    const actions = new Map([...auditPanel?.querySelectorAll('.audit-register-row') || []].map(row => [row.querySelector('[data-audit-id]')?.dataset.auditId, row.querySelector('.audit-row-actions')?.innerHTML || '']));
    const root = document.createElement('section');
    root.className = 'customer-audit-workspace';
    root.innerHTML = `<div class="customer-audit-filters">${select('certification', text('Certification / standard', 'Zertifizierung / Norm'), [...new Set(audits.map(audit => audit.framework))])}${select('site', text('Site', 'Standort'), [...new Set(audits.map(audit => audit.site))])}${select('status', text('Audit status', 'Auditstatus'), [...new Set(audits.map(audit => audit.status))])}</div><div class="customer-audit-list">${matching.map(audit => {
      const state = auditState(audit);
      const customer = window.DemoV2AuditorPortfolio?.customerOf(audit) || audit.contract?.customer || '';
      const requests = (audit.requests || []).filter(request => request.status === 'open').length;
      const tone = state.percent < 50 ? 'red' : state.percent < 70 ? 'amber' : 'green';
      return `<article class="customer-audit-card"><div class="customer-audit-head"><div><h3>${esc(audit.framework)}</h3><p>${esc(customer)} · ${esc(audit.site === 'all' || !audit.site ? text('All scoped sites', 'Alle Standorte im Umfang') : audit.site)}</p><small>${esc(audit.id)} · ${text('Audit date', 'Audittermin')}: ${esc(audit.plannedDate || text('Not set', 'Nicht festgelegt'))} · ${esc(audit.assignedAuditor?.name || audit.auditor || text('Unassigned', 'Nicht zugewiesen'))}</small></div><span class="tag ${window.DemoV2Auditors.statusTone(audit.status)}">${esc(window.DemoV2Auditors.statusLabel(audit.status))}</span></div><div class="customer-audit-summary"><span class="tag ${tone}">${state.percent}% ${text('evidence verified', 'Nachweise verifiziert')}</span><span>${state.missing} ${text('missing items', 'fehlende Punkte')}</span><span>${state.pending} ${text('awaiting verification', 'in Prüfung')}</span>${requests ? `<span>${requests} ${text('auditor requests', 'Auditoranforderungen')}</span>` : ''}</div><div class="customer-source-summary"><small>${text('Evidence sources', 'Nachweisquellen')}</small><div class="source-chips">${[...new Set(state.records.map(evidenceSource))].map(source => `<span class="source-chip ${source.includes('Live') ? 'live' : ''}">${esc(source)}</span>`).join('') || `<span class="source-chip">${text('No linked evidence yet', 'Noch keine verknüpften Nachweise')}</span>`}</div></div><div class="customer-audit-actions">${actions.get(audit.id) || ''}</div><details class="customer-audit-checklist" data-customer-audit="${esc(audit.id)}"><summary>${text('Requirements & evidence checklist', 'Anforderungen & Nachweischeckliste')} · ${state.items.length} ${text('items', 'Punkte')}</summary><div data-customer-checklist-body></div></details></article>`;
    }).join('') || `<p class="physical-ai-empty">${text('No audits match these filters. Start an audit to plan a new engagement.', 'Keine Audits entsprechen den Filtern. Starten Sie ein Audit, um einen neuen Auftrag zu planen.')}</p>`}</div>`;
    root.querySelectorAll('.customer-audit-card').forEach((card, index) => {
      const state = auditState(matching[index]);
      const tone = state.percent < 50 ? 'red' : state.percent < 70 ? 'amber' : 'green';
      const head = card.querySelector('.customer-audit-head');
      const status = head.querySelector('.tag');
      const progress = document.createElement('div');
      progress.className = 'customer-audit-progress ' + tone;
      progress.innerHTML = `<div><strong>${state.percent}%</strong><span>${text('Audit readiness', 'Auditbereitschaft')}</span></div><div class="customer-readiness-bar" role="progressbar" aria-label="${esc(text('Verified clause evidence', 'Verifizierte Klauselnachweise'))}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${state.percent}"><i style="width:${state.percent}%"></i></div><small>${text('Verified clause evidence', 'Verifizierte Klauselnachweise')}</small>`;
      if (status) progress.append(status);
      head.append(progress);
      card.querySelector('.customer-audit-summary > .tag')?.remove();
    });
    root.querySelectorAll('[data-customer-audit-filter]').forEach(input => input.addEventListener('change', () => { filters[input.dataset.customerAuditFilter] = input.value; pages.audits = 0; app.render(); }));
    root.querySelectorAll('[data-customer-audit]').forEach(details => details.addEventListener('toggle', () => {
      const body = details.querySelector('[data-customer-checklist-body]');
      if (!details.open || body.childElementCount) return;
      const audit = audits.find(item => item.id === details.dataset.customerAudit);
      const state = auditState(audit);
      body.innerHTML = auditEvidence(audit, state);
      body.querySelectorAll('.customer-clause-description').forEach((element, index) => {
        const check = window.DemoV2ClauseGuidance.describe(state.standard, state.clauses[index]).sourceCheck;
        if (!check) return;
        element.insertAdjacentHTML('beforeend', `<p class="customer-source-validation"><strong>${esc(check.edition)}</strong> · ${esc(text(...check.notice))}</p><div class="source-chips">${check.links.map((url, linkIndex) => `<a class="source-chip" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${text('Authoritative source', 'Maßgebliche Quelle')} ${linkIndex + 1}</a>`).join('')}</div>`);
      });
      const records = state.clauses.flatMap(clause => clause.evidence.flatMap(recordsFor));
      body.querySelectorAll('.customer-audit-file').forEach((row, index) => {
        const record = records[index];
        if (record?.status !== 'submitted') return;
        const mayReview = ['Quality Manager', 'Compliance Manager', 'Auditor', 'Administrator'].includes(app.settings.role);
        const blocked = ['astra-authored', 'sensor-captured'].includes(record.origin) && record.result !== 'Pass';
        row.insertAdjacentHTML('beforeend', `<button type="button" class="button secondary" data-action="verify-evidence" data-evidence-id="${esc(record.id)}" ${mayReview && !blocked ? '' : 'disabled'}>${text('Verify evidence', 'Nachweis verifizieren')}</button>`);
      });
    }));
    paginate(root.querySelector('.customer-audit-list'), 'audits');
    panel.append(root);
  }
  function paginate(list, key) {
    if (!list || list.dataset.compactPaged) return;
    list.dataset.compactPaged = key;
    const rows = [...list.children];
    const controls = document.createElement('div');
    controls.className = 'customer-pagination';
    list.after(controls);
    function update() {
      const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
      pages[key] = Math.min(pages[key], totalPages - 1);
      rows.forEach((row, index) => { row.hidden = index < pages[key] * pageSize || index >= (pages[key] + 1) * pageSize; });
      controls.innerHTML = `<span>${rows.length ? pages[key] * pageSize + 1 : 0}–${Math.min((pages[key] + 1) * pageSize, rows.length)} / ${rows.length}</span><div><button type="button" class="button secondary" data-page-back ${pages[key] === 0 ? 'disabled' : ''}>${text('Previous', 'Zurück')}</button><button type="button" class="button secondary" data-page-next ${pages[key] === totalPages - 1 ? 'disabled' : ''}>${text('Next', 'Weiter')}</button></div>`;
    }
    controls.addEventListener('click', event => {
      if (event.target.closest('[data-page-back]')) pages[key] = Math.max(0, pages[key] - 1);
      else if (event.target.closest('[data-page-next]')) pages[key]++;
      else return;
      update();
      list.scrollIntoView({ block: 'start' });
    });
    update();
  }
  function compactRequirement(card) {
    if (card.querySelector('.customer-evidence-details')) return;
    const heading = card.querySelector('.requirement-top');
    const requirement = window.DemoV2.compliance.requirements.find(item => heading?.textContent.includes(item.id));
    if (!heading || !requirement) return;
    const state = window.DemoV2.readiness(requirement);
    const sources = [...new Set(state.related.map(record => record.origin === 'sensor-captured' ? text('Live connection', 'Live-Verbindung') + ' · ' + record.deviceId : record.origin === 'astra-authored' ? text('Created in ASTRA', 'In ASTRA erstellt') : record.provenance?.illustrativeSystem ? record.provenance.illustrativeSystem + text(' (sample)', ' (Beispiel)') : text('Uploaded / sample file', 'Upload / Beispieldatei')))];
    const details = document.createElement('details');
    details.className = 'customer-evidence-details';
    details.innerHTML = `<summary>${text('Evidence & gaps', 'Nachweise & Lücken')} · ${state.related.length} ${text('records', 'Datensätze')}</summary>`;
    [...card.children].filter(child => child !== heading).forEach(child => details.append(child));
    heading.insertAdjacentHTML('afterend', `<div class="customer-source-summary"><small>${text('Evidence sources', 'Nachweisquellen')}</small><div class="source-chips">${sources.map(source => `<span class="source-chip ${source.includes('Live') ? 'live' : ''}">${esc(source)}</span>`).join('') || `<span class="source-chip">${text('Evidence still missing', 'Nachweise fehlen noch')}</span>`}</div></div>`);
    card.append(details);
  }
  function decorate() {
    const panel = document.querySelector('.requirements-panel');
    if (!panel || document.querySelector('#auditor-view')) return;
    const tabs = panel.querySelector('.mira-tabs');
    const auditPanel = document.querySelector('.audit-panel');
    const view = new URL(location.href).searchParams.get('view') === 'connections' ? 'connections' : 'audits';
    if (!tabs) return;
    tabs.querySelector('[data-mira-view="audits"]')?.remove();
    const auditTab = tabs.querySelector('[data-mira-view="requirements"]');
    auditTab.textContent = text('Audits', 'Audits');
    auditTab.classList.toggle('active', view === 'audits');
    auditTab.setAttribute('aria-selected', String(view === 'audits'));
    const content = document.querySelector('#app-content');
    if (content.firstElementChild !== panel) content.prepend(panel);
    if (auditPanel && auditPanel.parentElement !== panel) tabs.after(auditPanel);
    if (auditPanel) auditPanel.hidden = true;
    panel.querySelector('.customer-audit-workspace')?.remove();
    [...panel.children].forEach(child => {
      if (child === tabs || child === auditPanel) return;
      child.hidden = !child.matches('#connections-view') || view !== 'connections';
    });
    if (view === 'audits') workspace(panel, auditPanel);
    content.querySelector('.compliance-overview')?.setAttribute('hidden', '');
  }
  document.addEventListener('click', event => {
    const live = event.target.closest('[data-customer-live]');
    if (live) {
      const id = live.dataset.customerLive;
      document.querySelector('[data-mira-view="connections"]')?.click();
      document.querySelector(`[data-device-card="${CSS.escape(id)}"]`)?.scrollIntoView({ block: 'center' });
    }
    const create = event.target.closest('[data-customer-create]');
    if (create) window.DemoV2Evidence.openFor(JSON.parse(create.dataset.customerCreate), create);
    const upload = event.target.closest('[data-customer-upload]');
    if (upload) {
      const spec = JSON.parse(upload.dataset.customerUpload);
      const input = document.querySelector('#evidence-file-input');
      Object.assign(input.dataset, { taskId: '', orderId: spec.orderId, componentId: spec.componentId, kind: spec.kind, title: spec.title, clauses: JSON.stringify(spec.clauses) });
      input.click();
    }
  });
  window.DemoV2CustomerLayout = { decorate };
  document.addEventListener('DOMContentLoaded', decorate);
})();