(() => {
  const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  const field = (english, german, value) => ({ label: [english, german], value });
  function sampleFields(record) {
    const suffix = record.componentId || record.orderId;
    const reference = 'DEMO-' + record.id;
    const fields = {
      'material-certificate': [field('Material / specification', 'Werkstoff / Spezifikation', 'S355J2+N - fictional sample only'), field('Heat / batch ID', 'Schmelzen- / Chargen-ID', 'DEMO-HEAT-' + suffix), field('Supplier / goods receipt', 'Lieferant / Wareneingang', 'Demo supplier / DEMO-GR-' + suffix), field('Illustrative finding', 'Beispielhafte Feststellung', 'Sample certificate and marking references match in this fictional dataset; source authenticity is not established.')],
      wps: [field('Procedure / revision', 'Verfahren / Revision', 'DEMO-WPS-' + suffix + ' / Rev 04'), field('Joint / process', 'Naht / Verfahren', 'Fictional butt weld / MAG process 135'), field('Qualification reference', 'Qualifikationsreferenz', 'DEMO-WPQR-' + suffix), field('Illustrative operating window', 'Beispielhafter Arbeitsbereich', 'Example only: current 180-220 A; interpass maximum 250 deg C. Not an approved WPS.')],
      wpqr: [field('Qualification report', 'Verfahrensprüfbericht', 'DEMO-WPQR-' + suffix), field('Testing body', 'Prüfstelle', 'Fictional Demo Welding Laboratory'), field('Scope', 'Umfang', 'Sample process 135 / structural steel joint; no actual qualification is issued.')],
      'welding-record': [field('Execution record / joint', 'Ausführungsprotokoll / Naht', reference + ' / DEMO-JOINT-01'), field('Welder / qualification', 'Schweißer / Qualifikation', 'Demo welder / DEMO-WELDER-135'), field('Procedure used', 'Verwendetes Verfahren', 'DEMO-WPS-' + suffix + ' Rev 04'), field('Illustrative readings', 'Beispielhafte Messwerte', 'Fictional example: current 196 A, voltage 24.8 V, interpass temperature 192 deg C. Not actual measurements.')],
      'inspection-report': [field('Drawing / revision', 'Zeichnung / Revision', 'DEMO-DRW-' + suffix + ' Rev C'), field('Inspection method', 'Prüfverfahren', 'Sample dimensional and visual inspection'), field('Equipment', 'Prüfmittel', 'DEMO-CALIPER-017'), field('Illustrative result / criterion', 'Beispielergebnis / Kriterium', 'Fictional dimension 250.2 mm against 250 +/- 0.5 mm; not a real inspection result.')],
      'ndt-report': [field('Procedure / inspector', 'Verfahren / Prüfer', 'DEMO-NDT-PT-02 / Demo inspector'), field('Inspection scope', 'Prüfumfang', 'Fictional joint DEMO-JOINT-01, sample surface inspection'), field('Illustrative findings', 'Beispielhafte Befunde', 'Example report with no reportable surface indication. Not an actual NDT result; qualified personnel and original report required.')],
      'calibration-certificate': [field('Equipment / serial', 'Gerät / Seriennummer', 'DEMO-CALIPER-017 / DEMO-SERIAL-007'), field('Laboratory / reference', 'Labor / Referenz', 'Fictional Calibration Laboratory / DEMO-CAL-2026-017'), field('Illustrative range / uncertainty', 'Beispielbereich / Unsicherheit', 'Example only: 0-300 mm / +/- 0.02 mm. Not a laboratory-issued calibration certificate.')],
      'controlled-document': [field('Document / owner', 'Dokument / Verantwortlicher', 'DEMO-QMS-CONTEXT-01 / Demo quality manager'), field('Revision / review', 'Revision / Prüfung', 'Rev 03 / quarterly sample review'), field('Internal issues recorded', 'Erfasste interne Themen', 'Fictional examples: welder capacity, measuring equipment availability, procedure version control.'), field('External issues recorded', 'Erfasste externe Themen', 'Fictional examples: customer delivery expectations, supplier lead times, permit changes.'), field('Review output', 'Prüfergebnis', 'Sample action owners assigned to capacity planning and supplier review; next review recorded in the demo register.')],
      'competence-record': [field('Person / role', 'Person / Rolle', 'Demo employee / inspector and welding operator'), field('Qualification / review', 'Qualifikation / Prüfung', 'DEMO-TRAIN-017 / sample annual competence assessment'), field('Illustrative assessment', 'Beispielhafte Bewertung', 'Example skill matrix records supervised practice and document-control training; no real qualification claimed.')],
      'legal-register': [field('Source reference', 'Quellreferenz', 'DEMO-PERMIT-01 / fictional condition P2'), field('Applicability assessment', 'Anwendbarkeitsbewertung', 'Demo site monitoring only; actual permit, jurisdiction and paragraph have not been supplied.'), field('Evaluation / owner', 'Bewertung / Verantwortlicher', 'Sample environmental officer review; not a legal compliance determination.')],
      'operation-check': [field('Monitoring procedure', 'Überwachungsverfahren', 'DEMO-MONITOR-01 Rev 02'), field('Equipment / period', 'Gerät / Zeitraum', 'DEMO-SENSOR-' + suffix + ' / one illustrative shift'), field('Illustrative result', 'Beispielhaftes Ergebnis', 'Fictional storage humidity mean 44 % RH, maximum 49 % RH; example limit 60 % RH. Not real device data or a permit condition.')],
      'traceability-record': [field('Identity chain', 'Identitätskette', suffix + ' → DEMO-HEAT-' + suffix + ' → DEMO-GR-' + suffix), field('Identity check', 'Identitätsprüfung', 'Fictional manual marking check and source-reference comparison; no real camera reading.')],
      'release-package': [field('Release checklist', 'Freigabecheckliste', 'DEMO-RELEASE-' + suffix + ' Rev 02'), field('Supporting records', 'Unterstützende Nachweise', 'Sample material, inspection and procedure references for this component'), field('Authority / exceptions', 'Berechtigung / Ausnahmen', 'Demo quality reviewer; this sample document does not authorize operational release.')],
      'internal-audit-report': [field('Programme / scope', 'Programm / Umfang', 'DEMO-IA-2026 / sample purchasing and production controls'), field('Findings / follow-up', 'Feststellungen / Folgemaßnahmen', 'Fictional finding: obsolete drawing at work station. Owner: Demo production lead; follow-up recorded in action register.')],
      'management-review': [field('Meeting / participants', 'Besprechung / Teilnehmer', 'DEMO-MR-Q3 / Demo managing director and quality lead'), field('Inputs / decisions', 'Eingaben / Entscheidungen', 'Sample audit results, supplier performance and capacity reviewed; fictional action to refresh calibration schedule.')],
      'corrective-action': [field('Issue / cause', 'Problem / Ursache', 'DEMO-CAPA-017 / example obsolete procedure caused by uncontrolled local copy'), field('Correction / effectiveness', 'Korrektur / Wirksamkeit', 'Fictional action: remove local copy and verify controlled revision at work station; no actual effectiveness verification.')],
      'energy-data': [field('Meter / period', 'Zähler / Zeitraum', 'DEMO-METER-04 / illustrative monthly reporting period'), field('Illustrative comparison', 'Beispielhafter Vergleich', 'Fictional consumption 42,600 kWh vs baseline 44,000 kWh; not metered data. Normalize actual results for relevant variables.')],
      'access-review': [field('System / accounts', 'System / Konten', 'DEMO-ERP / illustrative review of 24 contractor accounts'), field('Illustrative changes', 'Beispielhafte Änderungen', 'Example: two expired accounts removed and one excessive role reduced; no real IT system accessed.')],
      'security-log': [field('Log source / period', 'Logquelle / Zeitraum', 'DEMO-SIEM-01 / illustrative security review period'), field('Illustrative findings', 'Beispielhafte Befunde', 'Example alert review and incident reference; not actual security logs.')]
    };
    return [field('Sample document reference', 'Beispieldokument-Referenz', reference), ...(fields[record.kind] || [field('Illustrative work record', 'Beispielhaftes Arbeitsprotokoll', 'Fictional operation scope and source-reference review for ' + suffix)])];
  }
  function details(record) {
    const app = window.DemoV2;
    const german = app.settings.language === 'de';
    const translated = (english, germanText) => german ? germanText : english;
    const sampleTranslations = {
      'Not available': 'Nicht verfügbar', 'Not recorded': 'Nicht erfasst',
      'Not yet verified': 'Noch nicht verifiziert',
      'Sample approved status; reviewer record not available.': 'Beispielstatus freigegeben; Verifizierungsprotokoll nicht verfügbar.',
      'Attached file; inspect the source document.': 'Datei beigefügt; Quelldokument prüfen.',
      'Metadata only; no original document attached.': 'Nur Metadaten; kein Originaldokument beigefügt.',
      'Rev 03 / quarterly sample review': 'Rev 03 / vierteljährliche Beispielprüfung',
      'Fictional examples: welder capacity, measuring equipment availability, procedure version control.': 'Fiktive Beispiele: Schweißer-Kapazität, Verfügbarkeit von Messmitteln, Revisionslenkung der Verfahren.',
      'Fictional examples: customer delivery expectations, supplier lead times, permit changes.': 'Fiktive Beispiele: Liefererwartungen der Kunden, Lieferzeiten der Lieferanten, Genehmigungsänderungen.',
      'Sample action owners assigned to capacity planning and supplier review; next review recorded in the demo register.': 'Beispielhafte Maßnahmenverantwortliche für Kapazitätsplanung und Lieferantenprüfung zugewiesen; nächste Prüfung im Demoregister erfasst.',
      'Sample certificate and marking references match in this fictional dataset; source authenticity is not established.': 'Zeugnis- und Kennzeichnungsreferenzen stimmen im fiktiven Beispieldatensatz überein; die Echtheit der Quelle ist nicht bestätigt.',
      'Sample dimensional and visual inspection': 'Beispielhafte Maß- und Sichtprüfung',
      'Fictional Calibration Laboratory / DEMO-CAL-2026-017': 'Fiktives Kalibrierlabor / DEMO-CAL-2026-017',
      'Sample environmental officer review; not a legal compliance determination.': 'Beispielprüfung durch Umweltbeauftragte; keine Feststellung rechtlicher Konformität.',
      'Demo quality reviewer; this sample document does not authorize operational release.': 'Demo-Qualitätsprüfer; dieses Beispieldokument berechtigt nicht zur betrieblichen Freigabe.'
    };
    const order = app.operations.orders.find(item => item.id === record.orderId);
    const verified = app.compliance.verifiedBy.find(item => item.evidenceId === record.id);
    const fields = [field('Record ID', 'Datensatz-ID', record.id), field('Order / component', 'Auftrag / Bauteil', record.orderId + ' / ' + record.componentId), field('Customer / site', 'Kunde / Standort', order ? order.customer + ' / ' + order.site : 'Not available'), field('Captured by / at', 'Erfasst von / am', (record.createdBy || 'Not recorded') + ' / ' + (record.createdAt || 'Not recorded'))];
    if (record.telemetry) {
      const device = window.DemoV2PhysicalAI?.devices.find(item => item.id === record.deviceId);
      const telemetry = record.telemetry;
      fields.push(field('Device / protocol', 'Gerät / Protokoll', record.deviceId + ' / ' + (device?.protocol || record.provenance?.protocol || translated('Not recorded', 'Nicht erfasst'))), field('Captured window', 'Erfasstes Fenster', telemetry.startedAt + ' → ' + telemetry.lastAt), field('Recorded samples', 'Erfasste Messwerte', String(telemetry.count)), field('Min / mean / max', 'Minimum / Mittelwert / Maximum', [telemetry.min, telemetry.count ? telemetry.sum / telemetry.count : null, telemetry.max].map(value => value == null ? '-' : Number(value).toLocaleString(german ? 'de-DE' : 'en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })).join(' / ') + ' ' + (device?.unit || '')), field('Flagged deviations', 'Markierte Abweichungen', String(telemetry.exceedances?.length || 0)), field('Rule source', 'Regelquelle', device?.limit ? device.limit[german ? 1 : 0] : translated('Not recorded', 'Nicht erfasst')));
    } else if (record.demoDetails) fields.push(...record.demoDetails);
    else if (record.authoredData) {
      for (const [key, value] of Object.entries(record.authoredData)) if (typeof value === 'string' && !['orderId', 'taskId', 'componentId'].includes(key)) fields.push(field(key, key, value));
    } else fields.push(field('Available content', 'Verfügbarer Inhalt', record.dataUrl ? 'Attached file; inspect the source document.' : 'Metadata only; no original document attached.'));
    fields.push(field('Verification', 'Verifizierung', verified ? verified.user + ' / ' + verified.time : record.status === 'approved' ? 'Sample approved status; reviewer record not available.' : 'Not yet verified'));
    return fields.map(item => ({ ...item, value: german ? sampleTranslations[item.value] || item.value : item.value }));
  }
  function enrichSamples() {
    const app = window.DemoV2;
    const operations = structuredClone(app.operations);
    if (operations.clauseEvidenceDetailsV1) return;
    for (const record of operations.evidence) {
      if (!record.sample || !/^EV-(EXP-|S-)/.test(record.id) || record.origin === 'astra-authored' || record.demoDetails) continue;
      record.demoDetails = sampleFields(record);
      let document;
      if (record.dataUrl?.startsWith('data:text/html;base64,')) {
        const decoded = new TextDecoder().decode(Uint8Array.from(atob(record.dataUrl.split(',')[1]), character => character.charCodeAt(0)));
        document = new DOMParser().parseFromString(decoded, 'text/html');
      } else document = new DOMParser().parseFromString('<!doctype html><html><head><meta charset="utf-8"><title>Fictional evidence sample</title><style>body{font:14px/1.6 sans-serif;max-width:850px;margin:32px auto;padding:20px}dt{font-weight:bold}dd{margin:0 0 12px;overflow-wrap:anywhere}</style></head><body></body></html>', 'text/html');
      const section = document.createElement('section');
      section.innerHTML = `<h2>${esc(record.title)}</h2><p><strong>FICTIONAL DEMO DETAILS - NOT ACTUAL TEST RESULTS OR A THIRD-PARTY CERTIFICATE</strong></p><dl>${record.demoDetails.map(item => `<dt>${esc(item.label[0])}</dt><dd>${esc(item.value)}</dd>`).join('')}</dl><p>Order ${esc(record.orderId)} / component ${esc(record.componentId)}. Status and verification remain those recorded in the demo; these details do not establish conformity.</p>`;
      document.body.append(section);
      const bytes = new TextEncoder().encode('<!doctype html>' + document.documentElement.outerHTML);
      record.dataUrl = 'data:text/html;base64,' + btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join(''));
      record.mimeType = 'text/html';
      record.fileName = record.fileName.replace(/\.[^.]+$/, '') + '.html';
      record.size = bytes.length;
    }
    operations.clauseEvidenceDetailsV1 = true;
    try { localStorage.setItem('rosnie-demo-v2-operations-v1', JSON.stringify(operations)); } catch { return; }
    Object.assign(app.operations, operations);
    app.render();
  }
  window.DemoV2EvidenceDetail = { details };
  document.addEventListener('DOMContentLoaded', enrichSamples);
})();