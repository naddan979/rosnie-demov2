// Mock dataset for the OpsComply demo dashboard.
// All data is fictional and generated for demonstration purposes only.

const DASHBOARD_DATA = {

  meta: {
    lastUpdated: "2026-09-15T09:42:00",
    refreshStatus: "Live feed connected",
    source: "Site telemetry, control attestations and compliance workflows"
  },

  organization: {
    groups: [{ id: "g1", name: "rosnie Group" }],
    subsidiaries: [
      { id: "sub1", groupId: "g1", name: "North Operations" },
      { id: "sub2", groupId: "g1", name: "West Operations" },
      { id: "sub3", groupId: "g1", name: "East Operations" }
    ]
  },

  thresholds: {
    compliant: 80,
    driftWarning: 70,
    critical: 50,
    yearEndTarget: 80
  },

  regulations: [
    // Emissions & Carbon
    { id: "r1", name: "EU ETS", category: "Emissions & Carbon", status: "compliant", score: 96, owner: "Compliance Team A", lastAudit: "2026-03-14", nextReview: "2026-11-01" },
    { id: "r2", name: "CBAM", category: "Emissions & Carbon", status: "in-progress", score: 68, owner: "Compliance Team A", lastAudit: "2026-05-02", nextReview: "2026-10-15" },
    { id: "r3", name: "GHG Protocol", category: "Emissions & Carbon", status: "compliant", score: 91, owner: "Compliance Team B", lastAudit: "2026-02-20", nextReview: "2027-02-20" },
    { id: "r4", name: "CSRD / ESRS", category: "Emissions & Carbon", status: "at-risk", score: 54, owner: "Compliance Team B", lastAudit: "2026-06-10", nextReview: "2026-09-30" },
    { id: "r18", name: "CO2 Reporting", category: "Emissions & Carbon", status: "in-progress", score: 74, owner: "Compliance Team A", lastAudit: "2026-08-15", nextReview: "2026-10-30" },

    // Production & Manufacturing
    { id: "r5", name: "ISO 50001", category: "Production & Manufacturing", status: "compliant", score: 93, owner: "Operations Team A", lastAudit: "2026-01-18", nextReview: "2027-01-18" },
    { id: "r6", name: "GMP", category: "Production & Manufacturing", status: "compliant", score: 89, owner: "Operations Team A", lastAudit: "2026-04-05", nextReview: "2026-12-05" },
    { id: "r7", name: "REACH", category: "Production & Manufacturing", status: "in-progress", score: 71, owner: "Operations Team B", lastAudit: "2026-05-22", nextReview: "2026-10-01" },
    { id: "r8", name: "CLP", category: "Production & Manufacturing", status: "compliant", score: 88, owner: "Operations Team B", lastAudit: "2026-03-30", nextReview: "2027-03-30" },

    // Supply Chain & Sourcing
    { id: "r9", name: "RED III", category: "Supply Chain & Sourcing", status: "at-risk", score: 58, owner: "Procurement Team A", lastAudit: "2026-04-11", nextReview: "2026-09-25" },
    { id: "r10", name: "SURE", category: "Supply Chain & Sourcing", status: "compliant", score: 94, owner: "Procurement Team A", lastAudit: "2026-06-01", nextReview: "2027-06-01" },
    { id: "r11", name: "ISCC", category: "Supply Chain & Sourcing", status: "compliant", score: 90, owner: "Procurement Team A", lastAudit: "2026-05-15", nextReview: "2027-05-15" },

    // Process Safety & Quality
    { id: "r12", name: "Seveso III", category: "Process Safety & Quality", status: "non-compliant", score: 39, owner: "Safety Team A", lastAudit: "2026-07-01", nextReview: "2026-09-20" },
    { id: "r13", name: "IEC 61508", category: "Process Safety & Quality", status: "compliant", score: 85, owner: "Safety Team A", lastAudit: "2026-02-14", nextReview: "2027-02-14" },
    { id: "r14", name: "IEC 61511", category: "Process Safety & Quality", status: "in-progress", score: 66, owner: "Safety Team A", lastAudit: "2026-04-28", nextReview: "2026-10-05" },

    // Environmental
    { id: "r15", name: "ISO 9001", category: "Environmental", status: "compliant", score: 92, owner: "Quality Team A", lastAudit: "2026-01-09", nextReview: "2027-01-09" },
    { id: "r16", name: "Waste Regulation", category: "Environmental", status: "compliant", score: 87, owner: "Quality Team A", lastAudit: "2026-03-19", nextReview: "2026-12-19" },
    { id: "r17", name: "Water Permits", category: "Environmental", status: "at-risk", score: 61, owner: "Quality Team A", lastAudit: "2026-05-30", nextReview: "2026-09-18" },
  ],

  sites: [
    { id: "s1", name: "Production Site A", location: "Region North", groupId: "g1", subsidiaryId: "sub1", status: "running", output: "38.2 MW", outputTarget: "40 MW", uptime: 98.4, efficiency: 94.1, lastIncident: "2026-06-02", ebitda: 1850000, costPerUnit: 42.50, energyCostPerUnit: 28.10, co2PerUnit: 0.42, co2Cost: 8.80, potentialExposure: 185000, energyManagementScore: 91, qualityScore: 96, employees: 84, outlook: "Expansion ready", yearEndRisk: "On Track", lastDataAt: "2026-09-14T10:41:00" },
    { id: "s2", name: "Production Site B", location: "Region North", groupId: "g1", subsidiaryId: "sub1", status: "running", output: "24.7 MW", outputTarget: "25 MW", uptime: 99.1, efficiency: 96.0, lastIncident: "—", ebitda: 1420000, costPerUnit: 39.80, energyCostPerUnit: 26.40, co2PerUnit: 0.35, co2Cost: 7.40, potentialExposure: 120000, energyManagementScore: 95, qualityScore: 98, employees: 61, outlook: "Stable / efficient", yearEndRisk: "On Track", lastDataAt: "2026-09-14T10:39:00" },
    { id: "s3", name: "Production Site C", location: "Region West", groupId: "g1", subsidiaryId: "sub2", status: "maintenance", output: "0 MW", outputTarget: "18 MW", uptime: 81.2, efficiency: 0, lastIncident: "2026-09-08", ebitda: -180000, costPerUnit: 58.90, energyCostPerUnit: 41.20, co2PerUnit: 0.88, co2Cost: 19.60, potentialExposure: 1250000, energyManagementScore: 62, qualityScore: 58, employees: 47, outlook: "Recovery plan required", yearEndRisk: "At Risk", lastDataAt: "2026-09-14T10:18:00" },
    { id: "s4", name: "Production Site D", location: "Region West", groupId: "g1", subsidiaryId: "sub2", status: "running", output: "12.4 MW", outputTarget: "14 MW", uptime: 95.6, efficiency: 88.7, lastIncident: "2026-07-19", ebitda: 640000, costPerUnit: 47.30, energyCostPerUnit: 31.60, co2PerUnit: 0.51, co2Cost: 10.70, potentialExposure: 260000, energyManagementScore: 84, qualityScore: 89, employees: 39, outlook: "Modernisation planned", yearEndRisk: "On Track", lastDataAt: "2026-09-14T10:40:00" },
    { id: "s5", name: "Production Site E", location: "Region East", groupId: "g1", subsidiaryId: "sub3", status: "stopped", output: "0 MW", outputTarget: "30 MW", uptime: 62.3, efficiency: 0, lastIncident: "2026-09-10", ebitda: -320000, costPerUnit: 71.40, energyCostPerUnit: 49.80, co2PerUnit: 1.24, co2Cost: 28.90, potentialExposure: 1680000, energyManagementScore: 40, qualityScore: 41, employees: 52, outlook: "Board review / reset", yearEndRisk: "Critical", lastDataAt: "2026-09-14T09:56:00" },
  ],

  inventory: [
    { id: "i1", sku: "BAT-CELL-2170", name: "Lithium Cell 21700", category: "Battery Cells", location: "Warehouse A", stock: 18500, reorder: 15000, unit: "pcs" },
    { id: "i2", sku: "INV-3PH-250K", name: "3-Phase Inverter 250kW", category: "Power Electronics", location: "Warehouse B", stock: 12, reorder: 15, unit: "units" },
    { id: "i3", sku: "BMS-CTRL-04", name: "Battery Management Controller v4", category: "Electronics", location: "Warehouse A", stock: 340, reorder: 200, unit: "units" },
    { id: "i4", sku: "TRANS-1000KVA", name: "Transformer 1000 kVA", category: "Grid Equipment", location: "Warehouse C", stock: 3, reorder: 4, unit: "units" },
    { id: "i5", sku: "CABLE-XLPE-95", name: "XLPE Power Cable 95mm²", category: "Cabling", location: "Warehouse B", stock: 8200, reorder: 5000, unit: "m" },
    { id: "i6", sku: "FIRE-SUPP-KIT", name: "Fire Suppression Kit", category: "Safety Equipment", location: "Warehouse C", stock: 6, reorder: 10, unit: "kits" },
    { id: "i7", sku: "COOL-UNIT-HVAC", name: "HVAC Cooling Unit", category: "Thermal Management", location: "Warehouse A", stock: 27, reorder: 20, unit: "units" },
  ],

  deliveries: [
    { id: "del1", expectedDate: "2026-09-16", supplier: "Partner Company A", material: "BMS Controller v4", quantity: "120 units", site: "Production Site A", contract: "BMS Controller Supply Agreement", status: "Confirmed", timing: "This week", relevance: "BMS Controller quality gate", kpi: "Quality release readiness", impact: 85000 },
    { id: "del2", expectedDate: "2026-09-18", supplier: "Partner Company G", material: "Fire Suppression Kits", quantity: "18 kits", site: "Production Site C", contract: "Fire Safety Equipment Contract", status: "At Risk", timing: "This week", relevance: "Seveso III · external audit", kpi: "Seveso compliance score", impact: 1250000 },
    { id: "del3", expectedDate: "2026-09-22", supplier: "Partner Company C", material: "Lithium Cell 21700", quantity: "8,000 pcs", site: "Production Site B", contract: "Battery Cell Framework Contract", status: "In Transit", timing: "Next 30 days", relevance: "RED III · supplier traceability", kpi: "Supply chain compliance", impact: 180000 },
    { id: "del4", expectedDate: "2026-09-29", supplier: "Partner Company F", material: "Transformer Maintenance Kit", quantity: "3 units", site: "Production Site D", contract: "Transformer Maintenance Contract", status: "Planned", timing: "Next 30 days", relevance: "ISO 50001 · internal control", kpi: "Uptime and energy efficiency", impact: 260000 },
    { id: "del5", expectedDate: "2026-10-05", supplier: "Partner Company B", material: "Grid service components", quantity: "24 units", site: "Production Site E", contract: "Grid Maintenance Services", status: "Planned", timing: "Future", relevance: "Water Permits · external reporting", kpi: "Production recovery", impact: 420000 },
  ],

  purchaseRecommendations: [
    { material: "Fire Suppression Kits", reason: "Critical stock below reorder point and Seveso delivery at risk.", action: "Expedite 18 kits", urgency: "Immediate", tone: "red" },
    { material: "BMS Controller v4", reason: "Market lead time rising 12%; current stock covers 3 weeks.", action: "Create SAP purchase order", urgency: "This week", tone: "yellow" },
    { material: "Transformer Maintenance Kit", reason: "Maintenance backlog and Site D uptime risk increase demand.", action: "Reserve 3 units", urgency: "Plan", tone: "blue" }
  ],

  purchaseDecisionSignals: [
    { material: "Fire Suppression Kits", contract: "Fire Safety Equipment Contract", supplier: "Partner Company G", suggestedAmount: 18, unit: "kits", confidence: "High", market: "Lead times rising 18%", operations: "Site C maintenance and Seveso control gap", inventory: "6 kits on hand vs 10-kit reorder point", reason: "Protect Seveso readiness and avoid production delay at Site C." },
    { material: "BMS Controller v4", contract: "BMS Controller Supply Agreement", supplier: "Partner Company A", suggestedAmount: 120, unit: "units", confidence: "Medium", market: "Market lead time rising 12%", operations: "Site A running at 94.1% efficiency", inventory: "340 units on hand; 3-week coverage", reason: "Secure supply before lead-time pressure affects the active production plan." },
    { material: "Transformer Maintenance Kit", contract: "Transformer Maintenance Contract", supplier: "Partner Company F", suggestedAmount: 3, unit: "kits", confidence: "Medium", market: "Stable pricing", operations: "Maintenance backlog affects uptime recovery", inventory: "3 units required for planned work", reason: "Protect Site D uptime and prevent maintenance work from slipping." }
  ],

  purchaseOrders: [
    { id: "po1", poNumber: "PO-2026-0418", supplier: "Partner Company A", site: "Production Site A", contract: "BMS Controller Supply Agreement", document: "PO + delivery note pending", invoice: "Not received", expectedDate: "2026-09-16", status: "Awaiting delivery" },
    { id: "po2", poNumber: "PO-2026-0421", supplier: "Partner Company G", site: "Production Site C", contract: "Fire Safety Equipment Contract", document: "PO issued · note missing", invoice: "Blocked: receipt missing", expectedDate: "2026-09-18", status: "At Risk" },
    { id: "po3", poNumber: "PO-2026-0402", supplier: "Partner Company C", site: "Production Site B", contract: "Battery Cell Framework Contract", document: "Delivery note DN-8831", invoice: "3-way match passed", expectedDate: "2026-09-22", status: "In Transit" },
    { id: "po4", poNumber: "PO-2026-0430", supplier: "Partner Company F", site: "Production Site D", contract: "Transformer Maintenance Contract", document: "Create PO", invoice: "Not started", expectedDate: "2026-09-29", status: "Ready to order" },
  ],

  sap: {
    lastSync: "2026-09-15T09:42:00",
    source: "SAP S/4HANA demo feed",
    contractsImported: 7,
    suppliersImported: 6,
    purchaseOrdersImported: 4,
    invoicesInFlow: 4
  },

  supplierProfiles: [
    { supplier: "Partner Company A", certifications: ["ISO 9001", "ISO 14001", "IATF 16949"], externalReport: "External audit passed · Q2 2026", flag: "Expiry approaching", contractedEur: 1240000, contractedAmount: 120, amountUnit: "BMS controllers", expiry: "2026-09-28" },
    { supplier: "Partner Company B", certifications: ["ISO 9001", "ISO 45001"], externalReport: "External audit observations", flag: "Certification expired", contractedEur: 380000, contractedAmount: 24, amountUnit: "Grid service lots", expiry: "2025-12-01" },
    { supplier: "Partner Company C", certifications: ["ISO 9001", "ISO 45001"], externalReport: "External sustainability report received", flag: "No flag", contractedEur: 6500000, contractedAmount: 8000, amountUnit: "Lithium cells", expiry: "2027-01-15" },
    { supplier: "Partner Company F", certifications: ["ISO 9001", "ISO 14001"], externalReport: "External audit passed · Q1 2026", flag: "No flag", contractedEur: 65000, contractedAmount: 3, amountUnit: "Maintenance kits", expiry: "2027-06-01" },
    { supplier: "Partner Company G", certifications: ["ISO 9001", "EN 15004"], externalReport: "External audit scheduled", flag: "Expiry approaching", contractedEur: 48000, contractedAmount: 18, amountUnit: "Fire safety kits", expiry: "2026-09-15" }
  ],

  testing: [
    { id: "t1", component: "BMS Controller v4 – Batch 12", stage: "Endurance Test", lab: "Internal Lab 2", progress: 72, started: "2026-08-01", expected: "2026-09-25", result: "pending" },
    { id: "t2", component: "Battery Cell 21700 – Lot 88", stage: "Incoming Inspection", lab: "Internal Lab 1", progress: 100, started: "2026-08-20", expected: "2026-09-05", result: "pass" },
    { id: "t3", component: "Inverter 250kW – Rev C", stage: "Functional Test", lab: "External Lab A", progress: 45, started: "2026-08-28", expected: "2026-10-10", result: "pending" },
    { id: "t4", component: "Fire Suppression Kit", stage: "Certification Test", lab: "External Lab B", progress: 30, started: "2026-09-01", expected: "2026-10-20", result: "pending" },
    { id: "t5", component: "Transformer 1000 kVA – Unit #3", stage: "Functional Test", lab: "Internal Lab 2", progress: 100, started: "2026-07-15", expected: "2026-08-30", result: "fail" },
    { id: "t6", component: "Cooling Unit HVAC – Batch 5", stage: "Endurance Test", lab: "Internal Lab 1", progress: 88, started: "2026-08-10", expected: "2026-09-18", result: "pending" },
  ],

  contracts: [
    { id: "c1", title: "BMS Controller Supply Agreement", partner: "Partner Company A", type: "Supply", value: "€1,240,000", start: "2024-01-01", end: "2026-10-05" },
    { id: "c2", title: "Grid Maintenance Services", partner: "Partner Company B", type: "Maintenance", value: "€380,000", start: "2023-06-01", end: "2026-12-31" },
    { id: "c3", title: "Battery Cell Framework Contract", partner: "Partner Company C", type: "Supply", value: "€6,500,000", start: "2022-03-01", end: "2027-03-01" },
    { id: "c4", title: "Site Lease – Facility A", partner: "Partner Company D", type: "Lease", value: "€92,000 / yr", start: "2021-01-01", end: "2026-09-30" },
    { id: "c5", title: "Auditing & Certification Services", partner: "Partner Company E", type: "Service", value: "€150,000", start: "2024-01-01", end: "2026-11-15" },
    { id: "c6", title: "Transformer Maintenance Contract", partner: "Partner Company F", type: "Maintenance", value: "€65,000", start: "2023-01-01", end: "2027-06-01" },
    { id: "c7", title: "Fire Safety Equipment Contract", partner: "Partner Company G", type: "Supply", value: "€48,000", start: "2024-05-01", end: "2026-09-22" },
  ],

  partners: [
    {
      id: "p1", name: "Partner Company A", type: "Supplier",
      certifications: [
        { name: "ISO 9001", validUntil: "2027-02-01" },
        { name: "ISO 14001", validUntil: "2026-10-01" },
        { name: "IATF 16949", validUntil: "2026-09-28" },
      ],
      lastAudit: "2026-02-01", nextAudit: "2027-02-01", auditResult: "Passed",
    },
    {
      id: "p2", name: "Partner Company C", type: "Supplier",
      certifications: [
        { name: "ISO 9001", validUntil: "2027-05-01" },
        { name: "ISO 45001", validUntil: "2027-01-15" },
      ],
      lastAudit: "2026-05-01", nextAudit: "2027-05-01", auditResult: "Passed with observations",
    },
    {
      id: "p3", name: "Partner Company B", type: "Contractor",
      certifications: [
        { name: "ISO 9001", validUntil: "2026-09-30" },
        { name: "ISO 45001", validUntil: "2025-12-01" },
      ],
      lastAudit: "2025-09-30", nextAudit: "2026-09-30", auditResult: "Passed with observations",
    },
    {
      id: "p4", name: "Partner Company E", type: "Auditor",
      certifications: [
        { name: "ISO 17020", validUntil: "2028-01-01" },
      ],
      lastAudit: "2026-03-10", nextAudit: "2027-03-10", auditResult: "Passed",
    },
    {
      id: "p5", name: "Partner Company G", type: "Supplier",
      certifications: [
        { name: "ISO 9001", validUntil: "2026-09-25" },
        { name: "EN 15004", validUntil: "2026-09-15" },
      ],
      lastAudit: "2025-09-25", nextAudit: "2026-09-25", auditResult: "Scheduled",
    },
    {
      id: "p6", name: "Partner Company F", type: "Contractor",
      certifications: [
        { name: "ISO 9001", validUntil: "2027-06-01" },
        { name: "ISO 14001", validUntil: "2027-06-01" },
      ],
      lastAudit: "2026-06-01", nextAudit: "2027-06-01", auditResult: "Passed",
    },
  ],

  supplierStandards: [
    { supplier: "Partner Company A", standards: ["ISO 9001", "ISO 14001", "IATF 16949"], regulations: ["REACH", "GMP"], risk: "Certification expiry approaching" },
    { supplier: "Partner Company B", standards: ["ISO 9001", "ISO 45001"], regulations: ["Seveso III", "ISO 50001"], risk: "Certification expired" },
    { supplier: "Partner Company C", standards: ["ISO 9001", "ISO 45001"], regulations: ["RED III", "SURE", "ISCC"], risk: "Low" },
    { supplier: "Partner Company E", standards: ["ISO 17020"], regulations: ["ISO 9001"], risk: "Low" },
    { supplier: "Partner Company F", standards: ["ISO 9001", "ISO 14001"], regulations: ["REACH", "ISO 50001"], risk: "Low" },
    { supplier: "Partner Company G", standards: ["ISO 9001", "EN 15004"], regulations: ["Seveso III", "GMP"], risk: "Certification expiry approaching" },
  ],

  // Estimated financial exposure linked to current compliance gaps.
  riskExposure: [
    { id: "e1", regulation: "Seveso III", category: "Process Safety & Quality", exposureType: "Regulatory Fine & Shutdown Risk", probability: "High", severity: "Critical", estimatedExposure: 2500000, description: "Non-compliance with major-accident prevention duties could trigger fines and a forced production stop." },
    { id: "e2", regulation: "CSRD / ESRS", category: "Emissions & Carbon", exposureType: "Reporting Penalty", probability: "Medium", severity: "High", estimatedExposure: 450000, description: "Incomplete sustainability reporting ahead of the filing deadline risks penalties and investor scrutiny." },
    { id: "e3", regulation: "RED III", category: "Supply Chain & Sourcing", exposureType: "Market Access Restriction", probability: "Medium", severity: "Medium", estimatedExposure: 800000, description: "Feedstock sourcing gaps could restrict access to preferential renewable-energy markets." },
    { id: "e4", regulation: "Water Permits", category: "Environmental", exposureType: "Operational Restriction", probability: "Medium", severity: "Medium", estimatedExposure: 150000, description: "Permit renewal delays could force throttling of water-dependent production processes." },
    { id: "e5", regulation: "CBAM", category: "Emissions & Carbon", exposureType: "Carbon Cost Pass-Through", probability: "High", severity: "Medium", estimatedExposure: 620000, description: "Underreported embedded emissions increase certificate purchase costs at the border." },
    { id: "e6", regulation: "REACH", category: "Production & Manufacturing", exposureType: "Product Recall Risk", probability: "Low", severity: "Medium", estimatedExposure: 300000, description: "Incomplete substance registration could require reformulation or recall of affected products." },
  ],

  // Regulations not yet in force, with expected operational/financial impact.
  upcomingRegulations: [
    { id: "u1", name: "EU ETS2 (Buildings & Road Transport)", category: "Emissions & Carbon", effectiveDate: "2027-01-01", expectedImpact: "High", estimatedCost: 1200000, summary: "Extends emissions trading to fuel suppliers, indirectly raising energy and transport costs across all sites." },
    { id: "u2", name: "CBAM Definitive Period", category: "Emissions & Carbon", effectiveDate: "2027-01-01", expectedImpact: "High", estimatedCost: 950000, summary: "Importers must purchase CBAM certificates matching the embedded carbon emissions of imported materials." },
    { id: "u3", name: "CSRD Wave 2 Reporting", category: "Emissions & Carbon", effectiveDate: "2027-01-01", expectedImpact: "Medium", estimatedCost: 280000, summary: "Extended double-materiality sustainability reporting obligations apply to additional subsidiaries." },
    { id: "u4", name: "EU Deforestation Regulation (EUDR)", category: "Supply Chain & Sourcing", effectiveDate: "2026-12-30", expectedImpact: "Medium", estimatedCost: 180000, summary: "New due-diligence and traceability requirements for supply chains linked to deforestation-risk commodities." },
    { id: "u5", name: "Revised F-Gas Regulation", category: "Environmental", effectiveDate: "2027-01-01", expectedImpact: "Low", estimatedCost: 90000, summary: "Further phase-down of fluorinated greenhouse gases used in site cooling systems." },
  ],

  // MIRA Module — Managed Document Repository
  documents: [
    { id: "d1", title: "Seveso III Major-Accident Prevention Plan 2026", type: "Safety Plan", module: "Astra", category: "Process Safety", size: "2.4 MB", uploadDate: "2026-06-15", status: "Active", entities: ["Seveso III", "Production Site C", "Safety Team A"] },
    { id: "d2", title: "ISO 50001 Energy Management Audit Certificate", type: "Certificate", module: "Astra", category: "Manufacturing", size: "1.1 MB", uploadDate: "2026-01-20", status: "Active", entities: ["ISO 50001", "Production Site A", "Operations Team A"] },
    { id: "d3", title: "RED III Feedstock Sustainability Declaration & Mass Balance", type: "Declaration", module: "Nova", category: "Supply Chain", size: "3.8 MB", uploadDate: "2026-04-12", status: "Under Review", entities: ["RED III", "Partner Company C", "Procurement Team A"] },
    { id: "d4", title: "BMS Controller v4 Qualification & Lab Test Protocol", type: "Test Protocol", module: "Astra", category: "Quality Control", size: "5.2 MB", uploadDate: "2026-08-05", status: "Active", entities: ["BMS Controller v4", "Internal Lab 2", "Partner Company A"] },
    { id: "d5", title: "EU ETS Carbon Emissions Verification Report Q2", type: "Verification Report", module: "Astra", category: "Emissions & Carbon", size: "4.1 MB", uploadDate: "2026-07-02", status: "Active", entities: ["EU ETS", "Production Site A", "Compliance Team A"] },
    { id: "d6", title: "Framework Master Supply Agreement — Cell Tech Components", type: "Contract", module: "Nova", category: "Procurement", size: "1.8 MB", uploadDate: "2024-01-10", status: "Expiring Soon", entities: ["Partner Company A", "BMS Controller v4"] },
    { id: "d7", title: "SURE Biomass Sustainability Certificate", type: "Certificate", module: "Nova", category: "Supply Chain", size: "0.9 MB", uploadDate: "2026-06-03", status: "Active", entities: ["SURE", "Procurement Team A"] },
    { id: "d8", title: "Water Permit Approval & Discharge License — Site A", type: "Permit", module: "Astra", category: "Environmental", size: "2.0 MB", uploadDate: "2026-05-31", status: "At Risk", entities: ["Water Permits", "Production Site A", "Quality Team A"] },
  ],

  // MIRA Module — Knowledge Graph (Entities & Relationships)
  knowledgeGraph: {
    nodes: [
      { id: "reg-seveso", label: "Seveso III", type: "Regulation", module: "Astra", status: "Non-Compliant", detail: "Process Safety & Quality" },
      { id: "reg-ets", label: "EU ETS", type: "Regulation", module: "Astra", status: "Compliant", detail: "Emissions & Carbon" },
      { id: "reg-red3", label: "RED III", type: "Regulation", module: "Nova", status: "At Risk", detail: "Supply Chain Sourcing" },
      { id: "reg-iso50001", label: "ISO 50001", type: "Regulation", module: "Astra", status: "Compliant", detail: "Energy Management" },

      { id: "site-a", label: "Production Site A", type: "Site", module: "Astra", status: "Running", detail: "38.2 MW Output" },
      { id: "site-c", label: "Production Site C", type: "Site", module: "Astra", status: "Maintenance", detail: "Site Under Maintenance" },

      { id: "comp-bms", label: "BMS Controller v4", type: "Component", module: "Nova", status: "Stock OK", detail: "Stock: 340 units" },
      { id: "comp-cell", label: "Lithium Cell 21700", type: "Component", module: "Nova", status: "High Stock", detail: "Stock: 18,500 pcs" },

      { id: "part-a", label: "Partner Company A", type: "Partner", module: "Nova", status: "Supplier", detail: "ISO 9001 / ISO 14001" },
      { id: "part-c", label: "Partner Company C", type: "Partner", module: "Nova", status: "Supplier", detail: "Battery Cell Vendor" },

      { id: "doc-seveso-plan", label: "Seveso Safety Plan 2026", type: "Document", module: "Mira", status: "Active", detail: "2.4 MB PDF" },
      { id: "doc-ets-report", label: "EU ETS Verification Report", type: "Document", module: "Mira", status: "Active", detail: "4.1 MB PDF" },
      { id: "doc-bms-protocol", label: "BMS Qualification Protocol", type: "Document", module: "Mira", status: "Active", detail: "5.2 MB PDF" },
      { id: "doc-red3-decl", label: "RED III Mass Balance Decl.", type: "Document", module: "Mira", status: "Under Review", detail: "3.8 MB PDF" },
    ],

    edges: [
      { source: "site-c", target: "reg-seveso", label: "Governed By" },
      { source: "doc-seveso-plan", target: "reg-seveso", label: "Documents Compliance" },
      { source: "doc-seveso-plan", target: "site-c", label: "Applies To" },

      { source: "site-a", target: "reg-ets", label: "Monitored Under" },
      { source: "doc-ets-report", target: "reg-ets", label: "Verifies Emissions" },
      { source: "doc-ets-report", target: "site-a", label: "Audits Facility" },

      { source: "part-a", target: "comp-bms", label: "Supplies Component" },
      { source: "doc-bms-protocol", target: "comp-bms", label: "Validates Spec" },
      { source: "doc-bms-protocol", target: "part-a", label: "Co-authored With" },

      { source: "part-c", target: "comp-cell", label: "Supplies Material" },
      { source: "part-c", target: "reg-red3", label: "Subject To" },
      { source: "doc-red3-decl", target: "reg-red3", label: "Certifies Origin" },
      { source: "doc-red3-decl", target: "part-c", label: "Issued By" },

      { source: "site-a", target: "reg-iso50001", label: "Certified Under" },
    ]
  },

  // ASTRA Module — Asset Management
  assets: [
    { id: "ast-1", name: "High-Capacity Inverter Bank #1", site: "Production Site A", category: "Power Conversion", status: "Operational", health: 98, riskLevel: "Low", lastMaintenance: "2026-05-10", nextMaintenance: "2026-11-10", reports: ["Asset Health Audit", "Risk Assessment PDF"] },
    { id: "ast-2", name: "HV Transformer Station 110kV", site: "Production Site A", category: "Grid Connection", status: "Operational", health: 92, riskLevel: "Low", lastMaintenance: "2026-03-14", nextMaintenance: "2026-09-20", reports: ["Grid Safety Report", "Thermal Scan PDF"] },
    { id: "ast-3", name: "Cooling Loop & HVAC System B", site: "Production Site B", category: "Thermal Systems", status: "Degraded", health: 74, riskLevel: "Medium", lastMaintenance: "2026-02-01", nextMaintenance: "2026-09-18", reports: ["Cooling Diagnostic Report"] },
    { id: "ast-4", name: "Battery Container Racks Row 4", site: "Production Site C", category: "Energy Storage", status: "In Maintenance", health: 58, riskLevel: "Critical Risk", lastMaintenance: "2026-09-08", nextMaintenance: "2026-09-22", reports: ["Root Cause Failure Analysis", "Safety Risk Audit"] },
    { id: "ast-5", name: "BMS Supervisory Server Alpha", site: "Production Site D", category: "Control Electronics", status: "Operational", health: 95, riskLevel: "Low", lastMaintenance: "2026-06-30", nextMaintenance: "2026-12-30", reports: ["Firmware Compliance Log"] },
    { id: "ast-6", name: "Substation Circuit Breaker Unit", site: "Production Site E", category: "Protection Systems", status: "Offline", health: 42, riskLevel: "Critical Risk", lastMaintenance: "2026-09-10", nextMaintenance: "2026-09-16", reports: ["Breaker Inspection Report", "Environmental Risk PDF"] },
  ],

  // ASTRA Module — Performance Reports
  performanceReports: [
    { id: "pr-1", title: "Q3 Operational Efficiency & Uptime Audit", period: "Q3 2026", scope: "All Sites", outputAvg: "75.3 MW", uptimeAvg: "90.9%", efficiencyScore: "93.4%", generatedDate: "2026-09-01", author: "Operations Team A", type: "Quarterly Performance", status: "Finalized" },
    { id: "pr-2", title: "Production Site A Peak Output & Degradation Analysis", period: "Aug 2026", scope: "Production Site A", outputAvg: "38.2 MW", uptimeAvg: "98.4%", efficiencyScore: "94.1%", generatedDate: "2026-08-31", author: "Operations Team A", type: "Site Deep Dive", status: "Finalized" },
    { id: "pr-3", title: "Production Site C Outage & Maintenance Downtime Report", period: "Aug 2026", scope: "Production Site C", outputAvg: "0.0 MW", uptimeAvg: "81.2%", efficiencyScore: "0.0%", generatedDate: "2026-09-09", author: "Safety Team A", type: "Outage Audit", status: "Under Review" },
    { id: "pr-4", title: "Grid Ancillary Services Reliability Benchmark", period: "H1 2026", scope: "Region North & West", outputAvg: "62.9 MW", uptimeAvg: "96.2%", efficiencyScore: "91.8%", generatedDate: "2026-07-15", author: "Compliance Team B", type: "Benchmark", status: "Finalized" },
    { id: "pr-5", title: "Monthly Site Efficiency & CO2 Intensity Summary", period: "Aug 2026", scope: "All Sites", outputAvg: "75.3 MW", uptimeAvg: "91.5%", efficiencyScore: "92.0%", generatedDate: "2026-09-02", author: "Quality Team A", type: "Environmental Report", status: "Finalized" },
  ],

  // ANALYTICS Module — Operational Analytics Data & Time Series
  analytics: {
    monthlyTrends: [
      { month: "Oct 2025", outputMW: 61.8, uptimePct: 92.4, efficiencyPct: 87.8, incidents: 2, complianceScore: 76 },
      { month: "Nov 2025", outputMW: 63.2, uptimePct: 93.1, efficiencyPct: 88.6, incidents: 1, complianceScore: 78 },
      { month: "Dec 2025", outputMW: 64.7, uptimePct: 93.8, efficiencyPct: 89.4, incidents: 2, complianceScore: 79 },
      { month: "Jan 2026", outputMW: 66.1, uptimePct: 94.0, efficiencyPct: 89.9, incidents: 1, complianceScore: 80 },
      { month: "Feb 2026", outputMW: 67.5, uptimePct: 94.6, efficiencyPct: 90.2, incidents: 1, complianceScore: 81 },
      { month: "Mar 2026", outputMW: 69.0, uptimePct: 94.8, efficiencyPct: 90.8, incidents: 0, complianceScore: 83 },
      { month: "Apr 2026", outputMW: 68.4, uptimePct: 94.2, efficiencyPct: 90.5, incidents: 1, complianceScore: 82 },
      { month: "May 2026", outputMW: 72.1, uptimePct: 96.0, efficiencyPct: 92.1, incidents: 0, complianceScore: 85 },
      { month: "Jun 2026", outputMW: 74.8, uptimePct: 95.1, efficiencyPct: 91.8, incidents: 1, complianceScore: 84 },
      { month: "Jul 2026", outputMW: 78.2, uptimePct: 93.8, efficiencyPct: 93.5, incidents: 2, complianceScore: 80 },
      { month: "Aug 2026", outputMW: 75.3, uptimePct: 91.5, efficiencyPct: 94.7, incidents: 3, complianceScore: 78 },
      { month: "Sep 2026", outputMW: 75.3, uptimePct: 90.9, efficiencyPct: 94.1, incidents: 1, complianceScore: 78 },
    ],
    siteBreakdown: [
      { site: "Production Site A", outputCapacityPct: 95.5, uptime: 98.4, riskIndex: "Low", category: "Top Performer" },
      { site: "Production Site B", outputCapacityPct: 98.8, uptime: 99.1, riskIndex: "Low", category: "Top Performer" },
      { site: "Production Site C", outputCapacityPct: 0.0, uptime: 81.2, riskIndex: "Critical", category: "Maintenance Required" },
      { site: "Production Site D", outputCapacityPct: 88.5, uptime: 95.6, riskIndex: "Low", category: "Normal" },
      { site: "Production Site E", outputCapacityPct: 0.0, uptime: 62.3, riskIndex: "Critical", category: "Stopped / Off-Line" },
    ],
    siteKpiTrends: {
      s1: {
        externalCompliance: [88, 90, 92, 94, 95, 96], internalCompliance: [91, 92, 93, 94, 95, 96], financialExposure: [320000, 290000, 260000, 230000, 205000, 185000], co2PerUnit: [0.55, 0.52, 0.50, 0.47, 0.44, 0.42], uptime: [96.8, 97.2, 97.8, 98.0, 98.2, 98.4], efficiency: [91.2, 92.0, 92.8, 93.4, 93.8, 94.1] },
      s2: {
        externalCompliance: [90, 91, 93, 94, 96, 97], internalCompliance: [92, 93, 94, 95, 96, 97], financialExposure: [220000, 200000, 180000, 160000, 140000, 120000], co2PerUnit: [0.44, 0.42, 0.40, 0.38, 0.36, 0.35], uptime: [97.5, 98.0, 98.4, 98.7, 98.9, 99.1], efficiency: [93.0, 93.8, 94.5, 95.0, 95.5, 96.0] },
      s3: {
        externalCompliance: [78, 74, 70, 64, 58, 52], internalCompliance: [81, 76, 70, 65, 60, 56], financialExposure: [540000, 680000, 820000, 960000, 1110000, 1250000], co2PerUnit: [0.62, 0.68, 0.73, 0.78, 0.84, 0.88], uptime: [91.0, 88.5, 86.0, 84.2, 82.6, 81.2], efficiency: [77.0, 68.0, 55.0, 40.0, 18.0, 0.0] },
      s4: {
        externalCompliance: [84, 85, 86, 87, 88, 89], internalCompliance: [86, 87, 88, 88, 89, 90], financialExposure: [310000, 300000, 290000, 280000, 270000, 260000], co2PerUnit: [0.60, 0.58, 0.56, 0.54, 0.52, 0.51], uptime: [93.2, 94.0, 94.6, 95.0, 95.4, 95.6], efficiency: [84.0, 85.2, 86.0, 87.0, 88.0, 88.7] },
      s5: {
        externalCompliance: [72, 68, 61, 54, 47, 39], internalCompliance: [70, 65, 58, 52, 46, 40], financialExposure: [720000, 900000, 1100000, 1300000, 1510000, 1680000], co2PerUnit: [0.76, 0.84, 0.92, 1.02, 1.14, 1.24], uptime: [83.0, 78.0, 74.5, 70.2, 66.0, 62.3], efficiency: [48.0, 41.0, 33.0, 24.0, 12.0, 0.0] }
    },
    steeringPeriods: ["Apr", "May", "Jun", "Jul", "Aug", "Sep"],
    steeringKpis: {
      externalCompliance: { label: "Regulatory exposure", unit: "%", target: 80, direction: "higher", ceiling: 100, recommendation: "Open the regulatory action plan, assign owners to the lowest-scoring controls, and schedule evidence review before the next checkpoint." },
      internalCompliance: { label: "Internal control readiness", unit: "%", target: 80, direction: "higher", ceiling: 100, recommendation: "Run a focused internal control review, close overdue CAPA actions, and refresh evidence for the controls trending below the internal threshold." },
      financialExposure: { label: "Financial exposure", unit: "EUR", target: 500000, direction: "lower", ceiling: 1800000, recommendation: "Prioritise the highest exposure driver, quantify the mitigation cost, and assign a decision owner with a dated recovery milestone." },
      co2PerUnit: { label: "CO2 per unit", unit: "t/MWh", target: 0.6, direction: "lower", ceiling: 1.4, recommendation: "Start an energy and emissions recovery action: inspect the highest-consuming assets, validate meter data, and set a reduction milestone for the next period." },
      uptime: { label: "Operational uptime", unit: "%", target: 95, direction: "higher", ceiling: 100, recommendation: "Review the incident and maintenance backlog, protect critical spares, and set a recovery date for the next operational review." },
      efficiency: { label: "Operational efficiency", unit: "%", target: 90, direction: "higher", ceiling: 100, recommendation: "Investigate the production constraint, link the corrective action to the affected asset, and confirm the recovery run with the site lead." },
      sevesoIII: { label: "Seveso III", unit: "%", target: 80, direction: "higher", ceiling: 100, recommendation: "Activate the Seveso recovery plan: restore missing major-accident evidence, complete the site safety review, and assign a responsible approver before year-end." },
      redIII: { label: "RED III traceability", unit: "%", target: 80, direction: "higher", ceiling: 100, recommendation: "Close the RED III traceability gaps with the supplier, validate the mass-balance evidence, and schedule a procurement control review." },
      waterPermits: { label: "Water permits", unit: "%", target: 80, direction: "higher", ceiling: 100, recommendation: "Confirm permit renewal actions, verify discharge evidence, and escalate any missing site documentation to the environmental owner." },
      bmsController: { label: "BMS Controller quality gate", unit: "%", target: 90, direction: "higher", ceiling: 100, recommendation: "Hold the affected batch at the quality gate, complete the endurance and functional evidence, and release only after the control owner signs off." }
    },
    steeringControlTrends: {
      s1: { sevesoIII: [88, 89, 90, 91, 92, 93], redIII: [82, 83, 84, 85, 86, 88], waterPermits: [86, 87, 88, 89, 90, 91], bmsController: [86, 88, 90, 92, 94, 96] },
      s2: { sevesoIII: [86, 87, 88, 89, 90, 91], redIII: [84, 85, 86, 88, 90, 92], waterPermits: [88, 89, 90, 91, 92, 93], bmsController: [88, 90, 92, 94, 95, 97] },
      s3: { sevesoIII: [76, 72, 68, 60, 50, 39], redIII: [72, 70, 67, 63, 59, 55], waterPermits: [79, 76, 72, 69, 65, 61], bmsController: [82, 76, 68, 60, 52, 44] },
      s4: { sevesoIII: [82, 83, 84, 85, 86, 87], redIII: [76, 77, 79, 81, 83, 85], waterPermits: [82, 83, 84, 85, 86, 88], bmsController: [84, 86, 87, 88, 89, 90] },
      s5: { sevesoIII: [68, 62, 56, 48, 40, 31], redIII: [65, 60, 55, 50, 45, 40], waterPermits: [70, 65, 59, 53, 47, 39], bmsController: [72, 65, 58, 50, 43, 35] }
    },
    steeringYearEnd: {
      externalCompliance: { s1: 97, s2: 98, s3: 45, s4: 91, s5: 25 }, internalCompliance: { s1: 97, s2: 98, s3: 42, s4: 92, s5: 22 }, financialExposure: { s1: 150000, s2: 90000, s3: 1500000, s4: 220000, s5: 1950000 }, co2PerUnit: { s1: 0.39, s2: 0.32, s3: 0.98, s4: 0.48, s5: 1.38 }, uptime: { s1: 98.8, s2: 99.4, s3: 76, s4: 96.2, s5: 54 }, efficiency: { s1: 95, s2: 97, s3: 0, s4: 90, s5: 0 }, sevesoIII: { s1: 95, s2: 93, s3: 25, s4: 90, s5: 15 }, redIII: { s1: 91, s2: 94, s3: 48, s4: 88, s5: 28 }, waterPermits: { s1: 94, s2: 95, s3: 50, s4: 91, s5: 20 }, bmsController: { s1: 98, s2: 99, s3: 35, s4: 92, s5: 18 }
    },
    complianceTrend: [
      { month: "Apr 2026", score: 82, target: 80 },
      { month: "May 2026", score: 85, target: 80 },
      { month: "Jun 2026", score: 84, target: 80 },
      { month: "Jul 2026", score: 80, target: 80 },
      { month: "Aug 2026", score: 78, target: 80 },
      { month: "Sep 2026", score: 78, target: 80 }
    ]
  },

  complianceMatrix: [
    { siteId: "s1", scores: { r1: 98, r2: 75, r4: 82, r5: 96, r9: 88, r12: 91 } },
    { siteId: "s2", scores: { r1: 97, r2: 79, r4: 85, r5: 95, r9: 92, r12: 89 } },
    { siteId: "s3", scores: { r1: 72, r2: 61, r4: 48, r5: 64, r9: 55, r12: 38 } },
    { siteId: "s4", scores: { r1: 94, r2: 70, r4: 76, r5: 88, r9: 69, r12: 77 } },
    { siteId: "s5", scores: { r1: 51, r2: 45, r4: 39, r5: 42, r9: 48, r12: 31 } }
  ],

  events: [
    { id: "ev1", timestamp: "2026-09-14T10:38:00", siteId: "s5", type: "Breach risk", title: "CO2 intensity above internal drift threshold", detail: "Energy management score fell to 40%; projected year-end status is Critical.", severity: "critical" },
    { id: "ev2", timestamp: "2026-09-14T10:22:00", siteId: "s3", type: "Drift warning", title: "Seveso III control evidence missing", detail: "Live evidence freshness is below the operating threshold for Site C.", severity: "warning" },
    { id: "ev3", timestamp: "2026-09-14T09:48:00", siteId: "s4", type: "Control check", title: "ISO 50001 evidence refreshed", detail: "Energy management control check passed and is within target.", severity: "info" },
    { id: "ev4", timestamp: "2026-09-14T09:30:00", siteId: "s1", type: "Forecast", title: "CBAM score trending below target", detail: "Current trajectory requires an owner review before the next reporting window.", severity: "warning" }
  ],

  capa: [
    { id: "ca1", action: "Restore major-accident prevention evidence", siteId: "s3", regulationId: "r12", owner: "Safety Team A", dueDate: "2026-09-20", priority: "Critical", status: "Open", effectiveness: "Not tested" },
    { id: "ca2", action: "Complete CBAM emissions data mapping", siteId: "s1", regulationId: "r2", owner: "Compliance Team A", dueDate: "2026-10-05", priority: "High", status: "In Progress", effectiveness: "Monitoring" },
    { id: "ca3", action: "Recover energy management controls", siteId: "s5", regulationId: "r5", owner: "Operations Team B", dueDate: "2026-09-18", priority: "Critical", status: "Overdue", effectiveness: "Failed" },
    { id: "ca4", action: "Validate RED III supplier traceability", siteId: "s4", regulationId: "r9", owner: "Procurement Team A", dueDate: "2026-09-25", priority: "Medium", status: "In Progress", effectiveness: "Pending" }
  ]
};

DASHBOARD_DATA.regulations.forEach(regulation => {
  regulation.auditType = regulation.auditType || "External audit";
});

// Generated Mira records keep demo source compact while exercising large-table behavior.
const generatedDocumentTypes = ["Inspection Record", "Calibration Certificate", "Delivery Note", "Supplier Declaration", "Control Evidence", "Maintenance Report", "Permit Record", "Audit Evidence"];
const generatedDocumentStatuses = ["Active", "Active", "Active", "Under Review", "At Risk", "Expiring Soon"];
const generatedDocumentModules = ["Nova", "Astra", "Mira"];
const generatedSites = ["Production Site A", "Production Site B", "Production Site C", "Production Site D", "Production Site E"];

DASHBOARD_DATA.documents.push(...Array.from({ length: 1200 }, (_, index) => {
  const sequence = index + 1;
  const site = generatedSites[index % generatedSites.length];
  const type = generatedDocumentTypes[index % generatedDocumentTypes.length];
  const status = generatedDocumentStatuses[index % generatedDocumentStatuses.length];
  const uploadDate = new Date(Date.UTC(2025, 9, 1 + (index % 349)));
  const uploadDateText = uploadDate.toISOString().slice(0, 10);
  return {
    id: `gd-${String(sequence).padStart(4, "0")}`,
    title: `${type} · ${site} · Record ${String(sequence).padStart(4, "0")}`,
    type,
    module: generatedDocumentModules[index % generatedDocumentModules.length],
    category: index % 2 === 0 ? "Operational Control" : "Compliance Evidence",
    size: `${(0.4 + (index % 46) / 10).toFixed(1)} MB`,
    uploadDate: uploadDateText,
    status,
    entities: [site, generatedDocumentModules[index % generatedDocumentModules.length], `Control ${String((index % 40) + 1).padStart(2, "0")}`]
  };
}));

const heavyIndustryGraphRefs = [
  { id: "std-reach", label: "REACH", type: "Regulation", module: "Astra", status: "Chemical registration", detail: "EU chemicals regulation for substances and mixtures" },
  { id: "std-clp", label: "CLP", type: "Regulation", module: "Astra", status: "Classification & labelling", detail: "Classification, labelling and packaging for hazardous substances" },
  { id: "std-ied", label: "IED 2.0", type: "Regulation", module: "Astra", status: "Industrial emissions", detail: "EU industrial emissions and BAT-based permit control" },
  { id: "std-adr", label: "ADR", type: "Regulation", module: "Nova", status: "Dangerous goods transport", detail: "Road transport controls for dangerous goods" },
  { id: "std-seveso", label: "Seveso III", type: "Regulation", module: "Astra", status: "Major-accident prevention", detail: "Hazardous substance threshold and safety management controls" },
  { id: "std-iso14001", label: "ISO 14001", type: "Standard", module: "Astra", status: "Environmental management", detail: "Environmental management system standard" },
  { id: "std-iso45001", label: "ISO 45001", type: "Standard", module: "Astra", status: "Occupational health & safety", detail: "Worker safety management system standard" },
  { id: "std-iso50001", label: "ISO 50001", type: "Standard", module: "Astra", status: "Energy management", detail: "Energy management system standard" },
  { id: "std-osha-dangerous", label: "EU-OSHA Dangerous Substances", type: "Guidance", module: "Astra", status: "Worker exposure control", detail: "Dangerous substances, exposure limits and prevention measures" },
  { id: "haz-flammable", label: "Flammable material inventory", type: "Hazard", module: "Astra", status: "Live threshold control", detail: "Fire and explosion risk reference" },
  { id: "haz-toxic", label: "Toxic exposure control", type: "Hazard", module: "Astra", status: "Exposure monitoring", detail: "Worker health and occupational exposure risk" },
  { id: "haz-corrosive", label: "Corrosive substance handling", type: "Hazard", module: "Astra", status: "Handling control", detail: "Storage, PPE and release prevention" },
  { id: "kpi-oel", label: "OEL exceedance rate", type: "KPI", module: "Analytics", status: "0.4% live rate", detail: "Occupational exposure limit exceedances" },
  { id: "kpi-spill", label: "Spill response time", type: "KPI", module: "Analytics", status: "18 min average", detail: "Time from incident signal to containment action" },
  { id: "kpi-permit", label: "Permit deviation count", type: "KPI", module: "Analytics", status: "7 open deviations", detail: "Open emissions, wastewater and waste permit deviations" }
];

DASHBOARD_DATA.knowledgeGraph.nodes.push(...heavyIndustryGraphRefs);

const generatedGraphDocs = DASHBOARD_DATA.documents.filter(doc => doc.id.startsWith("gd-")).slice(0, 1200);
const referenceTargets = heavyIndustryGraphRefs.map(ref => ref.id);
const siteNodeMap = {
  "Production Site A": "site-a",
  "Production Site B": "site-b",
  "Production Site C": "site-c",
  "Production Site D": "site-d",
  "Production Site E": "site-e"
};

DASHBOARD_DATA.knowledgeGraph.nodes.push(
  { id: "site-b", label: "Production Site B", type: "Site", module: "Astra", status: "Running", detail: "24.7 MW Output" },
  { id: "site-d", label: "Production Site D", type: "Site", module: "Astra", status: "Running", detail: "12.4 MW Output" },
  { id: "site-e", label: "Production Site E", type: "Site", module: "Astra", status: "Stopped", detail: "Recovery required" }
);

DASHBOARD_DATA.knowledgeGraph.nodes.push(...generatedGraphDocs.map((doc, index) => ({
  id: `kg-${doc.id}`,
  label: doc.title,
  type: "Document",
  module: "Mira",
  status: doc.status,
  detail: `${doc.type} · ${doc.category} · ${doc.size}`,
  generated: true,
  sampleRank: index
})));

DASHBOARD_DATA.knowledgeGraph.edges.push(...generatedGraphDocs.flatMap((doc, index) => {
  const site = doc.entities.find(entity => entity.startsWith("Production Site"));
  return [
    { source: `kg-${doc.id}`, target: referenceTargets[index % referenceTargets.length], label: "References" },
    { source: `kg-${doc.id}`, target: siteNodeMap[site] || "site-a", label: "Applies To" }
  ];
}));
