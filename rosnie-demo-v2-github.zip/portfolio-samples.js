(() => {
  function seed() {
    const app = window.DemoV2;
    const helpers = window.DemoV2Auditors;
    const modal = window.DemoV2AuditModalInternals;
    if (!app || !helpers || !modal || app.compliance.portfolioSamplesV1) return;
    const definitions = [
      ['CAT-QMS-9001', 'ASTRA-2026-001', 4, 1, 'Planned', 'agreed', 4200, 25],
      ['CAT-EN1090', 'ASTRA-2026-003', 9, 2, 'Planned', 'agreed', 3750, 40],
      ['CAT-QMS-14001', 'ASTRA-2026-001', 12, 3, 'On hold', 'agreed', 4050, 35],
      ['CAT-OHS-45001', 'ASTRA-2026-002', 21, 4, 'Planned', 'agreed', 2940, 60],
      ['CAT-ENERGY-50001', 'ASTRA-2026-004', 28, 5, 'Planned', 'agreed', 3540, 75],
      ['CAT-ISMS-27001', 'ASTRA-2026-001', 45, 6, 'Planned', 'proposed', 4800, 90],
      ['CAT-WELD-3834', 'ASTRA-2026-003', -3, 7, 'On hold', 'agreed', 2370, 14],
      ['CAT-CUSTOMER', 'ASTRA-2026-002', -14, 8, 'Approved', 'completed', 3400, -2],
      ['CAT-PERMIT', 'ASTRA-2026-001', -21, 3, 'Approved', 'completed', 2700, -7],
      ['CAT-FPC', 'ASTRA-2026-003', -7, 2, 'Declined', 'completed', 2500, 7],
      ['CAT-SUST-CERT', 'ASTRA-2026-004', 65, 5, 'Planned', 'proposed', 2360, 100],
      ['CAT-INTERNAL', 'ASTRA-2026-002', 18, 1, 'Planned', 'agreed', 2900, 50]
    ];
    const additions = [];
    definitions.forEach(([catalogId, orderId, offset, directoryNumber, status, contractStatus, fee, endOffset], index) => {
      const id = 'AUDIT-PORTFOLIO-DEMO-' + String(index + 1).padStart(2, '0');
      if (app.compliance.audits.some(audit => audit.id === id)) return;
      const order = app.operations.orders.find(item => item.id === orderId);
      const entry = modal.catalogue().find(item => item.id === catalogId);
      if (!order || !entry) return;
      const auditor = helpers.directory[directoryNumber - 1];
      const personal = index === 0 || index === 11;
      const name = personal ? app.settings.user : auditor.name;
      const createdAt = helpers.inDays(-45) + 'T09:00:00Z';
      const plannedDate = helpers.inDays(offset);
      const contract = {
        reference: 'DEMO-CTR-' + String(index + 1).padStart(3, '0'), customer: order.customer,
        start: helpers.inDays(-35), end: helpers.inDays(endOffset), status: contractStatus,
        fee: String(fee), signer: name, sample: true,
        updatedAt: createdAt, updatedBy: 'Demo sample data'
      };
      const audit = {
        id, catalogId, framework: entry.name, title: entry.name, version: entry.version, source: entry.source,
        type: catalogId === 'CAT-PERMIT' ? 'Regulatory compliance review' : 'Certification readiness review',
        site: order.site, plannedDate, status, auditor: name, sample: true, contract,
        assignedAuditor: { id: personal ? 'DEMO-CURRENT-AUDITOR' : auditor.id, name, firm: personal ? 'ROSNIE Demo Audit Practice' : auditor.firm, dayRate: auditor.dayRate, days: Math.max(1, Math.round(fee / auditor.dayRate)), cost: fee, assignedAt: createdAt, assignedBy: 'Demo sample data' },
        orderIds: [order.id], componentIds: order.componentIds.slice(), evidenceIds: [], controlIds: [],
        missingEvidence: [], pendingEvidence: [], evidenceSnapshot: [],
        createdAt, createdBy: 'Demo sample data', notes: 'Fictional audit engagement for demonstration. No real contract or certification decision.',
        requests: [], reviews: {}, history: [{ at: createdAt, by: 'Demo sample data', action: 'Illustrative engagement added', note: 'Fictional contract, assignment and fee.' }]
      };
      if (status === 'On hold') {
        const profile = window.DemoV2Library.checklist(entry);
        const clause = profile.clauses.find(item => item.evidence.some(evidence => evidence.kind === 'calibration-certificate')) || profile.clauses[0];
        const evidence = clause.evidence.find(item => item.kind === 'calibration-certificate') || clause.evidence[0];
        const note = 'Demo request: provide the current signed source record and its validity for this site.';
        audit.requests.push({ id: id + '-REQUEST', standard: profile.standard, ref: clause.ref, title: clause.title, kind: evidence.kind, note, due: helpers.inDays(7), status: 'open', createdAt: new Date().toISOString(), createdBy: name });
        audit.decision = { state: 'hold', note: 'Demo hold: awaiting source documentation from the customer.', by: name, at: new Date().toISOString(), exceptions: 0 };
      }
      if (status === 'Approved' || status === 'Declined') {
        audit.decision = { state: status === 'Approved' ? 'approved' : 'declined', by: name, at: helpers.inDays(offset + 1) + 'T15:00:00Z', exceptions: 0, sample: true, note: status === 'Approved' ? 'Fictional completed decision for portfolio demonstration only; not a real certification approval.' : 'Fictional declined decision: customer scope and source documentation require clarification.' };
        audit.history.push({ at: audit.decision.at, by: name, action: 'Sample decision recorded', note: audit.decision.note });
      }
      const sourceRecords = app.operations.evidence.filter(record => record.orderId === order.id && record.status !== 'superseded');
      audit.evidenceIds = sourceRecords.map(record => record.id);
      audit.evidenceSnapshot = sourceRecords.map(({ dataUrl, ...record }) => record);
      additions.push(audit);
    });
    const next = { ...app.compliance, audits: [...app.compliance.audits, ...additions], portfolioSamplesV1: true };
    try { localStorage.setItem('rosnie-demo-v2-compliance-v1', JSON.stringify(next)); }
    catch { return; }
    Object.assign(app.compliance, next);
    app.render();
  }
  document.addEventListener('DOMContentLoaded', seed);
})();