# ROSNIE | Operations & Compliance Demo

A standalone, browser-based product demo for operational quality (ASTRA) and compliance preparation (MIRA). This repository contains the complete Demo V2 source and can be served as a static website. It has no build step, backend, package installation, or database.

> **Demo only.** Records, evidence, device readings, camera scenes, roles, audit outcomes, and recommendations are illustrative browser-local sample data. This product is not an authenticated system, a connected-device platform, or a certification decision service.

## Product

- **ASTRA** presents operational work: customers, sites, orders, components, tasks, evidence, and release readiness.
- **MIRA** presents compliance preparation: standards and requirements, audit planning, clause-oriented evidence review, and customer/auditor workflows.
- **Live connections** demonstrates generated camera scenes and sensor readings. Every simulated source is labelled; no physical device or camera is contacted.
- **Guided evidence authoring** creates printable internal demo records. Submissions are not automatically approved.
- **Auditor tools** demonstrate evidence traceability, requests, review states, and a printable auditor package. They do not issue certifications.

Recommendations are local, rule-based demo guidance, not output from a connected AI model. Standards are represented only by limited clause references and demo checklists; use the licensed, current standard and qualified professionals for real assessments.

## Run Locally

No Node.js, npm, or third-party packages are required. From the extracted project directory, start Python's built-in static server:

```powershell
py -m http.server 8000
```

Open <http://localhost:8000>. Alternatively, use the VS Code Live Server extension. Serving the files over HTTP is recommended over opening `index.html` directly.

The app saves its sample workspace in this browser's local storage. Different browser profiles and hostnames (for example `localhost` and `127.0.0.1`) have separate data. **Reset demo data** clears the app's three V2 storage records for the current browser after confirmation; it does not affect the source files.

## GitHub Upload

1. Extract the ZIP on your computer. The `index.html` and `.github` folder should be at the repository root; do not upload only the ZIP if you want GitHub to display the source files.
2. Create a repository in the `naddan979` GitHub account. Choose public or private visibility deliberately. Add the extracted project contents to the repository root using GitHub Desktop, Git, or GitHub's file upload page.
3. Commit the files to the `main` branch. Include `.github/workflows/pages.yml` if you want automated Pages deployment.
4. In repository **Settings → Pages**, choose **GitHub Actions** as the build and deployment source. The workflow publishes the static app after a push to `main`; you can also run it from the Actions tab.
5. Open the Pages URL shown in the workflow run or repository Pages settings. Pages availability and visibility depend on the repository and GitHub plan settings.

The browser upload page may not preserve hidden paths in every workflow. If `.github/workflows/pages.yml` is missing after upload, add that file with its repository path, or use GitHub Desktop to publish the extracted folder. GitHub stores an uploaded ZIP as an archive; it does not unpack it into project files.

## Project Layout

```text
index.html                 App shell and script loading order
styles.css                 Responsive application styles
app.js                     Main state, navigation, and rendering
sample-data.js             Local sample data
physical-ai.js             Simulated device feed and controls
live-visuals.js            Generated camera scenes and sensor charts
audit-modal.js              Audit catalogue and clause evidence flow
customer-layout.js         Customer compliance views
...                        Supporting audit, evidence, and reference modules
rosnie-horizontal.png      Product mark
.github/workflows/         GitHub Pages deployment
scripts/                   Package validation
```

The browser app is intentionally organized as small vanilla JavaScript modules loaded from `index.html`. State and files are stored client-side; there is no server API or shared persistence.

## Validation

Run the dependency-free local-asset check from the project root in PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/validate-package.ps1
```

For browser regression checks, serve the app and use the browser developer console:

```js
await import('./layout-checks.js');
runDemoV2LayoutChecks();
```

```js
await import('./evidence-editor-checks.js');
runDemoV2EvidenceChecks();
```

The evidence checks temporarily exercise browser storage and restore its previous values. Run them in an isolated demo browser profile without concurrent edits. Layout checks cover the currently visible screen; review the key workflows at mobile, tablet, and desktop widths as well.

## Data, Privacy, and Limitations

- There is no sign-in, authorization boundary, backend, encryption service, or production audit trail. Role switching is a demo interaction, not access control.
- Do not enter confidential, personal, customer, supplier, production, or other sensitive information. Do not upload real evidence.
- Uploaded demo files and generated records are stored in browser local storage on the device. They are not sent to a ROSNIE service, but browser storage is not a secure records-management system.
- Device values, camera imagery, limits, and detection labels are generated locally and are illustrative. No live AI inference or physical integration occurs.
- Coverage and readiness indicators are demo calculations, not proof of conformity or certification. All certification and audit decisions require authorized human review.
- A production implementation would require a security architecture, identity and access management, server-side storage, privacy and retention controls, validated integrations, and qualified domain review.

See [SECURITY.md](SECURITY.md) for reporting and handling guidance, and [CONTRIBUTING.md](CONTRIBUTING.md) for development conventions.
