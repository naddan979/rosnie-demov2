(() => {
  const mappings = {
    'CAT-QMS-9001': ['REQ-QMS-01', 'REQ-1090-01'],
    'CAT-WELD-3834': ['REQ-3834-01', 'REQ-3834-02', 'REQ-3834-03'],
    'CAT-EN1090': ['REQ-3834-01', 'REQ-3834-03', 'REQ-1090-01'],
    'CAT-CUSTOMER': ['REQ-3834-01', 'REQ-3834-02', 'REQ-3834-03', 'REQ-1090-01'],
    'CAT-INTERNAL': ['REQ-QMS-01'],
    'CAT-FPC': ['REQ-3834-01', 'REQ-3834-02', 'REQ-3834-03', 'REQ-1090-01'],
    'CAT-PIPE-PACK': ['REQ-3834-01', 'REQ-3834-02', 'REQ-3834-03', 'REQ-1090-01'],
    'CAT-WELD-PACK': ['REQ-3834-01', 'REQ-3834-02', 'REQ-3834-03'],
    'CAT-PERMIT': ['REQ-REG-01']
  };
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const app = () => window.DemoV2;
  let language = 'en';
  const text = (english, german) => language === 'de' ? german : english;
  let selectedId = '';
  let query = '';
  let type = '';
  let opener;
  let draft;
  let success = null;
  let step = 0;
  let scopeConfirmed = false;
  let evidenceReviewed = false;
  let acceptedRecommendations = new Set();
  let gapOpen = '';
  const tx = pair => text(pair[0], pair[1]);
  const lib = () => window.DemoV2Library;
  const deviceOf = id => window.DemoV2PhysicalAI?.devices.find(item => item.id === id);
  const sourceName = id => deviceOf(id) ? `${id} · ${tx(deviceOf(id).name)}` : tx(lib().sources[id].name);
  const sourceNote = id => {
    if (deviceOf(id)) return text('live connection (simulated)', 'Live-Verbindung (simuliert)');
    if (id === 'astra') return text('create or upload', 'erstellen oder hochladen');
    return app().settings.integrations.find(item => item.name === lib().sources[id].integration)?.enabled ? text('demo connector', 'Demo-Konnektor') : text('connector off', 'Konnektor aus');
  };
  const sourceChip = id => `<span class="source-chip ${deviceOf(id) ? 'live' : ''}">${escapeHtml(sourceName(id))} · ${escapeHtml(sourceNote(id))}</span>`;
  const clauseLabel = (standard, ref) => `${standard} ${/^(\d|A\.)/.test(ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')}${ref}`;
  function checklistFor(entry, state) {
    const profile = lib().checklist(entry);
    const scope = Array.isArray(state.orders) ? state.orders : [];
    const scopeIds = new Set(scope.map(order => order.id));
    const sites = [...new Set(scope.map(order => order.site))];
    const today = new Date().toISOString().slice(0, 10);
    const valid = kind => app().operations.evidence.filter(record => record.kind === kind && !['deleted', 'superseded', 'withdrawn'].includes(String(record.status).toLowerCase()) && !(record.expiryDate && record.expiryDate < today) && record.result !== 'Fail');
    const clauses = profile.clauses.map(clause => ({ ...clause, evidence: clause.evidence.map(item => {
      const records = valid(item.kind).filter(record => {
        if (!scopeIds.has(record.orderId) && !record.applicableOrderIds?.some(id => scopeIds.has(id))) return false;
        if (record.origin !== 'sensor-captured') return true;
        return lib().sourceApplicable(deviceOf(record.deviceId), profile.standard, clause.ref, sites);
      });
      const orders = scope.filter(order => order.tasks.some(task => task.kind === item.kind));
      const pairs = (orders.length ? orders.flatMap(order => order.componentIds.map(componentId => ({ orderId: order.id, componentId }))) : [{ orderId: scope[0]?.id || '', componentId: scope[0]?.componentIds[0] || '', org: true }]).map(pair => {
        const mine = pair.org ? records : records.filter(record => record.orderId === pair.orderId && record.componentId === pair.componentId);
        const verifiedRecord = mine.find(record => record.status === 'approved');
        const pendingRecord = !verifiedRecord && mine.find(record => record.status === 'submitted');
        return { ...pair, verified: !!verifiedRecord, pending: !!pendingRecord, record: verifiedRecord || pendingRecord };
      });
      const status = !scope.length ? 'missing' : pairs.every(pair => pair.verified) ? 'verified' : pairs.some(pair => !pair.verified && !pair.pending) ? 'missing' : 'pending';
      const sources = (lib().kinds[item.kind]?.sources || []).filter(id => !deviceOf(id) || lib().sourceApplicable(deviceOf(id), profile.standard, clause.ref, sites));
      return { ...item, pairs, status, sources, standard: profile.standard, clauseRef: clause.ref, sites };
    }) }));
    return { standard: profile.standard, note: profile.note, scope, clauses };
  }
  const viaLabel = record => record.origin === 'sensor-captured' ? `${record.deviceId} (${text('live connection', 'Live-Verbindung')})` : record.origin === 'astra-authored' ? text('ASTRA guided document', 'ASTRA-geführtes Dokument') : text('uploaded file', 'hochgeladene Datei');
  function itemHtml(item) {
    const done = item.pairs.filter(pair => pair.verified).length;
    const tone = item.status === 'verified' ? 'green' : item.status === 'pending' ? 'amber' : 'red';
    const label = item.status === 'verified' ? text('Verified', 'Verifiziert') : item.status === 'pending' ? text('Awaiting review', 'In Prüfung') : text('Missing', 'Fehlt');
    const via = [...new Set(item.pairs.filter(pair => pair.record).map(pair => viaLabel(pair.record)))].join(', ');
    const source = lib().kinds[item.kind];
    return `<li class="audit-clause-item"><span class="audit-clause-letter">${item.id}</span><div><strong>${escapeHtml(tx(source.label))}</strong><small>${item.pairs.length > 1 || !item.pairs[0]?.org ? item.pairs.map(pair => escapeHtml(pair.orderId + ' · ' + pair.componentId)).join(' | ') : text('Scoped shared record', 'Gemeinsamer Nachweis im Auditumfang')}${via ? ' · ' + text('via', 'über') + ' ' + escapeHtml(via) : ''}</small><div class="source-chips"><span class="source-label">${text('Can come from', 'Kann kommen aus')}:</span>${item.sources.map(sourceChip).join('')}<span class="source-chip">${text('Manual upload', 'Manueller Upload')}</span></div></div><span class="tag ${tone}">${label}${item.pairs.length > 1 ? ' ' + done + '/' + item.pairs.length : ''}</span></li>`;
  }
  function checklistView(entry, state, prefill) {
    const data = checklistFor(entry, state);
    const items = data.clauses.flatMap(clause => clause.evidence);
    const count = status => items.filter(item => item.status === status).length;
    return `${prefill}<h4>${text('Evidence checklist by clause', 'Nachweis-Checkliste nach Klausel')}</h4><p class="audit-prefill-note">${escapeHtml(tx(data.note))}</p><div class="audit-guide-totals"><span>${data.clauses.length} ${text('clauses', 'Klauseln')}</span><span>${count('verified')} ${text('evidence items verified', 'Nachweise verifiziert')}</span><span>${count('pending')} ${text('awaiting review', 'in Prüfung')}</span><span>${count('missing')} ${text('missing', 'fehlend')}</span></div>${data.clauses.map(clause => `<article class="audit-clause"><header><strong>${escapeHtml(clauseLabel(data.standard, clause.ref))}</strong><span>${escapeHtml(tx(clause.title))}</span></header><ol class="audit-clause-items">${clause.evidence.map(itemHtml).join('')}</ol></article>`).join('')}`;
  }
  function gapList(data) {
    const gaps = new Map();
    for (const clause of data.clauses) for (const item of clause.evidence) for (const pair of item.pairs) {
      if (pair.verified || pair.pending || !pair.orderId) continue;
      const key = JSON.stringify([item.kind, pair.orderId, pair.componentId]);
      const gap = gaps.get(key) || { key, kind: item.kind, orderId: pair.orderId, componentId: pair.componentId, org: !!pair.org, clauses: [] };
      gap.clauses.push({ standard: data.standard, ref: clause.ref, title: clause.title });
      gaps.set(key, gap);
    }
    return [...gaps.values()];
  }
  function gapsView(entry, state) {
    const data = checklistFor(entry, state);
    const gaps = gapList(data);
    const options = data.scope.flatMap(order => order.componentIds.map(componentId => `<option value="${escapeHtml(JSON.stringify([order.id, componentId]))}">${escapeHtml(order.id + ' · ' + componentId + ' · ' + order.site)}</option>`)).join('');
    return `<h4>${text('Missing evidence — add it now', 'Fehlende Nachweise — jetzt hinzufügen')}</h4><p class="audit-prefill-note">${text('Upload a file prepared elsewhere, or create the document here: ROSNIE guides you through every required element of the clause and blocks submission until the required content is complete. Formal compliance is confirmed only after authorized verification in MIRA.', 'Laden Sie eine extern erstellte Datei hoch oder erstellen Sie das Dokument hier: ROSNIE führt Sie durch alle Pflichtinhalte der Klausel und sperrt das Einreichen, bis diese vollständig sind. Formale Konformität bestätigt erst die autorisierte Verifizierung in MIRA.')}</p><div class="audit-gaps">${gaps.map(gap => `<div class="audit-gap" data-gap="${escapeHtml(gap.key)}"><div class="audit-gap-main"><strong>${escapeHtml(tx(lib().kinds[gap.kind].label))}</strong><small>${gap.org ? text('Organization-wide record; link it to', 'Organisationsweiter Nachweis; verknüpfen mit') : escapeHtml(gap.orderId + ' · ' + gap.componentId)}</small><div class="source-chips">${gap.clauses.map(clause => `<span class="source-chip clause">${escapeHtml(clauseLabel(clause.standard, clause.ref))}</span>`).join('')}</div></div><button type="button" class="button secondary" data-gap-add="${escapeHtml(gap.key)}" aria-expanded="${gapOpen === gap.key}">${text('Add evidence', 'Nachweis hinzufügen')}</button>${gapOpen === gap.key ? `<div class="audit-gap-choose">${gap.org ? `<label class="field">${text('Link to order / component', 'Mit Auftrag / Bauteil verknüpfen')}<select data-gap-target>${options}</select></label>` : ''}<button type="button" class="button secondary" data-gap-upload="${escapeHtml(gap.key)}">${text('Upload file', 'Datei hochladen')}</button><button type="button" class="button primary" data-gap-create="${escapeHtml(gap.key)}">${text('Create document with ROSNIE', 'Dokument mit ROSNIE erstellen')}</button></div>` : ''}</div>`).join('') || `<p class="physical-ai-empty">${text('No missing checklist evidence.', 'Keine fehlenden Checklisten-Nachweise.')}</p>`}</div><h4>${text('Recommendations', 'Empfehlungen')}</h4>`;
  }
  function bindGapActions(entry, state) {
    const gaps = gapList(checklistFor(entry, state));
    const target = button => {
      const gap = gaps.find(item => item.key === button.dataset.gapAdd || item.key === button.dataset.gapUpload || item.key === button.dataset.gapCreate);
      const select = button.closest('[data-gap]').querySelector('[data-gap-target]');
      const [orderId, componentId] = select ? JSON.parse(select.value) : [gap.orderId, gap.componentId];
      return { gap, orderId, componentId, title: tx(lib().kinds[gap.kind].label), clauses: gap.clauses };
    };
    body.querySelectorAll('[data-gap-add]').forEach(button => button.addEventListener('click', () => {
      gapOpen = gapOpen === button.dataset.gapAdd ? '' : button.dataset.gapAdd;
      const top = body.scrollTop;
      render();
      body.scrollTop = top;
      body.querySelector(`[data-gap-add="${CSS.escape(button.dataset.gapAdd)}"]`)?.focus();
    }));
    body.querySelectorAll('[data-gap-upload]').forEach(button => button.addEventListener('click', () => {
      const info = target(button);
      const input = document.querySelector('#evidence-file-input');
      Object.assign(input.dataset, { taskId: '', orderId: info.orderId, componentId: info.componentId, kind: info.gap.kind, title: info.title, clauses: JSON.stringify(info.clauses) });
      input.click();
    }));
    body.querySelectorAll('[data-gap-create]').forEach(button => button.addEventListener('click', () => {
      const info = target(button);
      window.DemoV2Evidence.openFor({ orderId: info.orderId, componentId: info.componentId, kind: info.gap.kind, title: info.title, clauses: info.clauses }, button);
    }));
  }

  function guidance(entry) {
    const profiles = [
      [/Welding|Pipeline/, ['Confirm welding execution scope, materials and responsible personnel.', 'Check current WPS/WPQR, welder qualifications, material traceability and inspection records.', 'Resolve missing or invalid welding and inspection evidence before authorized review.'], ['Schweißumfang, Materialien und verantwortliche Personen bestätigen.', 'Aktuelle WPS/WPQR, Schweißerqualifikationen, Materialrückverfolgbarkeit und Prüfberichte prüfen.', 'Fehlende oder ungültige Schweiß- und Prüfnachweise vor der autorisierten Prüfung klären.']],
      [/Cybersecurity/, ['Confirm information systems, assets and access boundaries.', 'Collect access reviews, risk assessments, incident records and control-owner approval.', 'Arrange specialist review of security controls; fabrication records do not prove cybersecurity conformity.'], ['Informationssysteme, Anlagen und Zugriffsgrenzen bestätigen.', 'Zugriffsprüfungen, Risikobewertungen, Vorfallberichte und Kontrollfreigaben erfassen.', 'Sicherheitskontrollen fachlich prüfen lassen; Fertigungsnachweise belegen keine Cybersicherheitskonformität.']],
      [/Energy Management|Power Generation/, ['Confirm energy boundaries, sites and reporting period.', 'Collect energy baselines, metering/calibration records, objectives and performance reviews.', 'Ask the energy manager to confirm the baseline and applicable reporting obligations.'], ['Energiegrenzen, Standorte und Berichtszeitraum bestätigen.', 'Energiebaselines, Mess-/Kalibriernachweise, Ziele und Leistungsprüfungen erfassen.', 'Baseline und anwendbare Berichtspflichten durch das Energiemanagement bestätigen lassen.']],
      [/Environmental/, ['Confirm environmental aspects, permits and site applicability.', 'Collect permit conditions, monitoring results, inspection records and corrective actions.', 'Have an authorized reviewer check applicable permit limits and reporting duties.'], ['Umweltaspekte, Genehmigungen und Standortanwendbarkeit bestätigen.', 'Genehmigungsauflagen, Messergebnisse, Prüfberichte und Korrekturmaßnahmen erfassen.', 'Anwendbare Genehmigungsgrenzen und Berichtspflichten autorisiert prüfen lassen.']],
      [/Occupational/, ['Confirm workplaces, activities and contractor scope.', 'Collect risk assessments, training, incident records and safety inspections.', 'Ask the safety owner to review competence and outstanding safety actions.'], ['Arbeitsplätze, Tätigkeiten und Fremdfirmenumfang bestätigen.', 'Gefährdungsbeurteilungen, Schulungen, Vorfallberichte und Sicherheitsprüfungen erfassen.', 'Kompetenzen und offene Sicherheitsmaßnahmen durch die zuständige Person prüfen lassen.']],
      [/Sustainability/, ['Confirm supply-chain boundaries, material sources and site scope.', 'Collect supplier sustainability declarations, traceability and authorized scheme requirements.', 'Verify supplier claims and scheme applicability; a material certificate alone is insufficient.'], ['Lieferkettengrenzen, Materialquellen und Standortumfang bestätigen.', 'Lieferanten-Nachhaltigkeitserklärungen, Rückverfolgbarkeit und autorisierte Regelwerksanforderungen erfassen.', 'Lieferantenaussagen und Regelwerksanwendbarkeit prüfen; ein Materialzeugnis allein reicht nicht aus.']]
    ];
    const profile = profiles.find(([pattern]) => pattern.test(entry.topic || ''));
    return profile ? (language === 'de' ? profile[2] : profile[1]) : [
      text('Confirm the process, customer/order scope and applicable reference version.', 'Prozess, Kunden-/Auftragsumfang und anwendbare Referenzversion bestätigen.'),
      text('Review controlled records, measurement evidence, responsibilities and release decisions.', 'Gelenkte Aufzeichnungen, Messnachweise, Verantwortlichkeiten und Freigaben prüfen.'),
      text('Assign outstanding evidence to its source owner and obtain an authorized applicability review.', 'Offene Nachweise der zuständigen Quellperson zuweisen und Anwendbarkeit autorisiert prüfen lassen.')
    ];
  }
  function recommendations(entry, state) {
    const suggestions = state.missing.map(pair => ({
      id: JSON.stringify(['missing', pair.orderId, pair.componentId, pair.kind]),
      title: text('Obtain missing evidence', 'Fehlenden Nachweis beschaffen'),
      basis: `${pair.orderId} · ${pair.componentId} · ${pair.kind}`,
      action: text('Ask the ASTRA task owner to upload or create this record, then request authorized verification in MIRA.', 'Die zuständige ASTRA-Person soll diesen Datensatz hochladen oder erstellen und anschließend eine autorisierte MIRA-Prüfung anfordern.')
    }));
    for (const pair of state.pending) suggestions.push({ id: JSON.stringify(['review', pair.orderId, pair.componentId, pair.kind]), title: text('Review existing evidence', 'Vorhandenen Nachweis prüfen'), basis: `${pair.orderId} · ${pair.componentId} · ${pair.kind}`, action: text('The record is submitted, not verified. Assign a qualified reviewer; do not upload a duplicate just to raise coverage.', 'Der Datensatz ist eingereicht, aber nicht verifiziert. Eine qualifizierte Prüfung zuweisen; keine Dublette zur Erhöhung der Abdeckung hochladen.') });
    if (!state.controls.length) suggestions.push({ id: 'mapping:' + entry.id, title: text('Define an applicable control mapping', 'Anwendbare Kontrollzuordnung festlegen'), basis: `${entry.id} · ${entry.topic}`, action: text('No matching ASTRA mapping exists. Ask a domain expert to define the required controls and evidence before claiming readiness.', 'Keine passende ASTRA-Zuordnung vorhanden. Erforderliche Kontrollen und Nachweise fachlich festlegen lassen, bevor Bereitschaft behauptet wird.') });
    suggestions.push({ id: 'specialist:' + entry.id, title: text('Confirm standard-specific preparation', 'Normbezogene Vorbereitung bestätigen'), basis: `${entry.name} · ${entry.version} · ${entry.source}`, action: guidance(entry)[2] });
    return suggestions;
  }

  const dialog = document.createElement('dialog');
  dialog.id = 'audit-catalog-dialog';
  dialog.className = 'audit-modal';
  dialog.setAttribute('aria-labelledby', 'audit-modal-title');
  dialog.innerHTML = '<header class="audit-modal-header"><div><small>MIRA</small><h2 id="audit-modal-title"></h2></div><button type="button" class="audit-modal-close" data-close-audit></button></header><div class="audit-modal-body" id="audit-modal-body"></div>';
  document.body.append(dialog);
  const body = dialog.querySelector('#audit-modal-body');
  const closeButton = dialog.querySelector('[data-close-audit]');

  function catalogue() {
    const entries = new Map((window.DemoV2MiraReference?.catalog || window.DemoV2LegacyAuditCatalog || []).map(entry => [entry.id, entry]));
    for (const entry of app().compliance.catalog || []) if (!entries.has(entry.id)) entries.set(entry.id, entry);
    return [...entries.values()].map(entry => ({ ...entry, sourceReview: window.DemoV2ClauseGuidance?.sourceChecks[lib().checklist(entry).standard] || null }));
  }
  function coverage(entry) {
    const controls = (mappings[entry.id] || []).map(id => app().compliance.requirements.find(control => control.id === id)).filter(Boolean);
    const requirements = new Map();
    const scopedOrders = new Map();
    for (const control of controls) {
      for (const order of app().operations.orders) {
        if (!(control.appliesTo || []).includes(order.id) && !order.tasks.some(task => control.kinds.includes(task.kind))) continue;
        scopedOrders.set(order.id, order);
        for (const componentId of order.componentIds) {
          for (const kind of control.kinds) requirements.set(JSON.stringify([order.id, componentId, kind]), { orderId: order.id, componentId, kind });
        }
      }
    }
    const today = new Date().toISOString().slice(0, 10);
    const pairs = [...requirements.values()].map(pair => {
      const records = app().operations.evidence.filter(record => record.orderId === pair.orderId && record.componentId === pair.componentId && record.kind === pair.kind);
      const valid = records.filter(record => !['deleted', 'superseded', 'withdrawn'].includes(String(record.status).toLowerCase()) && !(record.expiryDate && record.expiryDate < today) && record.result !== 'Fail');
      const verified = valid.some(record => record.status === 'approved');
      const pending = !verified && valid.some(record => record.status === 'submitted');
      return { ...pair, verified, pending, evidenceIds: records.map(record => record.id) };
    });
    const verified = pairs.filter(pair => pair.verified).length;
    const result = {
      controls, orders: [...scopedOrders.values()], pairs, total: pairs.length, verified,
      pending: pairs.filter(pair => pair.pending), missing: pairs.filter(pair => !pair.verified && !pair.pending),
      evidenceIds: [...new Set(pairs.flatMap(pair => pair.evidenceIds))],
      componentIds: [...new Set([...scopedOrders.values()].flatMap(order => order.componentIds))],
      percent: 0
    };
    const scope = result.orders.length ? result.orders : app().operations.orders;
    const items = checklistFor(entry, { ...result, orders: scope }).clauses.flatMap(clause => clause.evidence);
    const fraction = items.reduce((sum, item) => sum + item.pairs.filter(pair => pair.verified).length / Math.max(item.pairs.length, 1), 0);
    result.scopeOrders = scope;
    result.itemTotal = items.length;
    result.itemVerified = items.filter(item => item.status === 'verified').length;
    result.percent = items.length ? Math.round(fraction / items.length * 100) : 0;
    return result;
  }
  const scoreTone = percent => percent < 50 ? 'red' : percent < 70 ? 'amber' : 'green';
  const scoreBar = percent => `<span class="score-bar ${scoreTone(percent)}" aria-hidden="true"><i style="width:${percent}%"></i></span>`;
  const mayPlan = () => ['Quality Manager', 'Compliance Manager', 'Auditor', 'Administrator'].includes(app().settings.role);

  function renderRows() {
    const entries = catalogue().filter(entry => (!type || entry.type === type) && [entry.name, entry.topic, entry.id, entry.issuer].join(' ').toLowerCase().includes(query.toLowerCase()));
    body.querySelector('[data-catalog-count]').textContent = `${entries.length} ${text('entries', 'Einträge')}`;
    body.querySelector('[data-catalog-results]').innerHTML = entries.map(entry => {
      const state = coverage(entry);
      return `<article class="audit-modal-entry tone-${scoreTone(state.percent)}" data-catalog-id="${escapeHtml(entry.id)}"><div><small>${escapeHtml(entry.type)} · ${escapeHtml(entry.version)}</small><h3>${escapeHtml(entry.name)}</h3><p>${escapeHtml(entry.topic)}</p><small>${state.scopeOrders.length} ${text('orders', 'Aufträge')} · ${state.itemVerified}/${state.itemTotal} ${text('evidence items verified', 'Nachweise verifiziert')}</small></div><div class="audit-modal-score ${scoreTone(state.percent)}"><strong>${state.percent}%</strong>${scoreBar(state.percent)}<small>${text('Evidence coverage', 'Nachweisabdeckung')}</small></div><button type="button" class="button secondary" data-select-audit="${escapeHtml(entry.id)}">${text('Select audit', 'Audit auswählen')}</button></article>`;
    }).join('') || `<p class="empty-state">${text('No matching catalogue entries.', 'Keine passenden Katalogeinträge.')}</p>`;
    body.querySelectorAll('[data-catalog-id]').forEach(row => {
      const review = entries.find(entry => entry.id === row.dataset.catalogId)?.sourceReview;
      if (review) row.firstElementChild.insertAdjacentHTML('beforeend', `<small>${escapeHtml(review.edition)} · ${escapeHtml(text(...review.notice))}</small>`);
    });
    body.querySelectorAll('[data-select-audit]').forEach(button => button.addEventListener('click', () => { selectedId = button.dataset.selectAudit; step = 0; gapOpen = ''; scopeConfirmed = false; evidenceReviewed = false; acceptedRecommendations = new Set(); render(); body.scrollTop = 0; body.querySelector('[data-back-catalog]').focus(); }));
  }

  function renderCatalogue() {
    body.innerHTML = `<div class="section-head"><div><h3>${text('Standards, certifications and requirements', 'Normen, Zertifizierungen und Anforderungen')}</h3><p>${text('Review current ASTRA evidence coverage before selecting an audit.', 'Prüfen Sie die aktuelle ASTRA-Nachweisabdeckung vor der Auditauswahl.')}</p></div><span class="tag" data-catalog-count></span></div><p class="audit-prefill-note">${text('Coverage = verified evidence items in the clause checklist of each standard, across the orders in its scope. Red is below 50%, orange 50 to 69%, green 70% or more. This is operational evidence readiness, not formal certification compliance.', 'Abdeckung = verifizierte Nachweise in der Klausel-Checkliste jeder Norm, über die Aufträge in ihrem Umfang. Rot liegt unter 50 %, Orange bei 50 bis 69 %, Grün ab 70 %. Dies zeigt die Nachweisbereitschaft, nicht die formelle Normkonformität.')}</p><div class="audit-modal-filters"><input class="audit-search" id="audit-modal-search" type="search" value="${escapeHtml(query)}" placeholder="${text('Search catalogue', 'Katalog durchsuchen')}" aria-label="${text('Search catalogue', 'Katalog durchsuchen')}"><select class="audit-search" id="audit-modal-type" aria-label="${text('Catalogue type', 'Katalogtyp')}"><option value="">${text('All types', 'Alle Typen')}</option>${[...new Set(catalogue().map(entry => entry.type))].map(value => `<option value="${escapeHtml(value)}" ${type === value ? 'selected' : ''}>${escapeHtml(value)}</option>`).join('')}</select></div><div class="audit-modal-results" data-catalog-results></div>`;
    body.querySelector('#audit-modal-search').addEventListener('input', event => { query = event.target.value; renderRows(); });
    body.querySelector('#audit-modal-type').addEventListener('change', event => { type = event.target.value; renderRows(); });
    renderRows();
  }

  function renderPlan() {
    const entry = catalogue().find(item => item.id === selectedId);
    if (!entry) { selectedId = ''; renderCatalogue(); return; }
    const state = coverage(entry);
    const meta = [
      [text('Orders', 'Aufträge'), state.orders.map(order => order.id).join(', ')],
      [text('Customers', 'Kunden'), [...new Set(state.orders.map(order => order.customer))].join(', ')],
      [text('Sites', 'Standorte'), [...new Set(state.orders.map(order => order.site))].join(', ')],
      [text('Components', 'Bauteile'), state.componentIds.join(', ')],
      [text('Evidence records', 'Nachweise'), state.evidenceIds.length],
      [text('Missing / awaiting review', 'Fehlend / in Prüfung'), `${state.missing.length} / ${state.pending.length}`]
    ];
    body.innerHTML = `<button type="button" class="button text" data-back-catalog>${text('Back to catalogue', 'Zurück zum Katalog')}</button><div class="section-head"><div><h3>${escapeHtml(entry.name)}</h3><p>${escapeHtml(entry.type)} · ${escapeHtml(entry.version)} · ${escapeHtml(entry.jurisdiction || '')}</p></div><span class="tag ${scoreTone(state.percent)}">${state.percent}% ${text('evidence coverage', 'Nachweisabdeckung')}</span></div><p class="audit-prefill-note">${text('The scope below is prefilled from ASTRA. Confirm the auditor and date; evidence gaps remain visible and will be included in the plan.', 'Der Umfang ist aus ASTRA vorausgefüllt. Bestätigen Sie Auditor und Datum. Nachweislücken bleiben sichtbar und werden in den Plan übernommen.')}</p><div class="audit-launch-summary">${meta.map(([label, value]) => `<div><small>${escapeHtml(label)}</small><strong>${escapeHtml(value || '—')}</strong></div>`).join('')}</div><h3 class="subheading">${text('Mapped demo controls', 'Zugeordnete Demokontrollen')}</h3>${state.controls.map(control => `<p class="field-label">${escapeHtml(control.id)} · ${escapeHtml(control.title)}</p>`).join('') || `<p>${text('No applicable operational mapping yet. A scoping audit can be planned without asserting a compliance percentage.', 'Noch keine passende betriebliche Zuordnung. Ein Umfangsaudit kann ohne behaupteten Compliance-Prozentsatz geplant werden.')}</p>`}<h3 class="subheading">${text('Related operational evidence', 'Zugehörige Betriebsnachweise')}</h3><div class="evidence-list">${app().operations.evidence.filter(record => state.evidenceIds.includes(record.id)).map(record => `<div class="evidence-link-card"><strong>${escapeHtml(record.fileName)}</strong><small>${escapeHtml(record.orderId)} · ${escapeHtml(record.componentId)} · ${escapeHtml(record.status)}</small></div>`).join('') || '—'}</div><h3 class="subheading">${text('Missing evidence', 'Fehlende Nachweise')}</h3><ul class="gap-list">${state.missing.map(pair => `<li>${escapeHtml(pair.orderId)} · ${escapeHtml(pair.componentId)} · ${escapeHtml(pair.kind)}</li>`).join('')}</ul><form id="audit-modal-form" class="audit-launch-form"><div class="form-grid"><label class="field">${text('Lead auditor (optional, assign later)', 'Leitender Auditor (optional, später zuweisen)')}<input name="auditor" value="${escapeHtml(draft.auditor)}" maxlength="160"></label><label class="field">${text('Planned date', 'Geplantes Datum')}<input name="date" type="date" value="${escapeHtml(draft.date)}" required></label><label class="field">${text('Site', 'Standort')}<select name="site"><option value="all">${text('All sites in scope', 'Alle Standorte im Umfang')}</option>${[...new Set(state.orders.map(order => order.site))].map(site => `<option value="${escapeHtml(site)}" ${draft.site === site ? 'selected' : ''}>${escapeHtml(site)}</option>`).join('')}</select></label></div><label class="field">${text('Scope notes (optional)', 'Umfangsnotizen (optional)')}<textarea name="notes">${escapeHtml(draft.notes)}</textarea></label><p role="alert" id="audit-modal-error"></p><div class="form-actions"><button type="submit" class="button primary" ${mayPlan() ? '' : 'disabled'}>${text('Create audit plan', 'Auditplan erstellen')}</button></div>${mayPlan() ? '' : `<p>${text('Your role cannot create audit plans.', 'Ihre Rolle darf keine Auditpläne erstellen.')}</p>`}</form>`;
    body.querySelector('[data-back-catalog]').addEventListener('click', () => { selectedId = ''; render(); body.scrollTop = 0; body.querySelector('#audit-modal-search').focus(); });
    const form = body.querySelector('#audit-modal-form');
    form.addEventListener('input', () => { draft = { auditor: form.elements.auditor.value, date: form.elements.date.value, notes: form.elements.notes.value, site: form.elements.site.value }; });
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!mayPlan() || !scopeConfirmed || !evidenceReviewed) return;
      const latest = coverage(entry);
      const audit = {
        id: 'AUDIT-' + crypto.randomUUID(), catalogId: entry.id, framework: entry.name, title: entry.name,
        type: ['Regulation', 'Permit condition'].includes(entry.type) ? 'Regulatory compliance review' : 'Certification readiness review',
        version: entry.version, source: entry.source, status: 'Planned',
        auditor: form.elements.auditor.value.trim() || 'Unassigned', site: form.elements.site.value, plannedDate: form.elements.date.value, notes: form.elements.notes.value,
        compliancePercent: latest.percent, totalControls: latest.total, verifiedControls: latest.verified,
        orderIds: latest.orders.map(order => order.id), componentIds: latest.componentIds, evidenceIds: latest.evidenceIds,
        controlIds: latest.controls.map(control => control.id), missingEvidence: latest.missing, pendingEvidence: latest.pending,
        evidenceSnapshot: app().operations.evidence.filter(record => latest.evidenceIds.includes(record.id)).map(({ dataUrl, ...record }) => record),
        createdAt: new Date().toISOString(), createdBy: app().settings.user
      };
      audit.walkthrough = { scopeConfirmed, evidenceReviewed, completedAt: new Date().toISOString(), steps: ['scope', 'checklist', 'evidence-review', 'recommendations', 'plan'] };
      audit.checklist = checklistFor(entry, latest).clauses.map(clause => ({ ref: clause.ref, title: clause.title[0], evidence: clause.evidence.map(item => ({ id: item.id, kind: item.kind, status: item.status })) }));
      audit.recommendations = recommendations(entry, latest).filter(item => acceptedRecommendations.has(item.id)).map(item => ({ ...item, status: 'Proposed', source: 'Rule-based demo suggestion; not generated by a connected AI service', requiresHumanReview: true }));
      const audits = app().compliance.audits || [];
      const next = { ...app().compliance, audits: [audit, ...audits] };
      try { localStorage.setItem('rosnie-demo-v2-compliance-v1', JSON.stringify(next)); }
      catch { body.querySelector('#audit-modal-error').textContent = text('Could not save audit. Browser storage may be full.', 'Audit konnte nicht gespeichert werden. Möglicherweise ist der Browserspeicher voll.'); return; }
      app().compliance.audits = next.audits;
      app().render();
      success = audit;
      render();
      body.scrollTop = 0;
      body.querySelector('[data-finish-audit]').focus();
    });
  }
  function renderScope() {
    const entry = catalogue().find(item => item.id === selectedId);
    if (!entry) { selectedId = ''; renderCatalogue(); return; }
    const state = coverage(entry);
    const steps = [text('Audit scope', 'Auditumfang'), text('Checklist & ASTRA prefill', 'Checkliste & ASTRA-Vorausfüllung'), text('Evidence review', 'Nachweisprüfung'), text('Gaps & recommendations', 'Lücken & Empfehlungen'), text('Confirm plan', 'Plan bestätigen')];
    if (step === 4) {
      renderPlan();
      body.querySelector('#audit-modal-form').insertAdjacentHTML('afterbegin', `<p class="audit-prefill-note">${text('Scope and evidence review completed. Open gaps do not block planning an audit, but they remain unresolved until evidence is verified. Proposed follow-ups included:', 'Umfangs- und Nachweisprüfung abgeschlossen. Offene Lücken verhindern keine Auditplanung, bleiben aber bis zur Nachweisverifizierung ungelöst. Vorgeschlagene Folgemaßnahmen:')} ${recommendations(entry, state).filter(item => acceptedRecommendations.has(item.id)).length}</p>`);
    }
    else {
      let content = '';
      if (step === 0) content = `<p>${escapeHtml(entry.type)} · ${escapeHtml(entry.version)} · ${escapeHtml(entry.jurisdiction || '')}</p><p class="audit-prefill-note">${escapeHtml(entry.source)}. ${text('These are preparation prompts, not the full normative clauses of this standard. Applicability and formal conformity need authorized review.', 'Dies sind Vorbereitungshinweise, nicht die vollständigen normativen Anforderungen. Anwendbarkeit und formelle Konformität erfordern eine autorisierte Prüfung.')}</p><ol class="audit-guide-list">${guidance(entry).map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ol><label class="audit-guide-confirm"><input type="checkbox" data-confirm-scope ${scopeConfirmed ? 'checked' : ''}>${text('I have reviewed the selected reference/version and will confirm its applicability.', 'Ich habe Referenz und Version geprüft und werde die Anwendbarkeit bestätigen.')}</label>`;
      if (step === 1) {
        const cells = [[text('Customer', 'Kunde'), [...new Set(state.orders.map(order => order.customer))].join(', ')], [text('Sites', 'Standorte'), [...new Set(state.orders.map(order => order.site))].join(', ')], [text('Orders', 'Aufträge'), state.orders.map(order => order.id).join(', ')], [text('Components', 'Bauteile'), state.componentIds.join(', ')]];
        content = `<p class="audit-prefill-note">${text('Already filled from ASTRA: the following scope and linked records are read directly from current operational data. Nothing here needs retyping. Missing data is not inferred.', 'Bereits aus ASTRA ausgefüllt: Umfang und verknüpfte Aufzeichnungen stammen direkt aus aktuellen Betriebsdaten. Keine erneute Eingabe nötig. Fehlende Daten werden nicht erfunden.')}</p><div class="audit-launch-summary">${cells.map(([label, value]) => `<div><small>${escapeHtml(label)}</small><strong>${escapeHtml(value || text('Not available from ASTRA', 'Nicht aus ASTRA verfügbar'))}</strong></div>`).join('')}</div><h4>${text('Mapped demo requirements', 'Zugeordnete Demoanforderungen')}</h4>${state.controls.map(control => `<p>${escapeHtml(control.id)} · ${escapeHtml(control.title)}</p>`).join('') || `<p>${text('No operational mapping. This can only be a scoping audit until a specialist defines applicable controls.', 'Keine betriebliche Zuordnung. Bis zur fachlichen Kontrollfestlegung ist nur ein Umfangsaudit möglich.')}</p>`}`;
      }
      if (step === 1) content = checklistView(entry, state, content);
      if (step === 2) content = `<p class="audit-prefill-note">${text('Already verified, awaiting review, and missing evidence are distinguished below. Reading this step does not approve or alter any source record.', 'Verifizierte, noch zu prüfende und fehlende Nachweise sind unten getrennt. Dieser Schritt genehmigt und verändert keine Quelldatensätze.')}</p><div class="audit-guide-totals"><span>${state.verified} ${text('verified', 'verifiziert')}</span><span>${state.pending.length} ${text('awaiting review', 'in Prüfung')}</span><span>${state.missing.length} ${text('missing or invalid', 'fehlend oder ungültig')}</span></div><div class="evidence-list">${app().operations.evidence.filter(record => state.evidenceIds.includes(record.id)).map(record => `<div class="evidence-link-card"><strong>${escapeHtml(record.fileName)}</strong><small>ASTRA · ${escapeHtml(record.orderId)} · ${escapeHtml(record.componentId)} · ${escapeHtml(record.status)}</small></div>`).join('') || `<p>${text('No linked operational evidence yet.', 'Noch keine verknüpften Betriebsnachweise.')}</p>`}</div><ul class="gap-list">${state.missing.map(pair => `<li>${escapeHtml(pair.orderId)} · ${escapeHtml(pair.componentId)} · ${escapeHtml(pair.kind)}</li>`).join('')}</ul><label class="audit-guide-confirm"><input type="checkbox" data-confirm-evidence ${evidenceReviewed ? 'checked' : ''}>${text('I reviewed the imported evidence and understand which items are still open.', 'Ich habe die importierten Nachweise geprüft und kenne die offenen Punkte.')}</label>`;
      if (step === 3) content = `<p class="audit-prefill-note">${text('AI-style assistance · DEMO: these suggestions are generated by local rules, not a connected AI model. They use missing/pending ASTRA records and the catalogue topic. Accepting a suggestion adds a proposed follow-up to the audit plan; it does not fill evidence, change compliance, or approve records.', 'KI-ähnliche Unterstützung · DEMO: Vorschläge stammen aus lokalen Regeln, nicht aus einem verbundenen KI-Modell. Grundlage sind offene ASTRA-Nachweise und das Katalogthema. Übernahme fügt eine vorgeschlagene Folgemaßnahme zum Plan hinzu; Nachweise, Compliance und Freigaben bleiben unverändert.')}</p><div class="audit-recommendations">${recommendations(entry, state).map(item => `<article class="audit-recommendation"><h4>${escapeHtml(item.title)}</h4><small>${escapeHtml(item.basis)}</small><p>${escapeHtml(item.action)}</p><label class="audit-guide-confirm"><input type="checkbox" data-recommendation="${escapeHtml(item.id)}" ${acceptedRecommendations.has(item.id) ? 'checked' : ''}>${text('Include as proposed follow-up', 'Als vorgeschlagene Folgemaßnahme aufnehmen')}</label></article>`).join('')}</div>`;
      if (step === 3) content = gapsView(entry, state) + content;
      body.innerHTML = `<button type="button" class="button text" data-back-catalog>${text('Back to catalogue', 'Zurück zum Katalog')}</button><div class="section-head"><div><h3>${escapeHtml(entry.name)}</h3><p>${text('Guided audit preparation', 'Geführte Auditvorbereitung')}</p></div><span class="tag ${scoreTone(state.percent)}">${state.percent}% ${text('evidence coverage', 'Nachweisabdeckung')}</span></div><section class="audit-guide-content"><h3 tabindex="-1" data-guide-heading>${steps[step]}</h3>${content}</section>`;
      body.querySelector('[data-back-catalog]').addEventListener('click', () => { selectedId = ''; render(); body.scrollTop = 0; });
    }
    body.querySelector('[data-back-catalog]').insertAdjacentHTML('afterend', `<ol class="audit-stepper" aria-label="${text('Audit preparation steps', 'Schritte der Auditvorbereitung')}">${steps.map((label, index) => `<li ${index === step ? 'aria-current="step"' : ''} class="${index < step ? 'complete' : ''}"><span>${index + 1}</span>${escapeHtml(label)}</li>`).join('')}</ol>`);
    body.querySelector('[data-confirm-scope]')?.addEventListener('change', event => { scopeConfirmed = event.target.checked; body.querySelector('[data-guide-next]').disabled = !scopeConfirmed; });
    body.querySelector('[data-confirm-evidence]')?.addEventListener('change', event => { evidenceReviewed = event.target.checked; body.querySelector('[data-guide-next]').disabled = !evidenceReviewed; });
    bindGapActions(entry, state);
    body.querySelectorAll('[data-recommendation]').forEach(input => input.addEventListener('change', () => { input.checked ? acceptedRecommendations.add(input.dataset.recommendation) : acceptedRecommendations.delete(input.dataset.recommendation); }));
    body.insertAdjacentHTML('beforeend', `<div class="audit-guide-navigation"><span>${text('Step', 'Schritt')} ${step + 1} / 5</span><div><button type="button" class="button secondary" data-guide-back ${step === 0 ? 'disabled' : ''}>${text('Back', 'Zurück')}</button>${step < 4 ? `<button type="button" class="button primary" data-guide-next ${(step === 0 && !scopeConfirmed) || (step === 2 && !evidenceReviewed) ? 'disabled' : ''}>${text('Continue', 'Weiter')}</button>` : ''}</div></div>`);
    const move = next => { step = next; render(); body.scrollTop = 0; (body.querySelector('[data-guide-heading]') || body.querySelector('[data-back-catalog]')).focus(); };
    body.querySelector('[data-guide-back]').addEventListener('click', () => move(Math.max(0, step - 1)));
    body.querySelector('[data-guide-next]')?.addEventListener('click', () => move(Math.min(4, step + 1)));
  }
  function render() {
    dialog.querySelector('#audit-modal-title').textContent = text('Audit catalogue', 'Audit-Katalog');
    closeButton.textContent = '×';
    closeButton.setAttribute('aria-label', text('Close audit catalogue', 'Audit-Katalog schließen'));
    if (success) {
      body.innerHTML = `<div class="audit-modal-confirmation"><span class="tag green">${text('Planned', 'Geplant')}</span><h3>${text('Audit plan created', 'Auditplan erstellt')}</h3><p>${escapeHtml(success.framework)} · ${escapeHtml(success.auditor)} · ${escapeHtml(success.plannedDate)}</p><p>${text('Your audit plan and ASTRA evidence snapshot are now in the MIRA audit register.', 'Auditplan und ASTRA-Nachweisauszug stehen jetzt im MIRA-Auditregister.')}</p><button type="button" class="button primary" data-finish-audit>${text('Return to MIRA', 'Zurück zu MIRA')}</button></div>`;
      body.querySelector('[data-finish-audit]').addEventListener('click', () => dialog.close());
    } else if (selectedId) renderScope();
    else renderCatalogue();
  }
  closeButton.addEventListener('click', () => dialog.close());
  dialog.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      event.preventDefault();
      dialog.close();
    }
  });
  dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
  });
  dialog.addEventListener('close', () => {
    document.body.classList.remove('audit-modal-open');
    if (opener?.isConnected) opener.focus();
    else document.querySelector('[data-action="browse-audit-catalog"]')?.focus();
  });
  document.addEventListener('demov2:evidence-changed', () => {
    if (!dialog.open || !selectedId || success) return;
    const top = body.scrollTop;
    render();
    body.scrollTop = top;
  });
  window.DemoV2AuditModalInternals = { checklistFor, coverage, catalogue };
  window.DemoV2AuditModal = {
    open(trigger) {
      opener = trigger;
      language = app().settings.language === 'de' ? 'de' : 'en';
      selectedId = ''; query = ''; type = ''; success = null; step = 0; scopeConfirmed = false; evidenceReviewed = false; acceptedRecommendations = new Set();
      draft = { auditor: '', date: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10), notes: '' };
      render();
      document.body.classList.add('audit-modal-open');
      if (!dialog.open) dialog.showModal();
      body.scrollTop = 0;
      body.querySelector('#audit-modal-search').focus();
    }
  };
  if (new URL(location.href).searchParams.get('audit') === 'catalog') {
    window.DemoV2AuditModal.open(document.querySelector('[data-action="browse-audit-catalog"]'));
  }
})();