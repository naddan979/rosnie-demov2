(() => {
  const OPS_KEY = 'rosnie-demo-v2-operations-v1';
  const COMPLIANCE_KEY = 'rosnie-demo-v2-compliance-v1';
  const app = window.DemoV2;
  if (!app || app.operations.sampleDataV2) return;
  const { operations, compliance } = app;
  const ago = days => new Date(Date.now() - days * 86400000).toISOString();
  const reviewer = 'Anna Weber (sample)';
  const rows = [
    ['ASTRA-2026-003', 'material-certificate', 'Material certificate with heat traceability', 'approved', 38],
    ['ASTRA-2026-003', 'wpqr', 'Welding procedure qualification record', 'approved', 36],
    ['ASTRA-2026-002', 'inspection-report', 'Dimensional inspection report', 'approved', 22],
    ['ASTRA-2026-004', 'release-package', 'Release and conformity package', 'approved', 9],
    ['ASTRA-2026-001', 'welding-record', 'Welding record with parameters', 'submitted', 3],
    ['ASTRA-2026-001', 'controlled-document', 'Context analysis and scope statement', 'approved', 61],
    ['ASTRA-2026-003', 'competence-record', 'Welder and inspector competence matrix', 'approved', 54],
    ['ASTRA-2026-004', 'legal-register', 'Legal and permit obligations register', 'approved', 47],
    ['ASTRA-2026-002', 'internal-audit-report', 'Internal audit report', 'approved', 41],
    ['ASTRA-2026-001', 'management-review', 'Management review minutes', 'approved', 33],
    ['ASTRA-2026-004', 'traceability-record', 'Component traceability log', 'approved', 27],
    ['ASTRA-2026-002', 'operation-check', 'Monitoring and operating log', 'approved', 14],
    ['ASTRA-2026-003', 'corrective-action', 'Corrective action register', 'approved', 19],
    ['ASTRA-2026-004', 'energy-data', 'Energy baseline and metering data', 'approved', 29],
    ['ASTRA-2026-002', 'access-review', 'Quarterly access review', 'approved', 12]
  ];
  rows.forEach(([orderId, kind, title, status, days], index) => {
    const order = operations.orders.find(item => item.id === orderId);
    const id = 'EV-S-' + String(index + 1).padStart(2, '0');
    if (!order || operations.evidence.some(item => item.id === id)) return;
    const createdAt = ago(days);
    operations.evidence.push({ id, orderId, componentId: order.componentIds[0], kind, title: `${title} (sample)`, fileName: `${kind}-sample.pdf`, mimeType: 'application/pdf', size: 0, status, createdAt, createdBy: 'Sample data', sample: true, ...(status === 'approved' ? { verifiedAt: createdAt } : {}) });
    if (status === 'approved') compliance.verifiedBy.push({ id: 'VERIFY-' + id, evidenceId: id, user: reviewer, time: createdAt });
  });
  operations.sampleDataV2 = true;
  try {
    localStorage.setItem(OPS_KEY, JSON.stringify(operations));
    localStorage.setItem(COMPLIANCE_KEY, JSON.stringify(compliance));
  } catch { /* the sample records stay in memory for this session */ }
  app.render();
})();
