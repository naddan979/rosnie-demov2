(() => {
  const COMPLIANCE_KEY = 'rosnie-demo-v2-compliance-v1';
  const app = () => window.DemoV2;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const iso = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const inDays = days => { const date = new Date(); date.setDate(date.getDate() + days); return iso(date); };
  const busy = ranges => ranges.map(([from, to]) => [inDays(from), inDays(to)]);

  const directory = [
    { id: 'AUD-01', name: 'Dr. Katrin Vogel', firm: 'Nordwerk Pr\u00fcfgesellschaft', tags: ['iso9001', 'quality', 'customer'], languages: ['DE', 'EN'], experience: 18, dayRate: 1450, rating: 4.8, audits: 212, references: ['Demo Stahlwerke AG', 'Rheintal Maschinenbau (demo)'], busy: busy([[8, 15], [38, 43]]) },
    { id: 'AUD-02', name: 'Marcus Hellmann', firm: 'Weldcert Demo Partners', tags: ['welding', 'steel', 'customer'], languages: ['DE', 'EN'], experience: 22, dayRate: 1250, rating: 4.7, audits: 305, references: ['Fabrik Nord GmbH (demo)', 'Kranbau S\u00fcd (demo)'], busy: busy([[20, 27]]) },
    { id: 'AUD-03', name: 'Ingrid Lang', firm: 'Alpen Zertifizierung (demo)', tags: ['environment', 'permit', 'iso14001', 'energy'], languages: ['DE', 'EN', 'FR'], experience: 15, dayRate: 1350, rating: 4.6, audits: 148, references: ['Biomasse Kraftwerk Demo AG', 'Stadtwerke Beispiel'], busy: busy([[3, 9], [30, 34]]) },
    { id: 'AUD-04', name: 'Tomasz Kowalski', firm: 'EU Audit Collective (demo)', tags: ['safety', 'iso45001', 'quality'], languages: ['EN', 'PL', 'DE'], experience: 9, dayRate: 980, rating: 4.4, audits: 96, references: ['Fertigung Ost (demo)', 'Logistik Beispiel GmbH'], busy: busy([[12, 18]]) },
    { id: 'AUD-05', name: 'Sofia Marin', firm: 'Greenline Assurance (demo)', tags: ['sustainability', 'energy', 'iso50001', 'environment'], languages: ['EN', 'DE', 'RO'], experience: 12, dayRate: 1180, rating: 4.5, audits: 121, references: ['Energie Demo AG', 'Pellet Werke (demo)'], busy: busy([[5, 12], [45, 50]]) },
    { id: 'AUD-06', name: 'Jens Brandt', firm: 'CyberAudit Nord (demo)', tags: ['security', 'iso27001'], languages: ['DE', 'EN'], experience: 14, dayRate: 1600, rating: 4.9, audits: 134, references: ['Netzbetrieb Demo GmbH', 'Industrie IT Beispiel'], busy: busy([[0, 6], [21, 24]]) },
    { id: 'AUD-07', name: 'Anna-Lena Roth', firm: 'Qualitas Freelance (demo)', tags: ['quality', 'iso9001', 'welding', 'steel'], languages: ['DE', 'EN'], experience: 6, dayRate: 790, rating: 4.3, audits: 58, references: ['Blechwerk Demo', 'Metallbau Beispiel'], busy: busy([[10, 13]]) },
    { id: 'AUD-08', name: 'Pieter van Dijk', firm: 'Benelux Inspect (demo)', tags: ['steel', 'welding', 'environment', 'quality'], languages: ['EN', 'NL', 'DE'], experience: 25, dayRate: 1700, rating: 4.9, audits: 410, references: ['Staalbouw Demo BV', 'Havenkraan Beispiel'], busy: busy([[14, 40]]) }
  ];

  const tagMap = {
    'ISO 9001': ['iso9001', 'quality'], 'ISO 14001': ['iso14001', 'environment'], 'ISO 45001': ['iso45001', 'safety'], 'ISO 50001': ['iso50001', 'energy'], 'ISO 27001': ['iso27001', 'security'],
    'Welding demo set': ['welding'], 'Steel construction demo set': ['steel', 'welding'], 'Customer quality plan demo set': ['customer', 'quality'], 'Permit and monitoring demo set': ['environment', 'permit'],
    'Energy demo set': ['energy'], 'Cybersecurity demo set': ['security'], 'Occupational safety demo set': ['safety'], 'Sustainability demo set': ['sustainability'], 'Governance demo set': ['quality']
  };
  const entryOf = audit => (window.DemoV2AuditModalInternals?.catalogue() || []).find(item => item.id === audit.catalogId);
  const tagsFor = audit => { const entry = entryOf(audit); return entry ? tagMap[window.DemoV2Library.checklist(entry).standard] || ['quality'] : ['quality']; };
  const matchScore = (auditor, audit) => tagsFor(audit).filter(tag => auditor.tags.includes(tag)).length;
  const isBusy = (auditor, date) => auditor.busy.some(([from, to]) => date >= from && date <= to);
  function nextFree(auditor, fromDate) {
    const start = new Date(fromDate + 'T00:00:00');
    for (let step = 0; step < 240; step++) { const day = new Date(start); day.setDate(day.getDate() + step); if (!isBusy(auditor, iso(day))) return iso(day); }
    return null;
  }
  function estimate(auditor, audit) {
    const entry = entryOf(audit);
    const clauses = entry ? window.DemoV2Library.checklist(entry).clauses.length : 4;
    const days = Math.max(1, Math.ceil(clauses / 5));
    return { days, cost: days * auditor.dayRate };
  }
  const money = value => new Intl.NumberFormat(app().settings.language === 'de' ? 'de-DE' : 'en-GB', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(value);
  const audits = () => app().compliance.audits;
  function saveCompliance() {
    try { localStorage.setItem(COMPLIANCE_KEY, JSON.stringify(app().compliance)); return true; } catch { return false; }
  }
  function syncRequests(audit) {
    let changed = false;
    for (const request of audit.requests || []) {
      if (request.status !== 'open') continue;
      const record = app().operations.evidence.find(item => item.kind === request.kind && item.createdAt > request.createdAt && !['superseded', 'deleted', 'withdrawn'].includes(item.status) && item.result !== 'Fail' && (audit.orderIds || []).includes(item.orderId) && app().operations.orders.some(order => order.id === item.orderId && (!siteOf(audit) || order.site === siteOf(audit)) && (!audit.contract?.customer || order.customer === audit.contract.customer)));
      if (record) { request.status = 'provided'; request.evidenceId = record.id; request.providedAt = record.createdAt; changed = true; }
    }
    if (changed) saveCompliance();
    return changed;
  }
  const openRequests = audit => (audit.requests || []).filter(request => request.status === 'open');
  const siteOf = audit => audit.site && audit.site !== 'all' ? audit.site : '';
  const statusLabel = status => ({ Planned: text('Planned', 'Geplant'), 'On hold': text('On hold', 'Angehalten'), Approved: text('Approved', 'Freigegeben'), Declined: text('Declined', 'Abgelehnt') }[status] || status);
  const statusTone = status => status === 'Approved' ? 'green' : status === 'Declined' ? 'red' : 'amber';
  const sourceKind = record => !record ? 'missing' : record.origin === 'sensor-captured' ? 'live' : record.origin === 'astra-authored' ? 'astra' : 'upload';
  const sourceLabel = record => record.origin === 'sensor-captured' ? `${text('Live connection', 'Live-Verbindung')} ${record.deviceId}` : record.origin === 'astra-authored' ? text('ASTRA guided document', 'ASTRA-gef\u00fchrtes Dokument') : text('Uploaded or sample file', 'Hochgeladene Datei oder Beispieldatei');

  window.DemoV2Auditors = { directory, tagsFor, matchScore, isBusy, nextFree, estimate, money, audits, saveCompliance, syncRequests, openRequests, siteOf, statusLabel, statusTone, sourceKind, sourceLabel, entryOf, inDays, iso };
})();
