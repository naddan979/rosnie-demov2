(() => {
  const app = () => window.DemoV2;
  const auditors = () => window.DemoV2Auditors;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  let customerFilter = '';
  let auditorFilter = '';
  let workFilter = 'all';
  const dateLabel = value => value ? new Date(value + 'T00:00:00').toLocaleDateString(app().settings.language === 'de' ? 'de-DE' : 'en-GB') : text('Not recorded', 'Nicht erfasst');
  const daysUntil = value => value ? Math.round((new Date(value + 'T00:00:00') - new Date(new Date().toDateString())) / 86400000) : null;
  const mayEdit = () => ['Auditor', 'Administrator', 'Quality Manager', 'Compliance Manager'].includes(app().settings.role);
  function customersOf(audit) {
    if (audit.contract?.customer?.trim()) return [audit.contract.customer.trim()];
    return [...new Set(app().operations.orders.filter(order => (audit.orderIds || []).includes(order.id) && (!auditors().siteOf(audit) || order.site === auditors().siteOf(audit))).map(order => order.customer))];
  }
  function customerOf(audit) {
    const names = customersOf(audit);
    return names.join(', ') || text('Customer not recorded', 'Kunde nicht erfasst');
  }
  function terms(audit) {
    if (audit.contract) return audit.contract;
    if (!audit.sample) return {};
    return { reference: 'DEMO-ENG-' + audit.id.replace('AUDIT-SAMPLE-', ''), start: audit.createdAt?.slice(0, 10) || '', end: audit.plannedDate ? auditors().iso(new Date(new Date(audit.plannedDate + 'T00:00:00').getTime() + 30 * 86400000)) : '', status: 'proposed', fee: '', signer: '', sample: true };
  }
  const contractLabel = status => ({ proposed: text('Proposed', 'Angeboten'), agreed: text('Agreed', 'Vereinbart'), completed: text('Completed', 'Abgeschlossen'), cancelled: text('Cancelled', 'Storniert') }[status] || text('Not recorded', 'Nicht erfasst'));
  const isFinal = audit => ['Approved', 'Declined'].includes(audit.status);
  const upcoming = audit => !isFinal(audit) && daysUntil(audit.plannedDate) !== null && daysUntil(audit.plannedDate) <= 30;
  function rows() {
    return auditors().audits().filter(audit => (!customerFilter || customersOf(audit).includes(customerFilter)) && (!auditorFilter || (auditorFilter === 'unassigned' ? !audit.assignedAuditor : audit.assignedAuditor?.name === auditorFilter)) && (workFilter === 'all' || (workFilter === 'soon' && upcoming(audit)) || (workFilter === 'hold' && audit.status === 'On hold') || (workFilter === 'signoff' && !isFinal(audit)))).sort((first, second) => (first.plannedDate || '9999').localeCompare(second.plannedDate || '9999'));
  }
  function deadline(audit) {
    const days = daysUntil(audit.plannedDate);
    if (isFinal(audit)) return auditors().statusLabel(audit.status);
    if (days === null) return text('Audit date not set', 'Audittermin nicht festgelegt');
    if (days < 0) return text('Overdue by ', 'Überfällig seit ') + Math.abs(days) + text(' days', ' Tagen');
    return days === 0 ? text('Due today', 'Heute fällig') : text('Audit in ', 'Audit in ') + days + text(' days', ' Tagen');
  }
  function signature(audit) {
    return audit.decision ? `${auditors().statusLabel(audit.status)} · ${audit.decision.by} · ${dateLabel(audit.decision.at?.slice(0, 10))}` : text('Auditor decision pending', 'Auditorentscheidung ausstehend');
  }
  function rowHtml(audit) {
    const contract = terms(audit);
    const assigned = audit.assignedAuditor;
    const result = window.DemoV2AuditorView.evaluate(audit, auditors().siteOf(audit));
    const fee = contract.fee !== '' && contract.fee !== undefined ? auditors().money(Number(contract.fee)) : assigned?.cost !== undefined ? auditors().money(assigned.cost) + text(' estimated', ' geschätzt') : text('Fee not agreed', 'Honorar nicht vereinbart');
    const days = daysUntil(audit.plannedDate);
    return `<article class="portfolio-row"><div class="portfolio-client"><strong>${esc(customerOf(audit))}</strong><small>${esc(auditors().siteOf(audit) || text('Multiple sites', 'Mehrere Standorte'))}</small><span>${esc(audit.framework)}</span><small>${esc(assigned?.name || text('No auditor assigned', 'Kein Auditor zugewiesen'))}${assigned?.firm ? ' · ' + esc(assigned.firm) : ''}</small></div><div class="portfolio-contract"><strong>${esc(contract.reference || text('No contract reference', 'Keine Vertragsreferenz'))}</strong><span class="tag ${contract.status === 'agreed' ? 'green' : 'amber'}">${contractLabel(contract.status)}</span><small>${contract.sample ? text('Illustrative demo terms', 'Beispielhafte Demokonditionen') : text('Recorded engagement terms', 'Erfasste Auftragskonditionen')}</small><small>${dateLabel(contract.start)} → ${dateLabel(contract.end)}</small><strong>${esc(fee)}</strong></div><div class="portfolio-dates"><strong>${dateLabel(audit.plannedDate)}</strong><span class="tag ${days !== null && days < 0 && !isFinal(audit) ? 'red' : upcoming(audit) ? 'amber' : ''}">${esc(deadline(audit))}</span><small>${text('Contract ends', 'Vertragsende')}: ${dateLabel(contract.end)}</small>${contract.end && daysUntil(contract.end) <= 30 ? `<small class="portfolio-attention">${text('Contract ending soon or expired', 'Vertrag endet bald oder ist abgelaufen')}</small>` : ''}</div><div class="portfolio-signoff"><span class="tag ${auditors().statusTone(audit.status)}">${esc(auditors().statusLabel(audit.status))}</span><small>${esc(signature(audit))}</small><small>${text('Designated signatory', 'Vorgesehene zeichnende Person')}: ${esc(contract.signer || assigned?.name || text('Not recorded', 'Nicht erfasst'))}</small>${result ? `<small>${result.verifiedPct}% ${text('evidence verified', 'Nachweise verifiziert')} · ${result.reviewedPct}% ${text('auditor reviewed', 'vom Auditor geprüft')}</small>` : ''}<div class="portfolio-actions"><button type="button" class="button primary" data-portfolio-review="${esc(audit.id)}">${text('Review audit', 'Audit prüfen')}</button><button type="button" class="button secondary" data-portfolio-contract="${esc(audit.id)}">${text('Contract details', 'Vertragsdetails')}</button></div></div></article>`;
  }
  function html() {
    const all = auditors().audits();
    const selected = rows();
    const customers = [...new Set(all.flatMap(customersOf))];
    const assignedNames = [...new Set(all.map(audit => audit.assignedAuditor?.name).filter(Boolean))];
    const active = selected.filter(audit => terms(audit).status === 'agreed' && (!terms(audit).end || daysUntil(terms(audit).end) >= 0)).length;
    const summary = [[text('Customers', 'Kunden'), new Set(selected.flatMap(customersOf)).size], [text('Agreed engagements', 'Vereinbarte Aufträge'), active], [text('Audits due within 30 days', 'Audits in den nächsten 30 Tagen'), selected.filter(upcoming).length], [text('Pending sign-offs', 'Ausstehende Entscheidungen'), selected.filter(audit => !isFinal(audit)).length]];
    return `<section class="portfolio-overview"><div class="section-head"><div><h2>${text('Customers & audit engagements', 'Kunden & Auditaufträge')}</h2><p>${text('Upcoming audits, engagement terms and decisions to sign off.', 'Anstehende Audits, Auftragskonditionen und ausstehende Entscheidungen.')}</p></div></div><div class="portfolio-summary">${summary.map(([label, count]) => `<div><small>${label}</small><strong>${count}</strong></div>`).join('')}</div><div class="portfolio-filters"><label class="field">${text('Customer', 'Kunde')}<select data-portfolio-customer><option value="">${text('All customers', 'Alle Kunden')}</option>${customers.map(name => `<option value="${esc(name)}" ${name === customerFilter ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label><label class="field">${text('Auditor portfolio', 'Auditor-Portfolio')}<select data-portfolio-auditor><option value="">${text('All engagements', 'Alle Aufträge')}</option><option value="${esc(app().settings.user)}" ${auditorFilter === app().settings.user ? 'selected' : ''}>${text('My engagements', 'Meine Aufträge')} · ${esc(app().settings.user)}</option><option value="unassigned" ${auditorFilter === 'unassigned' ? 'selected' : ''}>${text('Unassigned', 'Nicht zugewiesen')}</option>${assignedNames.filter(name => name !== app().settings.user).map(name => `<option value="${esc(name)}" ${auditorFilter === name ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label><label class="field">${text('Work queue', 'Arbeitsliste')}<select data-portfolio-work>${[['all', text('All audits', 'Alle Audits')], ['soon', text('Due within 30 days', 'Fällig innerhalb von 30 Tagen')], ['hold', text('Waiting on customer', 'Wartet auf Kunden')], ['signoff', text('Pending decision', 'Ausstehende Entscheidung')]].map(([key, label]) => `<option value="${key}" ${workFilter === key ? 'selected' : ''}>${label}</option>`).join('')}</select></label></div><div class="portfolio-column-head" aria-hidden="true"><span>${text('Customer / scope', 'Kunde / Umfang')}</span><span>${text('Contract / fee', 'Vertrag / Honorar')}</span><span>${text('Audit / contract dates', 'Audit- / Vertragsdaten')}</span><span>${text('Decision / next action', 'Entscheidung / nächste Aktion')}</span></div><div class="portfolio-list">${selected.map(rowHtml).join('') || `<p class="physical-ai-empty">${text('No engagements match these filters. Assigned work appears under the named auditor.', 'Keine Aufträge entsprechen diesen Filtern. Zugewiesene Aufträge erscheinen unter dem benannten Auditor.')}</p>`}</div><p class="portfolio-disclaimer">${text('Demo engagement register. Recorded terms and auditor decisions are not legal contracts or electronic signatures. No assignment means the audit is not in an auditor\'s personal portfolio.', 'Demo-Auftragsregister. Erfasste Konditionen und Auditorentscheidungen sind keine rechtsgültigen Verträge oder elektronischen Signaturen. Ohne Zuweisung gehört ein Audit nicht zum persönlichen Portfolio eines Auditors.')}</p></section>`;
  }
  function context(audit) {
    const contract = terms(audit);
    return `<section class="portfolio-context"><div><small>${text('Auditing for', 'Audit für')}</small><strong>${esc(customerOf(audit))}</strong><span>${esc(auditors().siteOf(audit) || text('Multiple sites', 'Mehrere Standorte'))}</span></div><div><small>${text('Engagement', 'Auftrag')}</small><strong>${esc(contract.reference || text('Not recorded', 'Nicht erfasst'))}</strong><span>${contractLabel(contract.status)} · ${text('ends', 'endet')} ${dateLabel(contract.end)}</span></div><div><small>${text('Decision recorded by', 'Entscheidung erfasst von')}</small><strong>${esc(audit.assignedAuditor?.name || app().settings.user)}</strong><span>${esc(signature(audit))}</span></div><button type="button" class="button secondary" data-portfolio-contract="${esc(audit.id)}">${text('Contract details', 'Vertragsdetails')}</button></section>`;
  }
  const dialog = document.createElement('dialog');
  dialog.id = 'portfolio-contract-dialog';
  dialog.className = 'audit-modal evidence-editor';
  dialog.setAttribute('aria-labelledby', 'portfolio-contract-title');
  dialog.innerHTML = '<header class="audit-modal-header"><h2 id="portfolio-contract-title"></h2><button class="button secondary" type="button" data-portfolio-close></button></header><div class="audit-modal-body" data-portfolio-body></div>';
  document.body.append(dialog);
  function openContract(id) {
    const audit = auditors().audits().find(item => item.id === id);
    if (!audit) return;
    const contract = terms(audit);
    const field = (name, label, type = 'text') => `<label class="field">${label}<input name="${name}" type="${type}" value="${esc(contract[name] ?? '')}" ${type === 'number' ? 'min="0" step="0.01"' : 'maxlength="160"'}></label>`;
    dialog.querySelector('#portfolio-contract-title').textContent = text('Audit engagement details', 'Details zum Auditauftrag');
    dialog.querySelector('[data-portfolio-close]').textContent = text('Close', 'Schließen');
    dialog.querySelector('[data-portfolio-body]').innerHTML = `<p><strong>${esc(customerOf(audit))}</strong> · ${esc(audit.framework)} · ${esc(auditors().siteOf(audit))}</p><p class="audit-prefill-note">${text('Record the terms agreed outside this demo. Saving does not sign a contract, assign an auditor or approve an audit.', 'Erfassen Sie außerhalb dieser Demo vereinbarte Konditionen. Speichern unterschreibt keinen Vertrag, weist keinen Auditor zu und gibt kein Audit frei.')}</p><form data-portfolio-form><div class="form-grid">${field('reference', text('Contract / engagement reference', 'Vertrags- / Auftragsreferenz'))}${field('start', text('Contract start', 'Vertragsbeginn'), 'date')}${field('end', text('Contract end', 'Vertragsende'), 'date')}${field('fee', text('Agreed fee (EUR)', 'Vereinbartes Honorar (EUR)'), 'number')}${field('signer', text('Designated signatory', 'Vorgesehene zeichnende Person'))}<label class="field">${text('Contract status', 'Vertragsstatus')}<select name="status"><option value="">${text('Not recorded', 'Nicht erfasst')}</option>${['proposed', 'agreed', 'completed', 'cancelled'].map(status => `<option value="${status}" ${contract.status === status ? 'selected' : ''}>${contractLabel(status)}</option>`).join('')}</select></label></div><p role="alert" class="evidence-editor-error" data-portfolio-error></p><div class="form-actions"><button type="submit" class="button primary" ${mayEdit() ? '' : 'disabled'}>${text('Save details', 'Details speichern')}</button></div></form>`;
    dialog.querySelector('.form-grid').insertAdjacentHTML('afterbegin', `<label class="field">${text('Contracting customer', 'Auftraggebender Kunde')}<input name="customer" value="${esc(contract.customer || '')}" maxlength="160" list="portfolio-customer-options"><datalist id="portfolio-customer-options">${[...new Set(app().operations.orders.map(order => order.customer))].map(name => `<option value="${esc(name)}"></option>`).join('')}</datalist></label>`);
    dialog.querySelector('form').addEventListener('submit', event => {
      event.preventDefault();
      if (!mayEdit()) return;
      const data = Object.fromEntries(new FormData(event.currentTarget));
      const error = dialog.querySelector('[data-portfolio-error]');
      if (data.start && data.end && data.end < data.start) { error.textContent = text('Contract end must be on or after its start.', 'Vertragsende muss am oder nach dem Vertragsbeginn liegen.'); return; }
      const previous = audit.contract;
      audit.contract = { ...data, updatedBy: app().settings.user, updatedAt: new Date().toISOString() };
      if (!auditors().saveCompliance()) { audit.contract = previous; error.textContent = text('Could not save contract details.', 'Vertragsdetails konnten nicht gespeichert werden.'); return; }
      dialog.close();
      app().render();
    });
    document.body.classList.add('audit-modal-open');
    dialog.showModal();
    dialog.querySelector('input').focus();
  }
  dialog.querySelector('[data-portfolio-close]').addEventListener('click', () => dialog.close());
  dialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); dialog.close(); } });
  dialog.addEventListener('close', () => { if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open'); });
  document.addEventListener('click', event => {
    const review = event.target.closest('[data-portfolio-review]');
    if (review) { window.DemoV2AuditorView.select(review.dataset.portfolioReview); window.scrollTo(0, 0); }
    const contract = event.target.closest('[data-portfolio-contract]');
    if (contract) openContract(contract.dataset.portfolioContract);
  });
  document.addEventListener('change', event => {
    if (event.target.matches('[data-portfolio-customer]')) customerFilter = event.target.value;
    else if (event.target.matches('[data-portfolio-auditor]')) auditorFilter = event.target.value;
    else if (event.target.matches('[data-portfolio-work]')) workFilter = event.target.value;
    else return;
    app().render();
  });
  window.DemoV2AuditorPortfolio = { html, context, customerOf, terms, rows };
  document.addEventListener('DOMContentLoaded', () => { if (document.querySelector('#auditor-view')) app().render(); });
})();