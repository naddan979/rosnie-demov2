(() => {
  const app = () => window.DemoV2;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const kindLabel = kind => { const item = window.DemoV2Library?.kinds[kind]; return item ? text(item.label[0], item.label[1]) : kind.replaceAll('-', ' '); };
  const sourceName = id => { const device = window.DemoV2PhysicalAI?.devices.find(item => item.id === id); if (device) return id; const source = window.DemoV2Library?.sources[id]; return source ? text(source.name[0], source.name[1]) : id; };

  function openItems() {
    const items = [];
    for (const requirement of app().compliance.requirements) {
      const state = app().readiness(requirement);
      const certification = requirement.framework.split(' · ')[0];
      for (const order of state.orders) {
        for (const kind of requirement.kinds) {
          if (!order.tasks.some(task => task.kind === kind)) continue;
          const records = state.related.filter(record => record.orderId === order.id && record.kind === kind);
          if (records.some(record => record.status === 'approved')) continue;
          const awaiting = records.some(record => record.status === 'submitted' && !['Fail', 'Incomplete'].includes(record.result));
          const deviation = records.some(record => record.result === 'Fail');
          const collecting = records.some(record => record.result === 'Incomplete' && record.origin === 'sensor-captured');
          const status = awaiting ? 'awaiting' : deviation ? 'deviation' : collecting ? 'collecting' : 'missing';
          items.push({ certification, requirement, order, kind, status });
        }
      }
    }
    return items.sort((a, b) => a.certification.localeCompare(b.certification) || a.order.site.localeCompare(b.order.site) || a.order.id.localeCompare(b.order.id));
  }
  function nextStep(item) {
    if (item.status === 'awaiting') return text('Evidence is submitted: an authorized reviewer verifies it in the requirement below.', 'Nachweis ist eingereicht: Eine autorisierte Prüfperson verifiziert ihn in der Anforderung unten.');
    if (item.status === 'deviation') return text('A deviation blocks verification: resolve it in Live connections or replace the evidence.', 'Eine Abweichung blockiert die Verifizierung: in Live-Verbindungen klären oder Nachweis ersetzen.');
    if (item.status === 'collecting') return text('A live connection is still collecting readings.', 'Eine Live-Verbindung erfasst noch Messwerte.');
    const sources = (window.DemoV2Library?.kinds[item.kind]?.sources || ['astra']).map(sourceName).join(' / ');
    return `${text('Create or upload it in ASTRA. Possible sources', 'In ASTRA erstellen oder hochladen. Mögliche Quellen')}: ${sources}.`;
  }
  function html() {
    const items = openItems();
    const labels = { missing: text('Missing', 'Fehlt'), awaiting: text('Awaiting verification', 'Verifizierung ausstehend'), deviation: text('Deviation', 'Abweichung'), collecting: text('Collecting', 'Wird erfasst') };
    const tones = { missing: 'red', awaiting: 'amber', deviation: 'red', collecting: 'amber' };
    const head = `<div class="section-head"><div><h3>${text('Open items before auditor approval', 'Offene Punkte vor der Auditorfreigabe')}</h3><p>${text('Evidence still blocking each certification at each site. The auditor decides on approval; this list shows what is not yet verified.', 'Nachweise, die jede Zertifizierung an jedem Standort noch blockieren. Der Auditor entscheidet über die Freigabe; diese Liste zeigt, was noch nicht verifiziert ist.')}</p></div><span class="tag ${items.length ? 'red' : 'green'}">${items.length ? items.length + ' ' + text('open', 'offen') : text('Nothing missing', 'Nichts fehlt')}</span></div>`;
    if (!items.length) return `<section class="open-items" id="open-items">${head}<p class="physical-ai-empty">${text('All required evidence is verified. The auditor can review the package.', 'Alle erforderlichen Nachweise sind verifiziert. Der Auditor kann das Paket prüfen.')}</p></section>`;
    return `<section class="open-items" id="open-items">${head}<div class="open-item-list">${items.map(item => `<div class="open-item"><div class="open-item-main"><strong>${esc(kindLabel(item.kind))}</strong><small>${esc(item.requirement.title)}</small><div class="source-chips"><span class="source-chip clause">${text('Certification', 'Zertifizierung')}: ${esc(item.certification)}</span><span class="source-chip">${text('Site', 'Standort')}: ${esc(item.order.site)}</span><span class="source-chip">${esc(item.order.id)} · ${esc(item.order.componentIds[0])}</span></div><small>${esc(nextStep(item))}</small></div><div class="open-item-side"><span class="tag ${tones[item.status]}">${esc(labels[item.status])}</span><button class="button text" type="button" data-action="open-order" data-order-id="${esc(item.order.id)}">${text('Open order', 'Auftrag öffnen')}</button></div></div>`).join('')}</div></section>`;
  }
  function decorate() {
    window.DemoV2CustomerAudits?.decorate();
    const tabs = document.querySelector('.mira-tabs');
    if (tabs && !tabs.querySelector('[data-open-package]')) tabs.insertAdjacentHTML('beforeend', `<button class="button secondary mira-tab-action" type="button" data-open-package>${text('Auditor package', 'Auditorenpaket')}</button>`);
    const filter = document.querySelector('.requirements-panel .filter-chip.active');
    const list = document.querySelector('.requirements-panel .requirement-list');
    document.querySelector('#open-items')?.remove();
    if (!list || filter?.dataset.miraFilter !== 'all') return;
    list.insertAdjacentHTML('beforebegin', html());
  }

  window.DemoV2MiraExtras = { decorate, openItems };
  decorate();
})();
