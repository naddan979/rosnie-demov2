window.runDemoV2EvidenceChecks = function () {
  const app = window.DemoV2;
  const operationsSnapshot = JSON.stringify(app.operations);
  const complianceSnapshot = JSON.stringify(app.compliance);
  const language = app.settings.language;
  const role = app.settings.role;
  const keys = ['rosnie-demo-v2-operations-v1', 'rosnie-demo-v2-compliance-v1', 'rosnie-demo-v2-settings-v1'];
  const stored = keys.map(key => localStorage.getItem(key));
  const checks = [];
  const assert = (condition, name) => { if (!condition) throw new Error(name); checks.push(name); };
  const editor = () => document.querySelector('#evidence-editor-dialog');
  const body = () => document.querySelector('#evidence-editor-body');
  const click = selector => body().querySelector(selector).click();
  const submit = () => body().querySelector('form').requestSubmit();
  const fill = (name, value) => {
    const input = body().querySelector(`[name="${name}"]`);
    if (input.type === 'checkbox') input.checked = value;
    else input.value = value;
  };
  const nextContext = () => { fill('contextConfirmed', true); submit(); };
  const fillDetails = () => {
    for (const input of body().querySelectorAll('[required]')) {
      if (!input.value) input.value = 'DEMO TEST SOURCE';
    }
  };
  const checkFindings = () => {
    for (const input of body().querySelectorAll('[type="checkbox"]')) input.checked = true;
    fill('assessment', 'conforming');
  };
  const restoreObject = (target, snapshot) => {
    for (const key of Object.keys(target)) delete target[key];
    Object.assign(target, JSON.parse(snapshot));
  };
  try {
    app.settings.language = 'en';
    const order = app.operations.orders[0];
    const task = { id: 'GUIDED-EVIDENCE-TEST', title: 'Verify steel material certificate', kind: 'material-certificate', componentId: order.componentIds[0], done: false, requiresReview: true };
    order.tasks.push(task);
    window.DemoV2Evidence.open(order.id, task.id);
    assert(body().innerText.includes(order.customer) && body().innerText.includes(task.componentId), 'Operational context prefilled');
    submit();
    assert(body().querySelector('[name="contextConfirmed"]'), 'Context confirmation required');
    nextContext();
    assert(body().querySelector('[name="author"]').value === app.settings.user, 'Preparer prefilled');
    assert(body().querySelector('[name="reference"]').value === '', 'Source certificate reference never fabricated');
    submit();
    assert(body().querySelector('[name="reference"]'), 'Missing source facts block continuation');
    fillDetails();
    fill('reference', 'DEMO-REF-42');
    fill('results', 'Test source: 355 MPa; not real measurements. <script>unsafe()</script>');
    click('[data-save-draft]');
    assert(!editor().open && app.operations.evidenceDrafts[JSON.stringify([order.id, task.id])].reference === 'DEMO-REF-42', 'Draft persisted without creating evidence');
    window.DemoV2Evidence.open(order.id, task.id);
    assert(body().querySelector('[name="reference"]').value === 'DEMO-REF-42', 'Draft resumes with entered facts');
    submit();
    click('[data-use-suggestion]');
    assert(body().querySelector('[name="notes"]').value.includes('Review prompts (not findings)'), 'Suggestions identified as prompts, not facts');
    fill('assessment', 'conforming');
    submit();
    assert(body().querySelector('[data-editor-error]').textContent.length > 0, 'Conformity requires all checks');
    checkFindings();
    submit();
    assert(body().querySelector('.authored-document') && !body().querySelector('.authored-document script'), 'Preview escapes user content');
    const evidenceBefore = app.operations.evidence.length;
    submit();
    assert(app.operations.evidence.length === evidenceBefore, 'Final review acknowledgement required');
    fill('submissionConfirmed', true);
    const setItem = Storage.prototype.setItem;
    try {
      Storage.prototype.setItem = function (key, value) { if (key === keys[0]) throw new DOMException('Full', 'QuotaExceededError'); return setItem.call(this, key, value); };
      submit();
      assert(app.operations.evidence.length === evidenceBefore && body().querySelector('[data-editor-error]').textContent.includes('Could not save'), 'Storage failure leaves evidence unchanged and draft available');
    } finally { Storage.prototype.setItem = setItem; }
    submit();
    const record = app.operations.evidence[0];
    assert(record.origin === 'astra-authored' && record.status === 'submitted' && !task.done, 'Created record awaits review; task not auto-completed');
    assert(record.orderId === order.id && record.componentId === task.componentId && record.kind === task.kind, 'Evidence linked to correct task scope');
    assert(record.mimeType === 'text/html' && record.dataUrl.startsWith('data:text/html;base64,'), 'Downloadable document generated');
    assert(!app.operations.evidenceDrafts[JSON.stringify([order.id, task.id])], 'Submitted draft removed');
    assert(record.provenance.suggestions.includes('no connected AI'), 'Assistance provenance persisted');
    assert(JSON.parse(localStorage.getItem(keys[0])).evidence[0].id === record.id, 'Submitted document persisted');
    editor().close();
    app.settings.role = 'Quality Manager';
    document.querySelector('[data-route="mira"]').click();
    document.querySelector('[data-mira-view="requirements"]')?.click();
    const verifyButton = () => document.querySelector(`[data-action="verify-evidence"][data-evidence-id="${record.id}"]`);
    assert(verifyButton() && !verifyButton().disabled, 'Authored evidence available for authorized MIRA review');
    record.result = 'Incomplete';
    app.render();
    assert(verifyButton().disabled, 'Incomplete findings cannot be approved');
    verifyButton().disabled = false;
    verifyButton().click();
    assert(record.status === 'submitted' && !task.done, 'Approval handler also blocks incomplete findings');
    record.result = 'Fail';
    app.render();
    assert(verifyButton().disabled, 'Nonconforming findings cannot be approved');
    record.result = 'Pass';
    app.render();
    app.settings.role = 'Operator';
    verifyButton().click();
    assert(record.status === 'submitted', 'Operator cannot approve authored evidence');
    app.settings.role = 'Quality Manager';
    verifyButton().click();
    assert(record.status === 'approved' && task.done, 'Authorized MIRA verification completes associated ASTRA task');
    app.settings.role = role;
    for (const kind of ['wps', 'wpqr', 'ndt-report', 'inspection-report', 'release-package']) {
      task.kind = kind;
      window.DemoV2Evidence.open(order.id, task.id);
      nextContext();
      assert(body().querySelectorAll('[required]').length >= 5, kind + ' template has guided fields');
      editor().close();
    }
    task.kind = 'material-certificate';
    app.settings.language = 'de';
    window.DemoV2Evidence.open(order.id, task.id);
    assert(body().innerText.includes('Kontext') && document.querySelector('#evidence-editor-title').textContent.includes('Stahlmaterial'), 'German editor guidance available');
    return { passed: true, checks };
  } finally {
    if (editor().open) editor().close();
    restoreObject(app.operations, operationsSnapshot);
    restoreObject(app.compliance, complianceSnapshot);
    app.settings.language = language;
    app.settings.role = role;
    keys.forEach((key, index) => { if (stored[index] === null) localStorage.removeItem(key); else localStorage.setItem(key, stored[index]); });
    app.render();
  }
};