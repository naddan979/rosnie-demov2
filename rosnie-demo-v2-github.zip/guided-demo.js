(() => {
  const KEYS = ['rosnie-demo-v2-operations-v1', 'rosnie-demo-v2-compliance-v1', 'rosnie-demo-v2-settings-v1'];
  const reviewers = ['Quality Manager', 'Compliance Manager', 'Auditor', 'Administrator'];
  const app = () => window.DemoV2;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const q = selector => document.querySelector(selector);
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const banner = document.createElement('section');
  banner.className = 'tour-banner';
  banner.setAttribute('role', 'region');
  let active = false;
  let index = 0;
  let busy = false;
  let note = '';
  let savedRole = null;

  const closeDialogs = () => document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close());
  const confirmBox = selector => { const input = q(selector); if (input && !input.checked) { input.checked = true; input.dispatchEvent(new Event('change', { bubbles: true })); } };
  function ensureView(view) {
    closeDialogs();
    if (new URL(location.href).searchParams.get('workspace') !== 'mira') q('[data-route="mira"]').click();
    q('[data-mira-mode="customer"]:not(.active)')?.click();
    const tab = q(`[data-mira-view="${view}"]`);
    if (tab && tab.getAttribute('aria-selected') !== 'true') tab.click();
  }
  const scrollTo = selector => q(selector)?.scrollIntoView({ block: 'start', behavior: 'smooth' });
  const api = () => window.DemoV2PhysicalAI;
  const openAlert = () => api().state().alerts.find(item => item.deviceId === 'SNS-WELD-01' && item.status === 'open');
  const auditStep = () => [...document.querySelectorAll('.audit-stepper li')].findIndex(item => item.getAttribute('aria-current') === 'step');

  const steps = [
    { title: ['Cameras and sensors are connected', 'Kameras und Sensoren sind verbunden'], body: ['Each live connection streams into MIRA, is tied to an ASTRA order and component, and shows the certification clause it creates evidence for.', 'Jede Live-Verbindung liefert Daten an MIRA, ist einem ASTRA-Auftrag und Bauteil zugeordnet und zeigt die Zertifizierungsklausel, f\u00fcr die sie Nachweise erzeugt.'],
      run: async () => { ensureView('connections'); await wait(60); scrollTo('#connections-view'); } },
    { title: ['A deviation is caught automatically', 'Eine Abweichung wird automatisch erkannt'], body: ['A sensor reading breaks its limit. The evidence window is flagged and blocked from verification, without anyone having to spot it.', 'Ein Messwert \u00fcberschreitet den Grenzwert. Das Nachweisfenster wird markiert und f\u00fcr die Verifizierung gesperrt, ohne dass es jemand bemerken muss.'],
      run: async () => {
        ensureView('connections');
        if (!api().state().running) { note = text('Live capture is paused. Resume it in the Live connections tab first.', 'Die Live-Erfassung ist pausiert. Setzen Sie sie zuerst im Tab Live-Verbindungen fort.'); return; }
        if (!openAlert()) api().simulateDeviation('SNS-WELD-01');
        await wait(150);
        scrollTo('[data-live-alerts]');
        note = text('Deviation raised on the weld parameter sensor.', 'Abweichung am Schwei\u00dfparameter-Sensor ausgel\u00f6st.');
      } },
    { title: ['A person resolves it with a note', 'Eine Person kl\u00e4rt es mit einer Notiz'], body: ['A reviewer closes the deviation with a corrective-action note. The failed window is closed and a clean one starts.', 'Eine Pr\u00fcfperson schlie\u00dft die Abweichung mit einer Korrekturnotiz. Das fehlerhafte Fenster wird geschlossen, ein sauberes beginnt.'],
      run: async () => {
        ensureView('connections');
        if (!openAlert()) { api().simulateDeviation('SNS-WELD-01'); await wait(250); }
        const alert = openAlert();
        const form = alert && q(`[data-pai-resolve="${alert.id}"]`);
        if (!form) { note = text('No open deviation to resolve.', 'Keine offene Abweichung zu kl\u00e4ren.'); return; }
        form.elements.note.value = text('Torch cooling adjusted and joint re-checked (demo note).', 'K\u00fchlung des Brenners angepasst und Naht erneut gepr\u00fcft (Demonotiz).');
        form.requestSubmit();
        await wait(150);
        note = text('Deviation closed with a corrective-action note.', 'Abweichung mit Korrekturnotiz geschlossen.');
      } },
    { title: ['Clean evidence is verified by a person', 'Saubere Nachweise verifiziert eine Person'], body: ['Machine-captured evidence only counts after an authorized reviewer verifies it. This verifies one ready window.', 'Maschinell erfasste Nachweise z\u00e4hlen erst nach Verifizierung durch eine autorisierte Pr\u00fcfperson. Hier wird ein bereites Fenster verifiziert.'],
      run: async () => {
        ensureView('connections');
        let button;
        for (let attempt = 0; attempt < 25 && !button; attempt++) {
          button = [...document.querySelectorAll('#connections-view [data-action="verify-evidence"]')].find(item => !item.disabled);
          if (!button) await wait(1000);
        }
        if (!button) { note = text('Windows are still collecting readings. Try again in a few seconds.', 'Die Fenster erfassen noch Messwerte. In wenigen Sekunden erneut versuchen.'); return; }
        button.click();
        await wait(150);
        note = text('One window verified. It now counts as evidence.', 'Ein Fenster verifiziert. Es z\u00e4hlt nun als Nachweis.');
      } },
    { title: ['See what still blocks the auditor', 'Sehen, was den Auditor noch blockiert'], body: ['The All view lists every missing or unverified evidence item per certification and site, with the likely source.', 'Die Ansicht \u201eAlle\u201c listet jeden fehlenden oder nicht verifizierten Nachweis je Zertifizierung und Standort mit der wahrscheinlichen Quelle.'],
      run: async () => { ensureView('requirements'); q('[data-mira-filter="all"]')?.click(); await wait(80); scrollTo('#open-items'); } },
    { title: ['Audit checklist by clause', 'Audit-Checkliste nach Klausel'], body: ['Choosing a standard builds a clause checklist (evidence A, B, C) and shows which camera, sensor, SAP or SharePoint can supply each item.', 'Die Wahl einer Norm erzeugt eine Klausel-Checkliste (Nachweis A, B, C) und zeigt, welche Kamera, welcher Sensor, SAP oder SharePoint jeden Punkt liefern kann.'],
      run: async () => {
        ensureView('requirements');
        window.DemoV2AuditModal.open();
        q('[data-select-audit="CAT-QMS-9001"]').click();
        confirmBox('[data-confirm-scope]');
        q('[data-guide-next]').click();
        await wait(80);
      } },
    { title: ['Add missing evidence in the tool', 'Fehlende Nachweise im Tool hinzuf\u00fcgen'], body: ['For a gap, upload a file or create the document with ROSNIE, guided through every required field. Nothing is approved automatically.', 'F\u00fcr eine L\u00fccke eine Datei hochladen oder das Dokument mit ROSNIE erstellen, gef\u00fchrt durch alle Pflichtfelder. Nichts wird automatisch freigegeben.'],
      run: async () => {
        if (!q('#audit-catalog-dialog[open]')) { window.DemoV2AuditModal.open(); q('[data-select-audit="CAT-QMS-9001"]').click(); confirmBox('[data-confirm-scope]'); q('[data-guide-next]').click(); await wait(60); }
        for (let guard = 0; guard < 4 && auditStep() < 3; guard++) { confirmBox('[data-confirm-scope]'); confirmBox('[data-confirm-evidence]'); q('[data-guide-next]')?.click(); await wait(60); }
        q('[data-gap-add]')?.click();
        await wait(80);
        q('.audit-gaps')?.scrollIntoView({ block: 'start', behavior: 'smooth' });
      } },
    { title: ['Hand over to the auditor', '\u00dcbergabe an den Auditor'], body: ['One printable package per certification and site: evidence, who captured it, who verified it, and what is still open. Print it or save it as PDF.', 'Ein druckbares Paket je Zertifizierung und Standort: Nachweise, wer sie erfasst und wer sie verifiziert hat, und was noch offen ist. Drucken oder als PDF speichern.'],
      run: async () => { closeDialogs(); window.DemoV2AuditorPackage.open({ cert: 'ISO 3834' }); await wait(120); } }
  ];

  function place() {
    const host = [...document.querySelectorAll('dialog[open]')].pop();
    if (host) host.querySelector('.audit-modal-header')?.after(banner);
    else document.body.append(banner);
  }
  function render() {
    document.body.classList.toggle('tour-active', active);
    if (!active) { banner.remove(); return; }
    const step = steps[index];
    const last = index === steps.length - 1;
    banner.setAttribute('aria-label', text('Guided demo', 'Gef\u00fchrte Demo'));
    banner.innerHTML = `<div class="tour-head"><span>${text('Guided demo', 'Gef\u00fchrte Demo')} \u00b7 ${text('Step', 'Schritt')} ${index + 1} / ${steps.length}</span><button class="button text" type="button" data-tour-exit>${text('Exit', 'Beenden')}</button></div><h3>${esc(text(step.title[0], step.title[1]))}</h3><p>${esc(text(step.body[0], step.body[1]))}</p>${note ? `<p class="tour-note" role="status">${esc(note)}</p>` : ''}<div class="tour-actions"><button class="button secondary" type="button" data-tour-back ${index === 0 ? 'disabled' : ''}>${text('Back', 'Zur\u00fcck')}</button><button class="button primary" type="button" data-tour-run ${busy ? 'disabled' : ''}>${busy ? text('Working\u2026', 'L\u00e4uft\u2026') : text('Show me', 'Zeig es mir')}</button><button class="button secondary" type="button" data-tour-next ${busy ? 'disabled' : ''}>${last ? text('Finish', 'Fertig') : text('Next', 'Weiter')}</button></div>`;
    place();
  }
  async function run() {
    if (busy) return;
    busy = true;
    note = '';
    render();
    try { await steps[index].run(); }
    catch { note = text('This step could not run. Use Next to continue.', 'Dieser Schritt konnte nicht ausgef\u00fchrt werden. Mit Weiter fortfahren.'); }
    busy = false;
    render();
  }
  function start() {
    if (active) return;
    if (!reviewers.includes(app().settings.role)) {
      savedRole = app().settings.role;
      app().settings.role = 'Quality Manager';
      try { localStorage.setItem(KEYS[2], JSON.stringify(app().settings)); } catch { /* role stays in memory */ }
      app().render();
      note = text('Role switched to Quality Manager for this tour; it is restored when you exit.', 'Rolle f\u00fcr diese Tour auf Qualit\u00e4tsmanagement gestellt; sie wird beim Beenden zur\u00fcckgesetzt.');
    } else note = '';
    active = true;
    index = 0;
    busy = false;
    render();
  }
  function exit() {
    active = false;
    closeDialogs();
    if (savedRole) {
      app().settings.role = savedRole;
      try { localStorage.setItem(KEYS[2], JSON.stringify(app().settings)); } catch { /* role stays in memory */ }
      savedRole = null;
      app().render();
    }
    render();
  }
  function labels() {
    const start_ = q('#tour-start');
    const reset = q('#demo-reset');
    if (start_) start_.textContent = text('Guided demo \u00b7 3 min', 'Gef\u00fchrte Demo \u00b7 3 Min.');
    if (reset) reset.textContent = text('Reset demo data', 'Demodaten zur\u00fccksetzen');
  }
  function reset() {
    if (!window.confirm(text('Reset all demo data in this browser? Your changes and uploads will be removed.', 'Alle Demodaten in diesem Browser zur\u00fccksetzen? Ihre \u00c4nderungen und Uploads werden entfernt.'))) return;
    window.__demoResetting = true;
    KEYS.forEach(key => localStorage.removeItem(key));
    location.href = location.pathname + '?workspace=astra';
  }

  banner.addEventListener('click', event => {
    if (event.target.closest('[data-tour-exit]')) exit();
    else if (event.target.closest('[data-tour-run]')) run();
    else if (event.target.closest('[data-tour-back]')) { index = Math.max(0, index - 1); note = ''; render(); }
    else if (event.target.closest('[data-tour-next]')) { if (index === steps.length - 1) exit(); else { index++; note = ''; render(); } }
  });
  document.addEventListener('close', () => { if (active) setTimeout(place, 0); }, true);
  document.addEventListener('click', event => {
    if (event.target.closest('#tour-start')) start();
    else if (event.target.closest('#demo-reset')) reset();
  });
  new MutationObserver(() => { labels(); if (active) render(); }).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
  labels();
  window.DemoV2Tour = { start, exit, steps, isActive: () => active };
  if (new URL(location.href).searchParams.get('tour') === '1') start();
})();
