(() => {
  const A = () => window.DemoV2Auditors;
  const app = () => window.DemoV2;
  const modal = () => window.DemoV2AuditModalInternals;
  const lib = () => window.DemoV2Library;
  const text = (english, german) => app().settings.language === 'de' ? german : english;
  const tx = pair => text(pair[0], pair[1]);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const canDecide = () => ['Auditor', 'Administrator'].includes(app().settings.role);
  const when = value => value ? new Date(value).toLocaleString(app().settings.language === 'de' ? 'de-DE' : 'en-GB') : '\u2014';
  const day = value => value ? new Date(value + 'T00:00:00').toLocaleDateString(app().settings.language === 'de' ? 'de-DE' : 'en-GB') : '\u2014';
  const clauseLabel = (standard, ref) => `${standard} ${/^(\d|A\.)/.test(ref) ? text('Clause ', 'Abschnitt ') : text('Demo reference ', 'Demo-Referenz ')}${ref}`;
  const kindLabel = kind => { const item = lib().kinds[kind]; return item ? tx(item.label) : kind; };
  let selectedId = '';
  let siteChoice = '';
  let decisionForm = '';
  let drafts = { reqClause: '', reqKind: '', reqNote: '', reqDue: '', decNote: '', decAck: false };
  let traceKey = null;
  let traceRequestId = null;

  function seed() {
    const compliance = app().compliance;
    if (compliance.auditSeedV1 || (compliance.audits || []).length || !modal()) return false;
    const defs = [['CAT-WELD-3834', 'Dortmund Fabrication Workshop', 21], ['CAT-QMS-9001', 'Rheinpark Biomass CHP Plant', 35], ['CAT-PERMIT', 'Rheinpark Biomass CHP Plant', 14]];
    defs.forEach(([catalogId, site, days], index) => {
      const entry = modal().catalogue().find(item => item.id === catalogId);
      if (!entry) return;
      const base = modal().coverage(entry);
      compliance.audits.push({
        id: 'AUDIT-SAMPLE-' + (index + 1), catalogId, framework: entry.name, title: entry.name,
        type: ['Regulation', 'Permit condition'].includes(entry.type) ? 'Regulatory compliance review' : 'Certification readiness review',
        version: entry.version, source: entry.source, status: 'Planned', auditor: 'Unassigned', site, plannedDate: A().inDays(days), notes: 'Sample audit',
        compliancePercent: base.percent, totalControls: base.total, verifiedControls: base.verified, orderIds: base.orders.map(order => order.id), componentIds: base.componentIds,
        evidenceIds: base.evidenceIds, controlIds: base.controls.map(control => control.id), missingEvidence: base.missing, pendingEvidence: base.pending, evidenceSnapshot: [],
        createdAt: new Date().toISOString(), createdBy: 'Demo sample', sample: true, requests: [], reviews: {}, history: []
      });
    });
    compliance.auditSeedV1 = true;
    A().saveCompliance();
    return true;
  }

  function evaluate(audit, site) {
    const entry = A().entryOf(audit);
    if (!entry) return null;
    const base = modal().coverage(entry);
    const filter = site && site !== 'all' ? site : '';
    const scope = app().operations.orders.filter(order => (audit.orderIds?.length ? audit.orderIds.includes(order.id) : base.orders.some(item => item.id === order.id)) && (!filter || order.site === filter) && (!audit.contract?.customer || order.customer === audit.contract.customer));
    const data = modal().checklistFor(entry, { ...base, orders: scope });
    const items = data.clauses.flatMap(clause => clause.evidence.map(item => ({ clause, item, key: clause.ref + '|' + item.id })));
    const reviews = audit.reviews || {};
    const sources = { live: 0, astra: 0, upload: 0, missing: 0 };
    for (const entryItem of items) {
      const records = entryItem.item.pairs.map(pair => pair.record).filter(Boolean);
      sources[records.length ? A().sourceKind(records[0]) : 'missing']++;
    }
    const total = items.length || 1;
    const verified = items.filter(entryItem => entryItem.item.status === 'verified').length;
    const reviewed = items.filter(entryItem => reviews[entryItem.key]?.state === 'accepted').length;
    return { entry, data, items, scope, sources, verified, reviewed, total: items.length, verifiedPct: Math.round(verified / total * 100), reviewedPct: Math.round(reviewed / total * 100), missing: items.filter(entryItem => entryItem.item.status === 'missing').length, pending: items.filter(entryItem => entryItem.item.status === 'pending').length };
  }
  const siteFor = audit => siteChoice && A().siteOf(audit) === '' ? siteChoice : A().siteOf(audit);
  const meter = (label, percent, detail, tone = '') => `<div class="av-meter"><div class="av-meter-head"><span>${esc(label)}</span><strong>${percent}%</strong></div><div class="av-meter-bar ${tone}"><span style="width:${percent}%"></span></div><small>${esc(detail)}</small></div>`;
  const sourceChip = id => { const device = window.DemoV2PhysicalAI?.devices.find(item => item.id === id); return `<span class="source-chip ${device ? 'live' : ''}">${esc(device ? id : tx(lib().sources[id].name))}</span>`; };

  function pickerHtml(current) {
    return `<div class="av-picker">${A().audits().map(audit => {
      const site = A().siteOf(audit);
      const result = evaluate(audit, site);
      return `<button type="button" class="av-audit ${audit.id === current ? 'active' : ''}" data-av-select="${esc(audit.id)}" aria-pressed="${audit.id === current}"><span class="av-audit-top"><strong>${esc(audit.framework)}</strong><span class="tag ${A().statusTone(audit.status)}">${esc(A().statusLabel(audit.status))}</span></span><small>${esc(site || text('All sites in scope', 'Alle Standorte im Umfang'))} \u00b7 ${esc(day(audit.plannedDate))}</small><small>${esc(audit.assignedAuditor ? audit.assignedAuditor.name : text('No auditor assigned', 'Kein Auditor zugewiesen'))}</small>${result ? `<span class="av-mini">${text('Verified', 'Verifiziert')} ${result.verifiedPct}% \u00b7 ${text('Reviewed', 'Gepr\u00fcft')} ${result.reviewedPct}%</span>` : ''}</button>`;
    }).join('')}</div>`;
  }
  function itemHtml(audit, entryItem) {
    const { item, key, clause } = entryItem;
    const records = [...new Map(item.pairs.map(pair => pair.record).filter(Boolean).map(record => [record.id, record])).values()];
    const done = item.pairs.filter(pair => pair.verified).length;
    const tone = item.status === 'verified' ? 'green' : item.status === 'pending' ? 'amber' : 'red';
    const label = item.status === 'verified' ? text('Verified', 'Verifiziert') : item.status === 'pending' ? text('Awaiting review', 'In Pr\u00fcfung') : text('Missing', 'Fehlt');
    const review = (audit.reviews || {})[key];
    const sources = lib().kinds[item.kind].sources;
    const decided = ['Approved', 'Declined'].includes(audit.status);
    return `<li class="audit-clause-item"><span class="audit-clause-letter">${esc(item.id)}</span><div><strong>${esc(kindLabel(item.kind))}</strong><small>${esc(item.pairs.map(pair => pair.orderId ? pair.orderId + ' \u00b7 ' + pair.componentId : '').filter(Boolean).join(' | '))}</small><div class="source-chips">${records.length ? records.map(record => `<span class="source-chip ${record.origin === 'sensor-captured' ? 'live' : ''}">${esc(A().sourceLabel(record))}</span>`).join('') : `<span class="source-label">${text('Could come from', 'Kann kommen aus')}:</span>${sources.map(sourceChip).join('')}`}${review ? `<span class="source-chip ${review.state === 'accepted' ? 'live' : 'clause'}">${review.state === 'accepted' ? text('Accepted by auditor', 'Vom Auditor akzeptiert') : text('Questioned by auditor', 'Vom Auditor hinterfragt')}</span>` : ''}</div><div class="av-actions">${records.length ? `<button type="button" class="button secondary" data-av-trace="${esc(key)}">${text('Trace source', 'Quelle zur\u00fcckverfolgen')}</button>` : ''}<button type="button" class="button text" data-av-accept="${esc(key)}" ${canDecide() && item.status !== 'missing' && !decided ? '' : 'disabled'}>${text('Accept', 'Akzeptieren')}</button><button type="button" class="button text" data-av-question="${esc(key)}" ${canDecide() && !decided ? '' : 'disabled'}>${text('Request more', 'Mehr anfordern')}</button></div></div><span class="tag ${tone}">${esc(label)}${item.pairs.length > 1 ? ' ' + done + '/' + item.pairs.length : ''}</span></li>`;
  }
  function requestsHtml(audit, result) {
    const requests = audit.requests || [];
    const decided = ['Approved', 'Declined'].includes(audit.status);
    const clauses = result.data.clauses;
    const clauseKey = drafts.reqClause || (clauses[0] ? clauses[0].ref : '');
    const chosen = clauses.find(clause => clause.ref === clauseKey) || clauses[0];
    const kinds = chosen ? [...new Set(chosen.evidence.map(item => item.kind))] : [];
    const kind = kinds.includes(drafts.reqKind) ? drafts.reqKind : kinds[0];
    const status = request => request.status === 'open' ? ['amber', text('Open', 'Offen')] : request.status === 'provided' ? ['green', text('Provided: review', 'Geliefert: pr\u00fcfen')] : request.status === 'closed' ? ['', text('Closed', 'Geschlossen')] : ['', text('Withdrawn', 'Zur\u00fcckgezogen')];
    return `<section class="av-panel"><h3>${text('Evidence requests', 'Nachweisanforderungen')}</h3>${requests.length ? `<div class="av-requests">${requests.map(request => { const [tone, label] = status(request); return `<div class="av-request"><div><strong>${esc(clauseLabel(request.standard, request.ref))} \u00b7 ${esc(tx(request.title))}</strong><small>${esc(kindLabel(request.kind))} \u00b7 ${text('due', 'f\u00e4llig')} ${esc(day(request.due))}</small><p>${esc(request.note)}</p></div><div class="av-request-side"><span class="tag ${tone}">${esc(label)}</span>${request.status === 'provided' ? `<button type="button" class="button text" data-av-trace-request="${esc(request.id)}">${text('Trace evidence', 'Nachweis ansehen')}</button><button type="button" class="button text" data-av-close-request="${esc(request.id)}" ${canDecide() ? '' : 'disabled'}>${text('Close request', 'Anforderung schlie\u00dfen')}</button>` : ''}${request.status === 'open' && canDecide() ? `<button type="button" class="button text" data-av-withdraw-request="${esc(request.id)}">${text('Withdraw', 'Zur\u00fcckziehen')}</button>` : ''}</div></div>`; }).join('')}</div>` : `<p class="physical-ai-empty">${text('No evidence requested yet.', 'Noch keine Nachweise angefordert.')}</p>`}${decided ? '' : `<form class="av-request-form" data-av-request-form><h4>${text('Request evidence by clause', 'Nachweis nach Klausel anfordern')}</h4><div class="form-grid"><label class="field">${text('Clause', 'Klausel')}<select name="clause" data-av-field="reqClause">${clauses.map(clause => `<option value="${esc(clause.ref)}" ${clause.ref === clauseKey ? 'selected' : ''}>${esc(clauseLabel(result.data.standard, clause.ref) + ' \u00b7 ' + tx(clause.title))}</option>`).join('')}</select></label><label class="field">${text('Evidence type', 'Nachweisart')}<select name="kind" data-av-field="reqKind">${kinds.map(item => `<option value="${esc(item)}" ${item === kind ? 'selected' : ''}>${esc(kindLabel(item))}</option>`).join('')}</select></label><label class="field">${text('Due date', 'F\u00e4lligkeitsdatum')}<input name="due" type="date" required value="${esc(drafts.reqDue || A().inDays(14))}" data-av-field="reqDue"></label></div><label class="field">${text('What do you need and why?', 'Was wird ben\u00f6tigt und warum?')}<textarea name="note" required maxlength="400" data-av-field="reqNote">${esc(drafts.reqNote)}</textarea></label><div class="form-actions"><button class="button secondary" type="submit" ${canDecide() ? '' : 'disabled'}>${text('Add request', 'Anforderung hinzuf\u00fcgen')}</button></div></form>`}</section>`;
  }
  function decisionHtml(audit, result) {
    const requests = audit.requests || [];
    const blocking = requests.filter(request => ['open', 'provided'].includes(request.status)).length;
    const exceptions = result.total - result.items.filter(entryItem => entryItem.item.status === 'verified' && (audit.reviews || {})[entryItem.key]?.state === 'accepted').length;
    const openCount = requests.filter(request => request.status === 'open').length;
    const decision = audit.decision;
    const lead = `<p class="audit-prefill-note">${text('Demo auditor decision. It records the outcome in this demo and is not a certification decision.', 'Demo-Auditorenentscheidung. Sie h\u00e4lt das Ergebnis in dieser Demo fest und ist keine Zertifizierungsentscheidung.')}</p>`;
    if (decision) return `<section class="av-panel"><h3>${text('Decision', 'Entscheidung')}</h3>${lead}<div class="av-decision ${decision.state}"><span class="tag ${A().statusTone(audit.status)}">${esc(A().statusLabel(audit.status))}</span><p>${esc(decision.note || '')}</p><small>${esc(decision.by)} \u00b7 ${esc(when(decision.at))}${decision.exceptions ? ' \u00b7 ' + decision.exceptions + ' ' + text('documented exceptions', 'dokumentierte Ausnahmen') : ''}</small></div>${canDecide() ? `<button type="button" class="button secondary" data-av-reopen>${text('Reopen review', 'Pr\u00fcfung wieder \u00f6ffnen')}</button>` : ''}</section>`;
    const roleBlock = canDecide() ? '' : `<p class="audit-prefill-note">${text('Only an Auditor can decide. Your current role is', 'Nur ein Auditor kann entscheiden. Ihre aktuelle Rolle ist')} <strong>${esc(app().settings.role)}</strong>. <button type="button" class="button text" data-av-act-auditor>${text('Act as Auditor (demo)', 'Als Auditor handeln (Demo)')}</button></p>`;
    const form = !decisionForm ? '' : `<form class="av-decision-form" data-av-decision-form="${decisionForm}"><h4>${decisionForm === 'approve' ? text('Approve', 'Freigeben') : decisionForm === 'hold' ? text('Put on hold', 'Anhalten') : text('Decline', 'Ablehnen')}</h4>${decisionForm === 'approve' && exceptions > 0 ? `<p class="audit-prefill-note">${exceptions} ${text('evidence items are not both verified and accepted (', 'Nachweise sind nicht zugleich verifiziert und akzeptiert (')}${result.missing} ${text('missing', 'fehlend')}, ${result.pending} ${text('awaiting review', 'in Pr\u00fcfung')}). ${text('Approving records them as documented exceptions.', 'Eine Freigabe h\u00e4lt sie als dokumentierte Ausnahmen fest.')}</p><label class="audit-guide-confirm"><input type="checkbox" data-av-field="decAck" ${drafts.decAck ? 'checked' : ''}>${text('I approve despite the listed exceptions and will explain them below.', 'Ich gebe trotz der aufgef\u00fchrten Ausnahmen frei und erl\u00e4utere sie unten.')}</label>` : ''}${decisionForm === 'hold' && !openCount ? `<p class="audit-prefill-note">${text('Add at least one evidence request above before putting the audit on hold.', 'F\u00fcgen Sie oben mindestens eine Nachweisanforderung hinzu, bevor Sie das Audit anhalten.')}</p>` : ''}<label class="field">${decisionForm === 'hold' ? text('Reason for the hold', 'Grund f\u00fcr das Anhalten') : text('Reason / explanation', 'Begr\u00fcndung / Erl\u00e4uterung')}<textarea required maxlength="600" data-av-field="decNote">${esc(drafts.decNote)}</textarea></label><p role="alert" class="evidence-editor-error" data-av-error></p><div class="form-actions"><button type="button" class="button text" data-av-cancel-decision>${text('Cancel', 'Abbrechen')}</button><button type="submit" class="button primary">${text('Confirm decision', 'Entscheidung best\u00e4tigen')}</button></div></form>`;
    return `<section class="av-panel"><h3>${text('Decision', 'Entscheidung')}</h3>${lead}${roleBlock}<div class="av-decision-buttons"><button type="button" class="button primary" data-av-decide="approve" ${canDecide() && !blocking ? '' : 'disabled'}>${text('Approve', 'Freigeben')}</button><button type="button" class="button secondary" data-av-decide="hold" ${canDecide() ? '' : 'disabled'}>${text('Hold', 'Anhalten')}</button><button type="button" class="button secondary danger" data-av-decide="decline" ${canDecide() ? '' : 'disabled'}>${text('Decline', 'Ablehnen')}</button></div>${blocking ? `<p class="physical-ai-empty">${text('Approve is unavailable while evidence requests are open or awaiting your review.', 'Freigabe ist nicht m\u00f6glich, solange Nachweisanforderungen offen oder noch zu pr\u00fcfen sind.')}</p>` : ''}${form}</section>`;
  }
  function historyHtml(audit) {
    const history = audit.history || [];
    if (!history.length) return '';
    return `<section class="av-panel"><h3>${text('History', 'Verlauf')}</h3><ul class="av-history">${history.slice().reverse().map(entry => `<li><time>${esc(when(entry.at))}</time><span><strong>${esc(entry.by)}</strong> ${esc(entry.action)}${entry.note ? ': ' + esc(entry.note) : ''}</span></li>`).join('')}</ul></section>`;
  }
  function detailHtml(audit) {
    const site = siteFor(audit);
    const result = evaluate(audit, site);
    if (!result) return `<p class="physical-ai-empty">${text('This audit has no catalogue entry.', 'Dieses Audit hat keinen Katalogeintrag.')}</p>`;
    const sites = [...new Set(result.scope.map(order => order.site).concat(app().operations.orders.map(order => order.site)))];
    const assigned = audit.assignedAuditor;
    const fixedSite = A().siteOf(audit);
    return `<section class="av-detail"><div class="av-head"><div><p class="heading-kicker">${text('Audit', 'Audit')} \u00b7 ${esc(audit.id.slice(0, 18))}</p><h2>${esc(audit.framework)}</h2></div><span class="tag ${A().statusTone(audit.status)}">${esc(A().statusLabel(audit.status))}</span></div><div class="audit-launch-summary"><div><small>${text('Certification', 'Zertifizierung')}</small><strong>${esc(result.data.standard)}</strong></div><div><small>${text('Site', 'Standort')}</small>${fixedSite ? `<strong>${esc(fixedSite)}</strong>` : `<select class="av-site" data-av-site aria-label="${text('Site', 'Standort')}"><option value="">${text('All sites in scope', 'Alle Standorte im Umfang')}</option>${sites.map(item => `<option ${item === site ? 'selected' : ''}>${esc(item)}</option>`).join('')}</select>`}</div><div><small>${text('Planned date', 'Geplantes Datum')}</small><strong>${esc(day(audit.plannedDate))}</strong></div><div><small>${text('Auditor', 'Auditor')}</small><strong>${esc(assigned ? assigned.name + ' \u00b7 ' + assigned.firm : text('Unassigned', 'Nicht zugewiesen'))}</strong></div></div><div class="av-meters">${meter(text('Evidence verified', 'Nachweise verifiziert'), result.verifiedPct, `${result.verified}/${result.total} ${text('items verified by the customer reviewer', 'Nachweise vom Pr\u00fcfer des Kunden verifiziert')}`, result.verifiedPct < 50 ? 'red' : result.verifiedPct < 70 ? 'amber' : 'green')}${meter(text('Reviewed by auditor', 'Vom Auditor gepr\u00fcft'), result.reviewedPct, `${result.reviewed}/${result.total} ${text('items accepted', 'Nachweise akzeptiert')}`, 'blue')}</div><div class="av-sources"><strong>${text('Where the evidence comes from', 'Woher die Nachweise stammen')}</strong><span class="source-chip live">${text('Live connections', 'Live-Verbindungen')}: ${result.sources.live}</span><span class="source-chip">${text('ASTRA documents', 'ASTRA-Dokumente')}: ${result.sources.astra}</span><span class="source-chip">${text('Uploads / sample files', 'Uploads / Beispieldateien')}: ${result.sources.upload}</span><span class="source-chip clause">${text('Missing', 'Fehlt')}: ${result.sources.missing}</span></div><h3>${text('Evidence by clause', 'Nachweise nach Klausel')}</h3><p class="audit-prefill-note">${esc(tx(result.data.note))}</p>${result.data.clauses.map(clause => `<article class="audit-clause"><header><strong>${esc(clauseLabel(result.data.standard, clause.ref))}</strong><span>${esc(tx(clause.title))}</span></header><ol class="audit-clause-items">${clause.evidence.map(item => itemHtml(audit, result.items.find(entry => entry.clause.ref === clause.ref && entry.item.id === item.id))).join('')}</ol></article>`).join('')}</section>${requestsHtml(audit, result)}${decisionHtml(audit, result)}${historyHtml(audit)}`;
  }
  function render() {
    seed();
    const root = document.querySelector('#auditor-view');
    if (!root) return;
    const audits = A().audits();
    audits.forEach(A().syncRequests);
    if (!audits.length) { root.innerHTML = `<section class="panel"><p class="physical-ai-empty">${text('No audits yet. Plan one in the Customer view with Start audit.', 'Noch keine Audits. Planen Sie eines in der Kundensicht mit Audit starten.')}</p></section>`; return; }
    if (!audits.some(audit => audit.id === selectedId)) { selectedId = ''; siteChoice = ''; }
    if (!selectedId) {
      root.innerHTML = window.DemoV2AuditorPortfolio?.html() || pickerHtml('');
      return;
    }
    const audit = audits.find(item => item.id === selectedId);
    root.innerHTML = `<button type="button" class="button text" data-av-overview>${text('Back to customers & contracts', 'Zurück zu Kunden & Verträgen')}</button>${window.DemoV2AuditorPortfolio?.context(audit) || ''}${detailHtml(audit)}`;
  }
  function refresh() {
    const scroll = window.scrollY;
    A().saveCompliance();
    app().render();
    window.scrollTo(0, scroll);
  }
  const current = () => A().audits().find(audit => audit.id === selectedId);
  const actor = audit => audit.assignedAuditor ? audit.assignedAuditor.name : app().settings.user;
  function log(audit, action, note = '') { (audit.history ||= []).push({ at: new Date().toISOString(), by: actor(audit), action, note }); }

  const dialog = document.createElement('dialog');
  dialog.id = 'trace-dialog';
  dialog.className = 'audit-modal trace-dialog';
  dialog.setAttribute('aria-labelledby', 'trace-title');
  dialog.innerHTML = '<header class="audit-modal-header"><div><small>MIRA \u00b7 AUDITOR</small><h2 id="trace-title"></h2></div><button class="button secondary evidence-editor-close" type="button"></button></header><div class="audit-modal-body" id="trace-body"></div>';
  document.body.append(dialog);
  const traceBody = dialog.querySelector('#trace-body');
  function chainHtml(record) {
    const device = record.origin === 'sensor-captured' ? window.DemoV2PhysicalAI?.devices.find(item => item.id === record.deviceId) : null;
    const order = app().operations.orders.find(item => item.id === record.orderId);
    const verified = app().compliance.verifiedBy.find(item => item.evidenceId === record.id);
    const steps = [];
    if (device) steps.push([text('Source: live connection', 'Quelle: Live-Verbindung'), `${tx(device.name)} (${device.id}) \u00b7 ${device.protocol} \u00b7 ${device.site}. ${text('Simulated demo feed.', 'Simulierter Demo-Datenstrom.')} ${text('Rule', 'Regel')}: ${tx(device.limit)}`]);
    else if (record.origin === 'astra-authored') steps.push([text('Source: ASTRA guided document', 'Quelle: ASTRA-gef\u00fchrtes Dokument'), `${text('Created in ASTRA; prefilled from order data, facts entered by', 'In ASTRA erstellt; aus Auftragsdaten vorausgef\u00fcllt, Fakten erfasst von')} ${record.createdBy}.`]);
    else steps.push([text('Source: file', 'Quelle: Datei'), `${record.fileName || '\u2014'}${record.size ? ' \u00b7 ' + Math.max(1, Math.round(record.size / 1024)) + ' KB' : ''} \u00b7 ${record.dataUrl ? text('uploaded by', 'hochgeladen von') + ' ' + record.createdBy : text('sample file in the demo data', 'Beispieldatei in den Demodaten')}`]);
    steps.push([text('Captured', 'Erfasst'), `${when(record.createdAt)} \u00b7 ${record.createdBy || '\u2014'}`]);
    steps.push([text('Linked to ASTRA', 'Mit ASTRA verkn\u00fcpft'), `${record.orderId} \u00b7 ${order ? order.name + ' \u00b7 ' + order.customer + ' \u00b7 ' + order.site : ''} \u00b7 ${record.componentId}`]);
    if (record.telemetry) {
      const tl = record.telemetry;
      const unit = device?.unit || '';
      const avg = tl.count ? tl.sum / tl.count : 0;
      steps.push([text('Captured data', 'Erfasste Daten'), `${tl.count} ${text('readings', 'Messwerte')}${device && device.rule !== 'camera' ? ` \u00b7 min ${Number(tl.min ?? 0).toFixed(1)} / \u00d8 ${avg.toFixed(1)} / max ${Number(tl.max ?? 0).toFixed(1)} ${unit}` : ` \u00b7 \u00d8 ${avg.toFixed(0)} %`} \u00b7 ${text('deviations', 'Abweichungen')}: ${tl.exceedances.length}`]);
    }
    if (record.addresses?.length) steps.push([text('Addresses clauses', 'Bezieht sich auf Klauseln'), record.addresses.map(item => clauseLabel(item.standard, item.ref)).join(', ')]);
    steps.push([text('Verification', 'Verifizierung'), record.status === 'approved' ? (verified ? `${verified.user} \u00b7 ${when(verified.time)}` : text('Sample data: no verification record', 'Beispieldaten: kein Verifizierungsnachweis')) : record.result === 'Fail' ? text('Deviation: not verifiable', 'Abweichung: nicht verifizierbar') : text('Not yet verified', 'Noch nicht verifiziert')]);
    return `<section class="trace-record"><h3>${esc(record.title)}</h3><ol class="trace-chain">${steps.map(([title, body]) => `<li><strong>${esc(title)}</strong><span>${esc(body)}</span></li>`).join('')}</ol>${device ? `<p class="audit-prefill-note">${text('Current live view of the source device (simulated; not the footage or data from the time of capture).', 'Aktuelle Live-Ansicht des Quellger\u00e4ts (simuliert; nicht das Material oder die Daten zum Erfassungszeitpunkt).')}</p>${device.type === 'camera' ? `<div class="physical-ai-frame"><canvas data-live-canvas="camera" data-device="${esc(device.id)}" role="img" aria-label="${esc(tx(device.name))}"></canvas></div>` : ''}<div class="physical-ai-spark trace-chart"><canvas data-live-canvas="chart" data-device="${esc(device.id)}" role="img" aria-label="${esc(tx(device.label))}"></canvas></div>` : ''}<div class="av-actions">${record.dataUrl ? `<button type="button" class="button secondary" data-av-open-record="${esc(record.id)}">${text('Open document / file', 'Dokument / Datei \u00f6ffnen')}</button>` : ''}${device ? `<button type="button" class="button secondary" data-av-open-live="${esc(device.id)}">${text('Open in Live connections', 'In Live-Verbindungen \u00f6ffnen')}</button>` : ''}</div></section>`;
  }
  function openTrace(key, requestId) {
    const audit = current();
    if (!audit) return;
    const result = evaluate(audit, siteFor(audit));
    let records = [];
    let heading = '';
    if (requestId) {
      const request = (audit.requests || []).find(item => item.id === requestId);
      const record = app().operations.evidence.find(item => item.id === request?.evidenceId);
      if (record) records = [record];
      heading = request ? clauseLabel(request.standard, request.ref) : '';
      traceKey = null;
    } else {
      const entry = result.items.find(item => item.key === key);
      records = [...new Map(entry.item.pairs.map(pair => pair.record).filter(Boolean).map(record => [record.id, record])).values()];
      heading = clauseLabel(result.data.standard, entry.clause.ref) + ' \u00b7 ' + kindLabel(entry.item.kind);
      traceKey = key;
    }
    dialog.querySelector('#trace-title').textContent = text('Trace source', 'Quelle zur\u00fcckverfolgen') + ' \u00b7 ' + heading;
    const close = dialog.querySelector('.evidence-editor-close');
    close.textContent = '\u00d7';
    close.setAttribute('aria-label', text('Close', 'Schlie\u00dfen'));
    traceRequestId = requestId || null;
    traceBody.innerHTML = `${!canDecide() ? `<p class="audit-prefill-note">${text('You can inspect sources in this role. Accepting evidence or requesting more requires the Auditor role.', 'In dieser Rolle können Sie Quellen einsehen. Nachweise akzeptieren oder weitere anfordern erfordert die Auditorrolle.')} <button type="button" class="button secondary" data-av-act-auditor>${text('Act as Auditor (demo)', 'Als Auditor handeln (Demo)')}</button></p>` : ''}${records.map(chainHtml).join('') || `<p class="physical-ai-empty">${text('No evidence recorded yet.', 'Noch kein Nachweis erfasst.')}</p>`}${records.filter(record => !record.dataUrl).map(record => `<details class="trace-sample-preview"><summary>${text('Inspect sample record', 'Beispielnachweis einsehen')}: ${esc(record.fileName || record.id)}</summary><p class="audit-prefill-note">${text('This sample has metadata only. No original file or measurements are attached.', 'Dieses Beispiel enthält nur Metadaten. Keine Originaldatei oder Messwerte sind beigefügt.')}</p><dl><dt>${text('Title', 'Titel')}</dt><dd>${esc(record.title)}</dd><dt>${text('Evidence type', 'Nachweisart')}</dt><dd>${esc(kindLabel(record.kind))}</dd><dt>${text('Record ID', 'Datensatz-ID')}</dt><dd>${esc(record.id)}</dd><dt>${text('Status', 'Status')}</dt><dd>${esc(record.status)}</dd><dt>${text('Captured', 'Erfasst')}</dt><dd>${esc(when(record.createdAt))}</dd></dl></details>`).join('')}<div class="evidence-editor-navigation"><span></span><div><button type="button" class="button secondary" data-av-close-trace>${text('Back to audit', 'Zurück zum Audit')}</button>${traceKey ? `<button type="button" class="button secondary" data-av-question="${esc(traceKey)}" ${canDecide() ? '' : 'disabled'}>${text('Request more', 'Mehr anfordern')}</button><button type="button" class="button primary" data-av-accept="${esc(traceKey)}" ${canDecide() && records.length ? '' : 'disabled'}>${text('Accept evidence', 'Nachweis akzeptieren')}</button>` : ''}</div></div>`;
    document.body.classList.add('audit-modal-open');
    if (!dialog.open) dialog.showModal();
    traceBody.scrollTop = 0;
  }
  dialog.querySelector('.evidence-editor-close').addEventListener('click', () => dialog.close());
  traceBody.addEventListener('click', event => {
    if (event.target.closest('[data-av-close-trace]')) dialog.close();
  });
  dialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); dialog.close(); } });
  dialog.addEventListener('close', () => { if (!document.querySelector('dialog[open]')) document.body.classList.remove('audit-modal-open'); });

  function accept(key) {
    const audit = current();
    if (!audit || !canDecide()) return;
    (audit.reviews ||= {})[key] = { state: 'accepted', by: actor(audit), at: new Date().toISOString() };
    if (dialog.open) dialog.close();
    refresh();
  }
  function question(key) {
    const audit = current();
    if (!audit || !canDecide()) return;
    const result = evaluate(audit, siteFor(audit));
    const entry = result.items.find(item => item.key === key);
    (audit.reviews ||= {})[key] = { state: 'questioned', by: actor(audit), at: new Date().toISOString() };
    drafts.reqClause = entry.clause.ref;
    drafts.reqKind = entry.item.kind;
    drafts.reqNote = drafts.reqNote || '';
    if (dialog.open) dialog.close();
    refresh();
    document.querySelector('[data-av-request-form]')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  function addRequest(form) {
    const audit = current();
    if (!audit || !canDecide() || !form.reportValidity()) return;
    const result = evaluate(audit, siteFor(audit));
    const clause = result.data.clauses.find(item => item.ref === form.elements.clause.value);
    if (!clause || !form.elements.note.value.trim()) return;
    (audit.requests ||= []).push({ id: 'REQ-' + crypto.randomUUID().slice(0, 8), standard: result.data.standard, ref: clause.ref, title: clause.title, kind: form.elements.kind.value, note: form.elements.note.value.trim(), due: form.elements.due.value, status: 'open', createdAt: new Date().toISOString(), createdBy: actor(audit) });
    log(audit, text('requested evidence', 'hat Nachweis angefordert'), `${clauseLabel(result.data.standard, clause.ref)} \u00b7 ${kindLabel(form.elements.kind.value)}`);
    drafts.reqNote = '';
    refresh();
  }
  function decide(form) {
    const audit = current();
    if (!audit || !canDecide()) return;
    const state = form.dataset.avDecisionForm;
    const note = drafts.decNote.trim();
    const result = evaluate(audit, siteFor(audit));
    const error = form.querySelector('[data-av-error]');
    const open = (audit.requests || []).filter(request => request.status === 'open').length;
    const exceptions = result.total - result.items.filter(entry => entry.item.status === 'verified' && (audit.reviews || {})[entry.key]?.state === 'accepted').length;
    if (!note) { error.textContent = text('A reason is required.', 'Eine Begr\u00fcndung ist erforderlich.'); return; }
    if (state === 'hold' && !open) { error.textContent = text('Add at least one open evidence request first.', 'Zuerst mindestens eine offene Nachweisanforderung hinzuf\u00fcgen.'); return; }
    if (state === 'approve' && exceptions > 0 && !drafts.decAck) { error.textContent = text('Confirm that you approve despite the exceptions.', 'Best\u00e4tigen Sie die Freigabe trotz der Ausnahmen.'); return; }
    audit.status = { approve: 'Approved', hold: 'On hold', decline: 'Declined' }[state];
    audit.decision = { state: { approve: 'approved', hold: 'hold', decline: 'declined' }[state], note, by: actor(audit), at: new Date().toISOString(), exceptions: state === 'approve' ? exceptions : 0 };
    log(audit, { approve: text('approved', 'hat freigegeben'), hold: text('put the audit on hold', 'hat das Audit angehalten'), decline: text('declined', 'hat abgelehnt') }[state], note);
    decisionForm = '';
    drafts.decNote = '';
    drafts.decAck = false;
    refresh();
  }

  document.addEventListener('click', event => {
    if (event.target.closest('[data-av-overview]')) { selectedId = ''; render(); return; }
    const target = event.target.closest('[data-av-select],[data-av-trace],[data-av-trace-request],[data-av-accept],[data-av-question],[data-av-close-request],[data-av-withdraw-request],[data-av-decide],[data-av-cancel-decision],[data-av-reopen],[data-av-act-auditor],[data-av-open-record],[data-av-open-live]');
    if (!target) return;
    const data = target.dataset;
    if (data.avSelect !== undefined) { selectedId = data.avSelect; siteChoice = ''; decisionForm = ''; render(); return; }
    if (data.avTrace !== undefined) { openTrace(data.avTrace); return; }
    if (data.avTraceRequest !== undefined) { openTrace(null, data.avTraceRequest); return; }
    if (data.avAccept !== undefined) { accept(data.avAccept); return; }
    if (data.avQuestion !== undefined) { question(data.avQuestion); return; }
    if (data.avCloseRequest !== undefined || data.avWithdrawRequest !== undefined) {
      const audit = current();
      const request = audit?.requests.find(item => item.id === (data.avCloseRequest ?? data.avWithdrawRequest));
      if (request && canDecide()) { request.status = data.avCloseRequest !== undefined ? 'closed' : 'withdrawn'; log(audit, request.status === 'closed' ? text('closed a request', 'hat eine Anforderung geschlossen') : text('withdrew a request', 'hat eine Anforderung zur\u00fcckgezogen'), `${clauseLabel(request.standard, request.ref)}`); refresh(); }
      return;
    }
    if (data.avDecide !== undefined) { decisionForm = data.avDecide; render(); document.querySelector('[data-av-decision-form]')?.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
    if (data.avCancelDecision !== undefined) { decisionForm = ''; render(); return; }
    if (data.avReopen !== undefined) { const audit = current(); if (audit && canDecide()) { log(audit, text('reopened the review', 'hat die Pr\u00fcfung wieder ge\u00f6ffnet')); audit.status = 'Planned'; audit.decision = null; refresh(); } return; }
    if (data.avActAuditor !== undefined) {
      app().settings.role = 'Auditor';
      try { localStorage.setItem('rosnie-demo-v2-settings-v1', JSON.stringify(app().settings)); } catch { /* role stays in memory */ }
      app().render();
      if (dialog.open) openTrace(traceKey, traceRequestId);
      return;
    }
    if (data.avOpenRecord !== undefined) { const record = app().operations.evidence.find(item => item.id === data.avOpenRecord); if (record?.dataUrl) { const link = document.createElement('a'); link.href = record.dataUrl; link.target = '_blank'; link.rel = 'noopener'; link.download = record.fileName; link.click(); } return; }
    if (data.avOpenLive !== undefined) {
      dialog.close();
      document.querySelector('[data-mira-mode="customer"]')?.click();
      document.querySelector('[data-mira-view="connections"]')?.click();
      setTimeout(() => { const card = document.querySelector(`.physical-ai-card[data-device-card="${CSS.escape(data.avOpenLive)}"]`); card?.scrollIntoView({ block: 'center', behavior: 'smooth' }); card?.classList.add('flash'); setTimeout(() => card?.classList.remove('flash'), 2400); }, 150);
    }
  });
  document.addEventListener('change', event => {
    if (event.target.matches('[data-av-site]')) { siteChoice = event.target.value; render(); return; }
    if (event.target.matches('[data-av-field="reqClause"]')) { drafts.reqClause = event.target.value; drafts.reqKind = ''; render(); return; }
  });
  document.addEventListener('input', event => {
    const field = event.target.closest('[data-av-field]');
    if (!field) return;
    const name = field.dataset.avField;
    drafts[name] = field.type === 'checkbox' ? field.checked : field.value;
  });
  document.addEventListener('submit', event => {
    const request = event.target.closest('[data-av-request-form]');
    if (request) { event.preventDefault(); addRequest(request); return; }
    const decision = event.target.closest('[data-av-decision-form]');
    if (decision) { event.preventDefault(); decide(decision); }
  });
  document.addEventListener('demov2:evidence-changed', () => { if (document.querySelector('#auditor-view')) render(); });

  window.DemoV2AuditorView = { decorate: render, seed, evaluate, openTrace, select: id => { selectedId = id; siteChoice = ''; decisionForm = ''; render(); }, current: () => selectedId };
  render();
  document.addEventListener('DOMContentLoaded', () => { if (document.querySelector('#auditor-view')) render(); });
})();
