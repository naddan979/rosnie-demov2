# Contributing

Thanks for helping improve the ROSNIE Demo V2. Keep changes focused, preserve the clear ASTRA/MIRA workflows, and do not weaken the demo's simulation and compliance caveats.

## Development

- The application is plain HTML, CSS, and JavaScript. No build system or package manager is required.
- Keep app assets and script paths relative to the repository root so the project works as a GitHub Pages project site.
- Keep browser-only behavior explicit. Do not imply that demo roles provide security, that generated recommendations are AI output, or that illustrative evidence establishes conformity.
- Preserve the V2 local-storage namespace. Avoid resetting or migrating existing browser data without a deliberate, idempotent migration.
- Keep the original V1 project separate from this repository.

## Before Submitting

1. Run `scripts/validate-package.ps1` in PowerShell.
2. Serve the app locally and check the changed workflow in the browser.
3. Review at narrow mobile, tablet, and desktop widths for clipped content, horizontal overflow, and overlap.
4. If changing evidence authoring or audit behavior, run the browser checks in `README.md` in an isolated profile.
5. Summarize user-visible changes and any limitations in the pull request.

Do not include real customer records, credentials, uploaded evidence, or other sensitive data in commits or screenshots.
