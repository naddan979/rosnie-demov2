# Security Policy

## Scope

This repository is a browser-only product demonstration. It is not designed or approved for production, confidential information, or real compliance records. It has no authentication, server-side authorization, secure storage, or production integration boundary.

## Reporting a Concern

Please do not publish credentials, personal information, customer records, or exploit details in a public issue. For a private repository, contact the repository owner through GitHub. For a public repository, use GitHub's private vulnerability reporting feature when enabled, or contact the owner privately.

## Demo Data

Use fictional data only. Files and records created in the app remain in the current browser's local storage. Treat the browser profile as accessible to anyone who can use that device. Deleting browser storage or using the app's reset action can remove demo records.
